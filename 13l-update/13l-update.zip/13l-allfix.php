<?php
// =====================================================================
// 13L ALLFIX v18 — EK click me: (a) theme CSS me history-reveal rules,
// (b) entry JS me un-clip watchdog (agar nahi laga), (c) status + request
// log report. Idempotent — dobara chalane par duplicate nahi.
// URL: https://13l.club9.eu.cc/13l-allfix.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
error_reporting(E_ALL); @ini_set('display_errors', '1');
header('Content-Type: text/plain; charset=utf-8');
$R = rtrim(__DIR__, '/');

// ---------- (a) CSS reveal rules ----------
$CSS_MARK = '13L-CSS-v18';
$cssRules = "\n\n/* ===== {$CSS_MARK}: history rows must always render ===== */\n"
    . "[class*=\"my_r-body\"] .list>div,[class*=\"my_r-body\"] .list>div:nth-child(n+1){display:block!important;visibility:visible!important;opacity:1!important;max-height:none!important}\n"
    . "[class*=\"my_r-body\"] .list-item,[class*=\"my_r-body\"] .list-item:nth-child(n+4){display:flex!important;height:auto!important;min-height:1.55rem}\n"
    . "[class*=\"my_r-body\"] .list,[class*=\"MyGameRecord__C-body\"]{height:auto!important;max-height:none!important;overflow:visible!important}\n"
    . "[class*=\"my_r-body\"] .list-item-m-top,[class*=\"my_r-body\"] .list-item-m-bottom{color:#fff!important}\n"
    . "[class*=\"my_r-body\"] .list-item-m-bottom{color:#9a9a9a!important}\n";

$html = (string)@file_get_contents($R . '/index.html');
$cssTargets = [];
if (preg_match_all('#<link[^>]+href="([^"]+\.css[^"]*)"#i', $html, $mm)) {
    foreach ($mm[1] as $h) { $p = parse_url($h); if (!empty($p['path'])) $cssTargets[] = $R . $p['path']; }
}
foreach (glob($R . '/css/*.css') ?: [] as $g) $cssTargets[] = $g;
$cssTargets = array_values(array_unique($cssTargets));
$cssDone = 0; $cssSkip = 0;
foreach ($cssTargets as $f) {
    if (basename($f) === '13l-overlay.css' || !is_file($f) || !is_writable($f)) { $cssSkip++; continue; }
    if (filesize($f) > 3000000) { $cssSkip++; continue; }
    $c = (string)file_get_contents($f);
    if (strpos($c, $CSS_MARK) !== false) { $cssSkip++; continue; }
    if (@file_put_contents($f, $c . $cssRules) !== false) $cssDone++;
}

// ---------- (b) un-clip watchdog in entry JS ----------
$JS_MARK = '13L-UNCLIP-v17';
$watchdog = <<<JS

/* ===== {$JS_MARK}: history list un-clip watchdog ===== */
(function(){
  function walkFix(){
    try{
      if(document.hidden) return;
      var lists=document.querySelectorAll('[class*="my_r-body"],[class*="MyGameRecord__C-body"]');
      for(var i=0;i<lists.length;i++){
        var el=lists[i];
        if(!el || !el.children.length) continue;
        var need=el.scrollHeight-el.clientHeight;
        if(need>4){
          el.style.setProperty('height','auto','important');
          el.style.setProperty('max-height','none','important');
          el.style.setProperty('overflow','visible','important');
        }
        var p=el.parentElement,n=0;
        while(p && p!==document.body && n<7){
          var cs=window.getComputedStyle(p);
          var clips=(cs.overflowY==='hidden'||cs.overflowY==='auto'||cs.overflow==='hidden');
          if(clips && p.clientHeight < el.scrollHeight-8){
            p.style.setProperty('overflow','visible','important');
            p.style.setProperty('overflow-y','visible','important');
            p.style.setProperty('height','auto','important');
            p.style.setProperty('max-height','none','important');
          }
          p=p.parentElement; n++;
        }
      }
    }catch(e){}
  }
  setInterval(walkFix,400);
  document.addEventListener('click',function(){setTimeout(walkFix,80);setTimeout(walkFix,500);},true);
  window.addEventListener('resize',function(){setTimeout(walkFix,120);},true);
  walkFix();
})();
/* ===== /{$JS_MARK} ===== */
JS;
$jsTargets = [];
if (preg_match_all('#<script[^>]+src="(/[^"]+\.js[^"]*)"#i', $html, $mm)) {
    foreach ($mm[1] as $s) { $p = parse_url($s); if (!empty($p['path'])) $jsTargets[] = $R . $p['path']; }
}
if (!$jsTargets) $jsTargets = glob($R . '/js/index-*.js') ?: [];
$jsDone = []; $jsSkip = [];
foreach ($jsTargets as $f) {
    $bn = basename((string)$f);
    if (!is_file($f) || !is_writable($f)) { $jsSkip[] = $bn; continue; }
    if (filesize($f) > 8000000) { $jsSkip[] = $bn . ' (big)'; continue; }
    $c = (string)file_get_contents($f);
    if (strpos($c, $JS_MARK) !== false) { $jsSkip[] = $bn . ' (watchdog already)'; continue; }
    @copy($f, $f . '.bak13a');
    if (@file_put_contents($f, $c . $watchdog) !== false) $jsDone[] = $bn;
    else $jsSkip[] = $bn . ' (write fail)';
}

// ---------- (c) report ----------
echo "ALLFIX v18\n";
echo "css: {$cssDone} files patched ({$cssSkip} skipped)\n";
echo "js : " . (count($jsDone) ? implode(',', $jsDone) : '-') . ($jsSkip ? '  skip: ' . implode(',', $jsSkip) : '') . "\n";
echo "router v18 (per-game history): " . (strpos((string)@file_get_contents($R . '/api/_router.php'), 'v18: per-game history restored') !== false ? "yes" : "NO — deploy link phir khol!") . "\n";
echo "engine v13.1 (exact amounts)  : " . (@filesize($R . '/api/_core/lottery_engine.php') >= 34538 ? "yes" : "NO") . "\n";
$log = $R . '/api/_core/.netlog';
echo "\n--- app requests (last 8) ---\n";
if (is_file($log)) {
    foreach (array_slice(file($log), -8) as $l) {
        $j = json_decode(trim((string)$l), true);
        if ($j) echo ($j['t'] ?? '') . '  ' . ($j['ep'] ?? '') . '  ' . ($j['g'] ?? '') . '  rows=' . ($j['rows'] ?? '?') . "  total=" . ($j['total'] ?? '-') . "\n";
    }
} else echo "(no requests yet)\n";
echo "\nDONE ✅ — app swipe-close → reopen → har game tab me sirf uski bets + poori list dikhegi.\n";
