<?php
// =====================================================================
// 13L SELF-DEPLOY (v11) — ek file upload karo, ek link kholo, BAS.
// Ye zip khud GitHub se download karke public_html me sahi jagah lagata hai
// (config.php / bridge.php ko CHHUTA NAHI — teri live settings safe),
// backup banata hai, phir turant backfill + Win/Lose repair chalata hai.
// Bar bar chalane par bhi kuch nahi bigdega (idempotent).
//
// URL: https://13l.club9.eu.cc/13l-deploy.php?key=13l2026
// =====================================================================

if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
if (!class_exists('ZipArchive')) exit('PHP ZipArchive missing — cPanel PHP me enable karo (Modules).');

$ZIP_URL = 'https://github.com/avinashraz19818/wingoapi/raw/arena/01a06254-wingoapi/13l-update/13l-update.zip';
$ROOT = rtrim(__DIR__, '/');
$R = ['root' => $ROOT];

// --- 1) download zip ---
$tmp = tempnam(sys_get_temp_dir(), 'zip13l') . '.zip';
$ch = curl_init($ZIP_URL);
$fp = fopen($tmp, 'wb');
curl_setopt_array($ch, [CURLOPT_FILE => $fp, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 120, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0']);
$ok = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch); fclose($fp);
$sz = is_file($tmp) ? filesize($tmp) : 0;
$R['downloaded'] = $code . ' ' . $sz . 'B';
if (!$ok || $sz < 40000) { $R['error'] = 'GitHub se zip nahi aaya (code/size dekh). Phir bhi fail ho to purane tareeke se extract kar lena.'; echo json_encode($R, JSON_PRETTY_PRINT); exit; }

// --- 2) extract with guards ---
$zip = new ZipArchive();
if ($zip->open($tmp) !== true) { $R['error'] = 'zip open fail'; echo json_encode($R, JSON_PRETTY_PRINT); exit; }
$protect = ['api/_core/config.php', 'api/_core/bridge.php']; // live DB + feed config — never overwrite
$bak = $ROOT . '/13l-bak-' . date('Ymd-His');
$written = [];
for ($i = 0; $i < $zip->numFiles; $i++) {
    $name = $zip->getNameIndex($i);
    if ($name === '' || substr($name, -1) === '/') continue;
    if (strpos($name, '..') !== false) continue;
    if (in_array($name, $protect, true)) continue;
    if (!preg_match('#^(api/|css/|js/|tools/|README|13l-)#', $name)) continue;
    $dest = $ROOT . '/' . $name;
    if (is_file($dest)) { // backup old copy once
        $bd = $bak . '/' . $name;
        if (!is_dir(dirname($bd))) @mkdir(dirname($bd), 0775, true);
        @copy($dest, $bd);
    }
    if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0775, true);
    $data = $zip->getFromIndex($i);
    if ($data === false) continue;
    @file_put_contents($dest, $data);
    $written[$name] = strlen($data);
}
$zip->close();
@unlink($tmp);
$R['files_updated'] = $written;

// --- 3) turant repair: backfill + pending settle + ulte Win/Lose fix + wallet ---
require_once $ROOT . '/api/_core/bootstrap.php';
$repairRes = false;
if (function_exists('le_autorepair')) $repairRes = @le_autorepair(0); // 0 = force now
$ar = function_exists('json_setting') ? json_setting('le_autorepair', []) : [];
$R['repair'] = ['ran' => $repairRes, 'checked' => (int)($ar['checked'] ?? 0), 'fixed' => (int)($ar['fixed'] ?? 0), 'last_fixes' => $ar['last'] ?? []];

// --- 4) verify report ---
$conn = db();
$bets = [];
if ($conn) {
    $rs = $conn->query('SELECT issue_number, bet_content, state, win_lose_amount FROM lottery_bets ORDER BY id DESC LIMIT 6');
    if ($rs) while ($b = $rs->fetch_assoc()) $bets[] = $b['issue_number'] . ' ' . $b['bet_content'] . ' => ' . ((int)$b['state'] === 1 ? 'WIN' : ((int)$b['state'] === 2 ? 'PENDING' : 'LOSE')) . ' net ' . $b['win_lose_amount'];
}
$R['recent_bets_after_fix'] = $bets;
$R['markers'] = [
    'engine_v11' => (strpos((string)@file_get_contents($ROOT . '/api/_core/lottery_engine.php'), 'v11: pull official feed') !== false) ? 'yes' : 'NO',
    'choice_fix' => (strpos((string)@file_get_contents($ROOT . '/api/_core/lottery_engine.php'), 'BigSmall_(big|small)') !== false) ? 'yes' : 'NO',
    'router_hook' => (strpos((string)@file_get_contents($ROOT . '/api/_router.php'), 'le_autorepair') !== false) ? 'yes' : 'NO',
];
$R['backup_dir'] = $bak;
$R['DONE'] = 'Ab app khol → My History dekh. Screenshot/JSON developer ko bhej de.';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
echo json_encode($R, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
