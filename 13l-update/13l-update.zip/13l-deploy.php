<?php
// =====================================================================
// 13L SELF-DEPLOY v11.1 — ek file, ek link, sab automatic.
// GitHub se latest zip download → backup → update (config/bridge safe) →
// forced backfill + Win/Lose + wallet repair → report.
// Har step print hota hai; fatal ho to exact error dikhega (500 nahi).
// URL: https://13l.club9.eu.cc/13l-deploy.php?key=13l2026
// =====================================================================
error_reporting(E_ALL);
@ini_set('display_errors', '1');

$GLOBALS['DSTEP'] = [];
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array((int)$e['type'], [1, 4, 2], true)) {
        echo "\n\n!!! FATAL: {$e['message']} (line {$e['line']})\nSteps done: " . implode(' -> ', $GLOBALS['DSTEP']) . "\n";
    }
});
function dstep(string $s): void { $GLOBALS['DSTEP'][] = $s; echo "\n[ok] $s\n"; @flush(); }

if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
header('Content-Type: text/plain; charset=utf-8');
echo "13L deploy v11.1 — steps:\n";

$ZIP_URL = 'https://github.com/avinashraz19818/wingoapi/raw/arena/01a06254-wingoapi/13l-update/13l-update.zip?v=' . time(); // cache-bust GitHub CDN
$ROOT = rtrim(__DIR__, '/');
dstep('root=' . $ROOT);

// --- 1) download zip (curl → file_get_contents fallback) ---
$tmp = $ROOT . '/.13l-deploy-tmp.zip';
$got = false;
if (function_exists('curl_init')) {
    $fp = @fopen($tmp, 'wb');
    if ($fp) {
        $ch = curl_init($ZIP_URL);
        curl_setopt_array($ch, [CURLOPT_FILE => $fp, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 120, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0']);
        $got = (bool)@curl_exec($ch) && (int)curl_getinfo($ch, CURLINFO_HTTP_CODE) === 200;
        curl_close($ch); fclose($fp);
    }
}
if (!$got) {
    $ctx = stream_context_create(['http' => ['timeout' => 120, 'user_agent' => 'Mozilla/5.0', 'follow_location' => 1]]);
    $data = @file_get_contents($ZIP_URL, false, $ctx);
    if ($data !== false && strlen($data) > 40000) { @file_put_contents($tmp, $data); $got = true; }
}
$sz = is_file($tmp) ? filesize($tmp) : 0;
if (!$got || $sz < 40000) { @unlink($tmp); exit("\n[FAIL] zip download nahi hua (size $sz). Host GitHub block kar raha ho to zip manually extract kar lena — baaki sab same.\n"); }
dstep("zip downloaded ($sz B)");

// --- 2) extract with guards (config.php + live bridge.php NEVER touched) ---
if (!class_exists('ZipArchive')) { @unlink($tmp); exit("\n[FAIL] PHP ZipArchive module missing — cPanel → Select PHP Version → Options me zip enable karo.\n"); }
$zip = new ZipArchive();
if ($zip->open($tmp) !== true) { @unlink($tmp); exit("\n[FAIL] zip open fail\n"); }
$bak = $ROOT . '/13l-bak-' . date('Ymd-His');
$written = 0;
for ($i = 0; $i < $zip->numFiles; $i++) {
    $name = (string)$zip->getNameIndex($i);
    if ($name === '' || substr($name, -1) === '/' || strpos($name, '..') !== false) continue;
    if ($name === 'api/_core/config.php' || $name === 'api/_core/bridge.php') continue;
    if (!preg_match('#^(api/|css/|js/|tools/|README|13l-)#', $name)) continue;
    $dest = $ROOT . '/' . $name;
    if (is_file($dest)) {
        $bd = $bak . '/' . $name;
        if (!is_dir(dirname($bd))) { @mkdir(dirname($bd), 0775, true); }
        @copy($dest, $bd);
    }
    if (!is_dir(dirname($dest))) { @mkdir(dirname($dest), 0775, true); }
    $data = $zip->getFromIndex($i);
    if ($data === false) continue;
    if (@file_put_contents($dest, $data) !== false) $written++;
}
$zip->close();
@unlink($tmp);
dstep("files updated: $written (backup: $bak)");

// --- 3) forced repair on NEW code: backfill + settle + recalc (incl. premium-fallback) ---
if (!is_file($ROOT . '/api/_core/bootstrap.php')) { exit("\n[FAIL] bootstrap.php missing?! Zip galat folder me gaya hoga — public_html me extract karo.\n"); }
require_once $ROOT . '/api/_core/bootstrap.php';
dstep('bootstrap loaded');
$ran = function_exists('le_autorepair') ? @le_autorepair(0) : false;
dstep('le_autorepair forced: ' . ($ran ? 'YES' : 'NO (lock/perm issue)'));

// --- 4) report ---
$conn = db();
$bets = [];
$water = [];
if ($conn) {
    $rs = $conn->query('SELECT issue_number, game_code, bet_content, state, win_lose_amount FROM lottery_bets ORDER BY id DESC LIMIT 8');
    if ($rs) while ($b = $rs->fetch_assoc()) {
        $bets[] = $b['issue_number'] . ' [' . $b['bet_content'] . '] => ' . ((int)$b['state'] === 1 ? 'WIN' : ((int)$b['state'] === 2 ? 'PENDING' : 'LOSE')) . ' net ' . $b['win_lose_amount'] . ' (game ' . $b['game_code'] . ')';
    }
    if (function_exists('json_setting')) { $water = json_setting('le_autorepair', []); }
}
echo "\n--- recent bets (AFTER repair) ---\n" . implode("\n", $bets) . "\n";
echo "\n--- autorepair watermark ---\nlast_run: " . ($water['ran_at'] ?? 'n/a') . "  checked: " . (int)($water['checked'] ?? 0) . "  fixed: " . (int)($water['fixed'] ?? 0) . "\n";
foreach ((array)($water['last'] ?? []) as $l) { echo "  fixed: $l\n"; }
// --- 5) v23 auto-run: histfix overlay filler + v19 cache purge (marker-safe) ---
echo "\n--- v23 patches auto-run ---\n";
$GLOBALS['13L_CHAIN'] = true;
$_GET['key'] = '13l2026';
@ini_set('display_errors', '0');
foreach (['13l-histfix.php', '13l-v19.php'] as $__f) {
    if (is_file($ROOT . '/' . $__f)) { include $ROOT . '/' . $__f; echo "\n"; }
    else echo "$__f: zip me nahi mila (skip)\n";
}
@ini_set('display_errors', '1');

echo "\nDONE ✅ — deploy ne saare patches bhi chala liye. Ab app band→khol → My history check.\n";
