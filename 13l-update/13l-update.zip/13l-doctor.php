<?php
// =====================================================================
// 13L DOCTOR v8 — ek link kholo, sab check + repair + REPORT.
// URL: https://13l.club9.eu.cc/13l-doctor.php?key=13l2026
// Output ka poora screenshot/copy developer ko bhejo.
// (Ye file delete mat karna jab tak developer bole — dobara chalani pad sakti hai)
// =====================================================================

if (($_GET['key'] ?? '') !== '13l2026') {
    http_response_code(403);
    exit('wrong key');
}

require_once __DIR__ . '/api/_core/bootstrap.php';

$R = ['ok' => false];

// ---- 1) deployed files ka fingerprint (v7/v8 files hi hone chahiye) ----
$R['files'] = [];
foreach (['api/_core/bootstrap.php', 'api/_core/lottery_engine.php', 'api/_core/lottery_bridge.php', 'api/_router.php', 'api/_core/bridge.php'] as $f) {
    $p = __DIR__ . '/' . $f;
    $R['files'][$f] = is_file($p) ? (filesize($p) . 'B @ ' . date('m-d H:i', filemtime($p))) : 'MISSING';
}
$R['has_no_store_fix'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/bootstrap.php'), 'no-store') !== false) ? 'yes' : 'NO — v7+ deploy nahi hua!';
$R['has_lb'] = function_exists('lb_sync') ? 'yes' : 'NO';

// ---- 2) bridge/feed status ----
$R['bridge_cfg'] = function_exists('lb_cfg') ? lb_cfg() : 'missing';
if (function_exists('lb_enabled') && lb_enabled()) {
    $R['feed_probe'] = lb_probe(lb_cfg()['mode'] ?: 'ar', lb_cfg()['base'], lb_cfg()['key'] ?? '');
} else {
    $R['feed_probe'] = 'bridge OFF (local draw chal raha hai)';
}

// ---- 3) resync results from feed (agar on hai) ----
$R['feed_rows_synced'] = 0;
if (function_exists('lb_enabled') && lb_enabled()) {
    foreach (glob(sys_get_temp_dir() . '/lbhist_*.json') ?: [] as $f) @unlink($f);
    foreach (['WinGo_30S','WinGo_1M','WinGo_3M','WinGo_5M','TrxWinGo_1M'] as $g) $R['feed_rows_synced'] += (int)lb_sync($g, 60);
}

// ---- 4) settle pending ----
foreach (['WinGo_30S','WinGo_1M','WinGo_3M','WinGo_5M'] as $g) { @le_settle_pending_bets($g); }

// ---- 5) REPAIR: already-settled bets vs official results ----
$conn = db();
if (!$conn) { $R['error'] = 'DB connect failed'; header('Content-Type: application/json'); echo json_encode($R, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES); exit; }
$fixed = 0; $mismatchList = [];
$rs = $conn->query(
    "SELECT b.id, b.user_id, b.order_no, b.game_code, b.issue_number, b.bet_content,
            b.real_amount, b.fee, b.state, b.premium AS bet_premium, b.win_lose_amount, r.premium AS good_premium
     FROM lottery_bets b
     JOIN lottery_results r ON r.game_code = b.game_code AND r.issue_number = b.issue_number
     WHERE b.state IN (0,1) AND b.created_at > DATE_SUB(NOW(), INTERVAL 3 DAY)
       AND TRIM(b.premium) <> TRIM(r.premium)
     LIMIT 500"
);
if ($rs) {
    while ($b = $rs->fetch_assoc()) {
        $g = (string)$b['game_code'];
        $result = le_result_detail($g, (string)$b['good_premium'], (string)$b['issue_number']);
        $choice = le_extract_choice($g, (string)$b['bet_content']);
        $settings = le_get_settings($g);
        $isWin = le_result_matches($choice, $result, $g);
        $rate = le_payout_rate($g, $choice, $settings);
        $stake = (float)$b['real_amount'];
        $fee = (float)$b['fee'];
        $payout = $isWin ? round(max(0.0, $stake - $fee) * $rate, 2) : 0.0;
        $net = round($payout - $stake, 2);
        $delta = round($net - (float)$b['win_lose_amount'], 2);
        $stmt = $conn->prepare('UPDATE lottery_bets SET premium=?, state=?, win_lose_amount=? WHERE id=?');
        $st = (int)($isWin ? 1 : 0);
        $prem = (string)$result['premium'];
        $stmt->bind_param('sidi', $prem, $st, $net, $b['id']);
        @$stmt->execute();
        if (abs($delta) >= 0.01) {
            $stmt = $conn->prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
            $stmt->bind_param('di', $delta, $b['user_id']);
            @$stmt->execute();
        }
        $mismatchList[] = ['order' => (string)$b['order_no'], 'issue' => (string)$b['issue_number'], 'bet' => (string)$b['bet_content'], 'was' => (string)$b['bet_premium'], 'now' => $prem, 'wallet_delta' => $delta];
        $fixed++;
    }
}
$R['bets_repaired'] = $fixed;
$R['repair_detail'] = array_slice($mismatchList, 0, 10);

// ---- 6) CURRENT DATA SNAPSHOT (developer ko ye chahiye) ----
$R['recent_results'] = [];
$rs = $conn->query("SELECT game_code, issue_number, premium FROM lottery_results WHERE game_code LIKE 'WinGo_30S' ORDER BY id DESC LIMIT 8");
if ($rs) while ($x = $rs->fetch_assoc()) $R['recent_results'][] = $x['issue_number'] . '=' . $x['premium'];
$R['recent_bets'] = [];
$rs = $conn->query("SELECT game_code, issue_number, bet_content, premium, state, win_lose_amount, created_at FROM lottery_bets ORDER BY id DESC LIMIT 10");
if ($rs) while ($x = $rs->fetch_assoc()) $R['recent_bets'][] = $x['issue_number'] . ' [' . substr($x['bet_content'], 0, 14) . '] betPrem=' . $x['premium'] . ' state=' . $x['state'] . ' net=' . $x['win_lose_amount'] . ' @' . $x['created_at'];
$R['issue_now'] = lottery_issue('WinGo_30S');
$R['server_now_utc'] = gmdate('Y-m-d H:i:s');
$R['server_tz'] = date_default_timezone_get();
$R['php'] = PHP_VERSION;
$R['has_myhistory_all'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_router.php'), 'v13: \"My History\" must show') !== false) ? 'yes' : 'NO — v13 router deploy nahi hua';
$R['has_bridge_fix'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_bridge.php'), 'v11.2 CRITICAL') !== false) ? 'yes' : 'NO — bridge ka bind fix deploy nahi hua (v11.2 zip chahiye, CDN 10 min me fresh hoga)';
$R['has_v11_backfill'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_engine.php'), 'v11: pull official feed') !== false) ? 'yes' : 'NO — v11 engine deploy nahi hua!';
$R['has_choice_fix'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_engine.php'), 'BigSmall_(big|small)') !== false) ? 'yes' : 'NO — v9/v10 engine deploy nahi hua!';
$R['has_autorepair'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_engine.php'), 'le_autorepair') !== false) ? 'yes' : 'NO — v10 engine deploy nahi hua!';
$ar = function_exists('json_setting') ? json_setting('le_autorepair', []) : [];
$R['autorepair'] = [
    'last_run' => isset($ar['ran_at']) ? $ar['ran_at'] : 'abhi tak nahi chala (koi game page kholo, 1 poll me chalega)',
    'checked' => (int)($ar['checked'] ?? 0),
    'fixed' => (int)($ar['fixed'] ?? 0),
    'last_fixes' => $ar['last'] ?? [],
];

$R['ok'] = true;

// ===== SKIN DEBUG (v12): bundle grep + DB counts — developer ke liye =====
$R['bets_by_user'] = [];
$rsU = @$conn ? $conn->query('SELECT user_id, COUNT(*) c, MIN(DATE(created_at)) d0, MAX(DATE(created_at)) d1 FROM lottery_bets GROUP BY user_id ORDER BY c DESC LIMIT 6') : null;
if ($rsU) while ($u = $rsU->fetch_assoc()) $R['bets_by_user'][] = 'uid=' . $u['user_id'] . ' n=' . $u['c'] . ' [' . $u['d0'] . '..' . $u['d1'] . ']';
$R['bets_by_game'] = [];
$rsG = @$conn ? $conn->query('SELECT game_code, COUNT(*) c, SUM(user_id=(SELECT id FROM users ORDER BY balance DESC LIMIT 1)) top_user_n FROM lottery_bets GROUP BY game_code ORDER BY c DESC LIMIT 8') : null;
if ($rsG) while ($u = $rsG->fetch_assoc()) $R['bets_by_game'][] = $u['game_code'] . ' n=' . $u['c'];
$R['users_n'] = $conn ? (int)@$conn->query('SELECT COUNT(*) c FROM users')->fetch_assoc()['c'] : 0;

$sk = ['js_files' => [], 'hits' => []];
$html = (string)@file_get_contents(__DIR__ . '/index.html');
preg_match_all('#(?:src|href)="(/[^"]+\.js[^"]*)"#', $html, $mm);
$files = array_values(array_unique($mm[1]));
$scan = [];
foreach ($files as $f) { if (is_file(__DIR__ . $f)) $scan[] = $f; }
if (!$scan) { foreach (glob(__DIR__ . '/js/*.js') ?: [] as $p) $scan[] = '/' . basename($p); }
$sk['js_files'] = array_slice($scan, 0, 15);
$pats = ['GetMyGameRecord', 'GameRecord', 'GetmyIssusPage', 'myHistory', 'queryPage', 'totalPage', 'isWin', 'status==', 'status:', 'winLoseAmount', 'winAmount', 'betTime', 'scrollToLoad', 'finished', 'van-list', 'no more', 'noData'];
foreach ($scan as $jf) {
    $js = (string)@file_get_contents(__DIR__ . $jf);
    if (strlen($js) < 10) continue;
    if (strlen($js) > 4000000) $js = substr($js, 0, 4000000);
    foreach ($pats as $p) {
        $off = 0; $n = 0;
        while ($n < 2 && ($pos = stripos($js, $p, $off)) !== false) {
            $snip = substr($js, max(0, $pos - 70), 200);
            $snip = preg_replace('/\s+/', ' ', $snip);
            if (!isset($sk['hits'][$p])) $sk['hits'][$p] = [];
            if (count($sk['hits'][$p]) < 3) $sk['hits'][$p][] = basename($jf) . ' | ' . $snip;
            $off = $pos + strlen($p); $n++;
        }
    }
}
$R['skin_debug'] = $sk;
// ---- live record call as the skin does it: two variants ----
$R['record_variants'] = [];
foreach ([['gameCode' => 'WinGo_30S', 'pageNo' => 1, 'pageSize' => 10], ['pageNo' => 1, 'pageSize' => 10]] as $qi => $qq) {
    $q = http_build_query($qq);
    $resp = @file_get_contents('http://127.0.0.1/api/Lottery/GetMyGameRecord.php?' . $q, false, stream_context_create(['http' => ['timeout' => 8, 'header' => 'Host: ' . ($_SERVER['HTTP_HOST'] ?? '13l.club9.eu.cc')]]));
    $j = json_decode((string)$resp, true);
    $R['record_variants'][] = ['q' => $q, 'code' => is_array($j) ? (int)($j['code'] ?? -1) : 'nojson', 'rows' => is_array($j) ? count($j['data']['list'] ?? []) : 0, 'totalCount' => is_array($j) ? (int)($j['data']['totalCount'] ?? -1) : -1, 'totalPage' => is_array($j) ? (int)($j['data']['totalPage'] ?? -1) : -1];
}

$R['next'] = 'Poora JSON copy karke developer ko bhejo (ya screen ka screenshot).';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
echo json_encode($R, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
