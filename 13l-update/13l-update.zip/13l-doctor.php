<?php
// =====================================================================
// 13L DOCTOR v8 — ek link kholo, sab check + repair + REPORT.
// URL: https://13l.club9.eu.cc/13l-doctor.php?key=13l2026
// Output ka poora screenshot/copy developer ko bhejo.
// (Ye file delete mat karna jab tak developer bole — dobara chalani pad sakti hai)
// =====================================================================

if (($_GET['key'] ?? '') !== '13l2026') {
    http_response_code(403);
    exit('wrong key');
}

require_once __DIR__ . '/api/_core/bootstrap.php';

$R = ['ok' => false];

// ---- 1) deployed files ka fingerprint (v7/v8 files hi hone chahiye) ----
$R['files'] = [];
foreach (['api/_core/bootstrap.php', 'api/_core/lottery_engine.php', 'api/_core/lottery_bridge.php', 'api/_router.php', 'api/_core/bridge.php'] as $f) {
    $p = __DIR__ . '/' . $f;
    $R['files'][$f] = is_file($p) ? (filesize($p) . 'B @ ' . date('m-d H:i', filemtime($p))) : 'MISSING';
}
$R['has_no_store_fix'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/bootstrap.php'), 'no-store') !== false) ? 'yes' : 'NO — v7+ deploy nahi hua!';
$R['has_lb'] = function_exists('lb_sync') ? 'yes' : 'NO';

// ---- 2) bridge/feed status ----
$R['bridge_cfg'] = function_exists('lb_cfg') ? lb_cfg() : 'missing';
if (function_exists('lb_enabled') && lb_enabled()) {
    $R['feed_probe'] = lb_probe(lb_cfg()['mode'] ?: 'ar', lb_cfg()['base'], lb_cfg()['key'] ?? '');
} else {
    $R['feed_probe'] = 'bridge OFF (local draw chal raha hai)';
}

// ---- 3) resync results from feed (agar on hai) ----
$R['feed_rows_synced'] = 0;
if (function_exists('lb_enabled') && lb_enabled()) {
    foreach (glob(sys_get_temp_dir() . '/lbhist_*.json') ?: [] as $f) @unlink($f);
    foreach (['WinGo_30S','WinGo_1M','WinGo_3M','WinGo_5M','TrxWinGo_1M'] as $g) $R['feed_rows_synced'] += (int)lb_sync($g, 60);
}

// ---- 4) settle pending ----
foreach (['WinGo_30S','WinGo_1M','WinGo_3M','WinGo_5M'] as $g) { @le_settle_pending_bets($g); }

// ---- 5) REPAIR: already-settled bets vs official results ----
$conn = db();
if (!$conn) { $R['error'] = 'DB connect failed'; header('Content-Type: application/json'); echo json_encode($R, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES); exit; }
$fixed = 0; $mismatchList = [];
$rs = $conn->query(
    "SELECT b.id, b.user_id, b.order_no, b.game_code, b.issue_number, b.bet_content,
            b.real_amount, b.fee, b.state, b.premium AS bet_premium, b.win_lose_amount, r.premium AS good_premium
     FROM lottery_bets b
     JOIN lottery_results r ON r.game_code = b.game_code AND r.issue_number = b.issue_number
     WHERE b.state IN (0,1) AND b.created_at > DATE_SUB(NOW(), INTERVAL 3 DAY)
       AND TRIM(b.premium) <> TRIM(r.premium)
     LIMIT 500"
);
if ($rs) {
    while ($b = $rs->fetch_assoc()) {
        $g = (string)$b['game_code'];
        $result = le_result_detail($g, (string)$b['good_premium'], (string)$b['issue_number']);
        $choice = le_extract_choice($g, (string)$b['bet_content']);
        $settings = le_get_settings($g);
        $isWin = le_result_matches($choice, $result, $g);
        $rate = le_payout_rate($g, $choice, $settings);
        $stake = (float)$b['real_amount'];
        $fee = (float)$b['fee'];
        $payout = $isWin ? round(max(0.0, $stake - $fee) * $rate, 2) : 0.0;
        $net = round($payout - $stake, 2);
        $delta = round($net - (float)$b['win_lose_amount'], 2);
        $stmt = $conn->prepare('UPDATE lottery_bets SET premium=?, state=?, win_lose_amount=? WHERE id=?');
        $st = (int)($isWin ? 1 : 0);
        $prem = (string)$result['premium'];
        $stmt->bind_param('sidi', $prem, $st, $net, $b['id']);
        @$stmt->execute();
        if (abs($delta) >= 0.01) {
            $stmt = $conn->prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
            $stmt->bind_param('di', $delta, $b['user_id']);
            @$stmt->execute();
        }
        $mismatchList[] = ['order' => (string)$b['order_no'], 'issue' => (string)$b['issue_number'], 'bet' => (string)$b['bet_content'], 'was' => (string)$b['bet_premium'], 'now' => $prem, 'wallet_delta' => $delta];
        $fixed++;
    }
}
$R['bets_repaired'] = $fixed;
$R['repair_detail'] = array_slice($mismatchList, 0, 10);

// ---- 6) CURRENT DATA SNAPSHOT (developer ko ye chahiye) ----
$R['recent_results'] = [];
$rs = $conn->query("SELECT game_code, issue_number, premium FROM lottery_results WHERE game_code LIKE 'WinGo_30S' ORDER BY id DESC LIMIT 8");
if ($rs) while ($x = $rs->fetch_assoc()) $R['recent_results'][] = $x['issue_number'] . '=' . $x['premium'];
$R['recent_bets'] = [];
$rs = $conn->query("SELECT game_code, issue_number, bet_content, premium, state, win_lose_amount, created_at FROM lottery_bets ORDER BY id DESC LIMIT 10");
if ($rs) while ($x = $rs->fetch_assoc()) $R['recent_bets'][] = $x['issue_number'] . ' [' . substr($x['bet_content'], 0, 14) . '] betPrem=' . $x['premium'] . ' state=' . $x['state'] . ' net=' . $x['win_lose_amount'] . ' @' . $x['created_at'];
$R['issue_now'] = lottery_issue('WinGo_30S');
$R['server_now_utc'] = gmdate('Y-m-d H:i:s');
$R['server_tz'] = date_default_timezone_get();
$R['php'] = PHP_VERSION;
$R['has_v11_backfill'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_engine.php'), 'v11: pull official feed') !== false) ? 'yes' : 'NO — v11 engine deploy nahi hua!';
$R['has_choice_fix'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_engine.php'), 'BigSmall_(big|small)') !== false) ? 'yes' : 'NO — v9/v10 engine deploy nahi hua!';
$R['has_autorepair'] = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_engine.php'), 'le_autorepair') !== false) ? 'yes' : 'NO — v10 engine deploy nahi hua!';
$ar = function_exists('json_setting') ? json_setting('le_autorepair', []) : [];
$R['autorepair'] = [
    'last_run' => isset($ar['ran_at']) ? $ar['ran_at'] : 'abhi tak nahi chala (koi game page kholo, 1 poll me chalega)',
    'checked' => (int)($ar['checked'] ?? 0),
    'fixed' => (int)($ar['fixed'] ?? 0),
    'last_fixes' => $ar['last'] ?? [],
];

$R['ok'] = true;
$R['next'] = 'Poora JSON copy karke developer ko bhejo (ya screen ka screenshot).';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
echo json_encode($R, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
