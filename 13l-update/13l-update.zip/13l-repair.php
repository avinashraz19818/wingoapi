<?php
// =====================================================================
// 13L REPAIR — ek baar chalao, khud delete ho jayegi.
//   1) feed se results dobara sync (aur 15s cache clear)
//   2) jo bets pehle GALAT result par settle ho chuke hain (lottery_results
//      ka official premium se match nahi karte) — unhe dobara calculate karke
//      state/amounts THEEK karegi aur wallet ka farak adjust karegi
//   3) abhi-pending closed bets settle karegi
// URL: https://13l.club9.eu.cc/13l-repair.php?key=13l2026
// =====================================================================

if (($_GET['key'] ?? '') !== '13l2026') {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'open the exact URL from the README']);
    exit;
}

require_once __DIR__ . '/api/_core/bootstrap.php';

$out = ['ok' => false, 'steps' => []];
$conn = db();
if (!$conn) { $out['error'] = 'DB connect failed'; echo json_encode($out); exit; }

// 1) clear bridge list caches + resync recent draws for all games
foreach (glob(sys_get_temp_dir() . '/lbhist_*.json') ?: [] as $f) @unlink($f);
$games = ['WinGo_30S','WinGo_1M','WinGo_3M','WinGo_5M','TrxWinGo_1M','TrxWinGo_3M','TrxWinGo_5M','K3_1M','K3_3M','K3_5M','D5_1M','D5_3M','D5_5M','MotoRace_1M'];
$synced = 0;
foreach ($games as $g) { $synced += (int)lb_sync($g, 60); }
$out['steps']['feed_rows_synced_now'] = $synced; // NEW rows only (updates don't count)
$out['steps']['bridge'] = (lb_enabled() ? 'on: ' . lb_cfg()['mode'] . ' ' . lb_cfg()['base'] : 'OFF (local draw)');

// 2) settle still-pending bets whose period is closed
foreach ($games as $g) { le_settle_pending_bets($g); }

// 3) reconcile already-settled bets against official lottery_results
//    (last 3 days, only where a result row exists and premium differs)
$rs = $conn->query(
    "SELECT b.id, b.user_id, b.order_no, b.game_code, b.issue_number, b.bet_content,
            b.real_amount, b.fee, b.state, b.win_lose_amount, r.premium AS good_premium
     FROM lottery_bets b
     JOIN lottery_results r ON r.game_code = b.game_code AND r.issue_number = b.issue_number
     WHERE b.state IN (0,1) AND b.created_at > DATE_SUB(NOW(), INTERVAL 3 DAY)
       AND TRIM(b.premium) <> TRIM(r.premium)
     LIMIT 500"
);
$fixed = 0; $skipped = 0;
if ($rs) {
    while ($b = $rs->fetch_assoc()) {
        $g = (string)$b['game_code'];
        $result = le_result_detail($g, (string)$b['good_premium'], (string)$b['issue_number']);
        $choice = le_extract_choice($g, (string)$b['bet_content']);
        $settings = le_get_settings($g);
        $isWin = le_result_matches($choice, $result, $g);
        $rate = le_payout_rate($g, $choice, $settings);
        $stake = (float)$b['real_amount'];
        $fee = (float)$b['fee'];
        $payout = $isWin ? round(max(0.0, $stake - $fee) * $rate, 2) : 0.0;
        $net = round($payout - $stake, 2);
        $oldNet = (float)$b['win_lose_amount'];
        $delta = round($net - $oldNet, 2);

        $stmt = $conn->prepare('UPDATE lottery_bets SET premium=?, state=?, win_lose_amount=? WHERE id=?');
        $st = (int)($isWin ? 1 : 0);
        $prem = (string)$result['premium'];
        $stmt->bind_param('sidi', $prem, $st, $net, $b['id']);
        if (!$stmt->execute()) { $skipped++; continue; }

        if (abs($delta) >= 0.01) {
            $stmt = $conn->prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
            $stmt->bind_param('di', $delta, $b['user_id']);
            if (!$stmt->execute()) { $skipped++; continue; }
            $recordNo = (string)$b['order_no'] . 'R' . $b['id'];
            $remark = 'Settle repair ' . $g . ' issue ' . $b['issue_number'] . ' delta ' . $delta;
            $type = $delta >= 0 ? 'GameWin' : 'GameLose';
            $amt = abs($delta); $back = 0.0; $vendor = 'ARLottery';
            $stmt = $conn->prepare('INSERT IGNORE INTO financial_records(user_id, record_no, order_no, vendor_code, type, amount, back_amount, remark, created_at) VALUES(?,?,?,?,?,?,?,?,NOW())');
            $stmt->bind_param('issssdds', $b['user_id'], $recordNo, (string)$b['order_no'], $vendor, $type, $amt, $back, $remark);
            @$stmt->execute();
        }
        $fixed++;
    }
}
$out['steps']['bets_repaired'] = $fixed;
$out['steps']['bets_skipped'] = $skipped;

$out['ok'] = true;
$out['note'] = 'Ab My history aur Game history dono official results se consistent honge. Ek naya bet laga ke check karo.';
$out['setup_file'] = @unlink(__FILE__) ? 'self-deleted' : 'delete this file manually';

header('Content-Type: application/json');
echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
