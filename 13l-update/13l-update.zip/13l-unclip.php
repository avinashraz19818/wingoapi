<?php
// =====================================================================
// 13L UN-CLIP v17 — entry JS ke end me ek watchdog patch: My history /
// Game history list ke parent containers ko skin ka runtime JS fixed-height
// + overflow:hidden de deta hai (rows "1 sec me gayab" ka asli karan).
// Watchdog parent chain ko expand karta hai AUR lock nahi lagne deta.
// URL: https://13l.club9.eu.cc/13l-unclip.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
header('Content-Type: text/plain; charset=utf-8');
$R = rtrim(__DIR__, '/');
$MARK = '13L-UNCLIP-v17';

$patch = <<<JS

/* ===== {$MARK}: history list un-clip watchdog ===== */
(function(){
  function walkFix(){
    try{
      if(document.hidden) return;
      var lists=document.querySelectorAll('[class*="my_r-body"],[class*="MyGameRecord__C-body"]');
      for(var i=0;i<lists.length;i++){
        var el=lists[i];
        if(!el || !el.children.length) continue;
        var need=el.scrollHeight-el.clientHeight;
        if(need>4){ // list itself clips (fixed height) -> open it
          el.style.setProperty('height','auto','important');
          el.style.setProperty('max-height','none','important');
          el.style.setProperty('overflow','visible','important');
        }
        var p=el.parentElement,n=0;
        while(p && p!==document.body && n<7){
          var cs=window.getComputedStyle(p);
          var oy=cs.overflowY, ov=cs.overflow;
          var clips=(oy==='hidden'||oy==='auto'||ov==='hidden');
          if(clips && p.clientHeight < el.scrollHeight-8 && p.getAttribute('data-13l-un')!=='1'){
            p.setAttribute('data-13l-un','1');
            p.style.setProperty('overflow','visible','important');
            p.style.setProperty('overflow-y','visible','important');
            p.style.setProperty('height','auto','important');
            p.style.setProperty('max-height','none','important');
          } else if(p.getAttribute('data-13l-un')==='1' && p.clientHeight < el.scrollHeight-8){
            // skin ne doobaar height thoonsi — dobara kholo
            p.style.setProperty('overflow','visible','important');
            p.style.setProperty('overflow-y','visible','important');
            p.style.setProperty('height','auto','important');
            p.style.setProperty('max-height','none','important');
          }
          p=p.parentElement; n++;
        }
      }
    }catch(e){}
  }
  setInterval(walkFix,400);
  document.addEventListener('click',function(){setTimeout(walkFix,80);setTimeout(walkFix,500);},true);
  window.addEventListener('resize',function(){setTimeout(walkFix,120);},true);
  walkFix();
})();
/* ===== /{$MARK} ===== */
JS;

$html = (string)@file_get_contents($R . '/index.html');
$targets = [];
if (preg_match_all('#<script[^>]+src="(/[^"]+\.js[^"]*)"#i', $html, $mm)) {
    foreach ($mm[1] as $s) { $p = parse_url($s); if (!empty($p['path'])) $targets[] = $R . $p['path']; }
}
if (!$targets) $targets = glob($R . '/js/index-*.js') ?: [];
$done = []; $skipped = [];
foreach ($targets as $f) {
    $bn = basename((string)$f);
    if (!is_file($f) || !is_writable($f)) { $skipped[] = $bn . ' (missing/nowrite)'; continue; }
    if (filesize($f) > 8000000) { $skipped[] = $bn . ' (too big)'; continue; }
    $c = (string)file_get_contents($f);
    if (strpos($c, $MARK) !== false) { $skipped[] = $bn . ' (already patched)'; continue; }
    @copy($f, $f . '.bak13lu');
    if (@file_put_contents($f, $c . $patch) !== false) $done[] = $bn;
    else $skipped[] = $bn . ' (write fail)';
}
echo "UNCLIP v17\n";
echo "patched (" . count($done) . "):\n  " . implode("\n  ", $done ?: ['(none)']) . "\n";
echo "skipped (" . count($skipped) . "):\n  " . implode("\n  ", $skipped ?: ['(none)']) . "\n";
echo "\nAb app band→khol → My history: expand hoga, sikudega nahi (watchdog har 0.4s check karta hai).\n";
