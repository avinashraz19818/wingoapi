<?php
// =====================================================================
// 13L REPAIR v11.1 — backfill + ALL settled bets (7 days) ko OFFICIAL
// result (na mile to bet ke saved number) se recalculate; wallet +
// statement bhi theek. Koi mismatch-gate nahi — har row verify hoti hai.
// URL: https://13l.club9.eu.cc/13l-repair2.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
error_reporting(E_ALL);
@ini_set('display_errors', '1');
@set_time_limit(0);
@ignore_user_abort(true);

require_once __DIR__ . '/api/_core/bootstrap.php';
$conn = db();
if (!$conn) { echo json_encode(['error' => 'DB fail']); exit; }

$parserOk = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_engine.php'), 'BigSmall_(big|small)') !== false) ? 'yes' : 'NO';
echo "engine choice-fix: $parserOk\n";

// backfill: jo games kheli gayi, unke latest 100 official results uthao
$gset = [];
$rs = @$conn->query('SELECT DISTINCT game_code FROM lottery_bets WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY) LIMIT 8');
if ($rs) while ($x = $rs->fetch_assoc()) $gset[] = (string)$x['game_code'];
if (function_exists('lb_sync')) {
    foreach ($gset as $g) { $n = @lb_sync($g, 100); echo "backfill $g: $n rows\n"; }
}

// pending settle
foreach ($gset as $g) { @le_settle_pending_bets($g); }

// full recalc — official row first, bet premium fallback
$checked = 0; $fixed = 0; $details = [];
$setCache = [];
$rs = $conn->query(
    'SELECT b.id, b.user_id, b.order_no, b.game_code, b.issue_number, b.bet_content,
            b.real_amount, b.fee, b.state, b.win_lose_amount,
            COALESCE(NULLIF(TRIM(r.premium),\'\'), NULLIF(TRIM(b.premium),\'\')) AS good_premium
     FROM lottery_bets b
     LEFT JOIN lottery_results r ON r.game_code = b.game_code AND r.issue_number = b.issue_number
     WHERE b.state IN (0,1) AND b.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
       AND COALESCE(NULLIF(TRIM(r.premium),\'\'), NULLIF(TRIM(b.premium),\'\')) IS NOT NULL
     ORDER BY b.id DESC LIMIT 2000'
);
if ($rs) {
    while ($b = $rs->fetch_assoc()) {
        $checked++;
        $g = (string)$b['game_code'];
        $result = le_result_detail($g, (string)$b['good_premium'], (string)$b['issue_number']);
        $choice = le_extract_choice($g, (string)$b['bet_content']);
        $isWin = le_result_matches($choice, $result, $g);
        if (!isset($setCache[$g])) $setCache[$g] = le_get_settings($g);
        $rate = le_payout_rate($g, $choice, $setCache[$g]);
        $stake = (float)$b['real_amount'];
        $fee = (float)$b['fee'];
        $payout = $isWin ? round(max(0.0, $stake - $fee) * $rate, 2) : 0.0;
        $net = round($payout - $stake, 2);
        $wantState = $isWin ? 1 : 0;
        if ((int)$b['state'] === $wantState && abs((float)$b['win_lose_amount'] - $net) < 0.01) continue;
        $stmt = $conn->prepare('UPDATE lottery_bets SET premium=?, state=?, win_lose_amount=? WHERE id=?');
        $prem = (string)$result['premium'];
        $stmt->bind_param('sidi', $prem, $wantState, $net, $b['id']);
        if (!$stmt->execute()) continue;
        $delta = round($net - (float)$b['win_lose_amount'], 2);
        if (abs($delta) >= 0.01) {
            $stmt = $conn->prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
            $stmt->bind_param('di', $delta, $b['user_id']);
            @$stmt->execute();
            $rec = (string)$b['order_no'] . 'R4' . $b['id'];
            $remark = 'Settle repair - ' . $g . ' ' . substr((string)$b['bet_content'], 0, 20) . ' result ' . $prem;
            $type = $delta >= 0 ? 'GameWin' : 'GameLose';
            $amt = abs($delta); $back = 0.0; $vendor = 'ARLottery';
            $stmt = $conn->prepare('INSERT IGNORE INTO financial_records(user_id, record_no, order_no, vendor_code, type, amount, back_amount, remark, created_at) VALUES(?,?,?,?,?,?,?,?,NOW())');
            $stmt->bind_param('issssdds', $b['user_id'], $rec, (string)$b['order_no'], $vendor, $type, $amt, $back, $remark);
            @$stmt->execute();
        }
        if (count($details) < 12) {
            $details[] = $b['issue_number'] . ' [' . substr((string)$b['bet_content'], 0, 14) . '] p=' . $prem
                . ' ' . ((int)$b['state'] === 1 ? 'WIN' : 'LOSE') . '->' . ($isWin ? 'WIN' : 'LOSE')
                . ' net ' . $b['win_lose_amount'] . '->' . $net . ' wallet ' . ($delta >= 0 ? '+' : '') . $delta;
        }
        $fixed++;
    }
}
echo "\nchecked: $checked   fixed: $fixed\n";
foreach ($details as $d) { echo "  $d\n"; }
echo "\nDONE ✅ — app refresh karke My History dekh.\n";
