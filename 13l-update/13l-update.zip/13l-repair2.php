<?php
// =====================================================================
// 13L REPAIR v2 — BigSmall flip ke baad sab settled bets ko OFFICIAL
// result ke against dobara recalculate karti hai (naye parser se),
// galat state/amount theek + wallet delta + statement entry.
// URL: https://13l.club9.eu.cc/13l-repair2.php?key=13l2026
// Ek baar kholo; output ka screenshot developer ko bhejo; phir file
// delete kar dena.
// =====================================================================

if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }

require_once __DIR__ . '/api/_core/bootstrap.php';
$conn = db();
$R = ['ok' => false];
if (!$conn) { echo json_encode(['error' => 'DB fail']); exit; }

$parserFix = (strpos((string)@file_get_contents(__DIR__ . '/api/_core/lottery_engine.php'), 'BigSmall_(big|small)') !== false) ? 'yes' : 'NO — naya lottery_engine.php deploy nahi hua! repair pehle zip extract karo';
$R['engine_has_choice_fix'] = $parserFix;
if ($parserFix !== 'yes') { echo json_encode($R, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES); exit; }

// 1) pending bets (closed periods) settle karo
foreach (['WinGo_30S','WinGo_1M','WinGo_3M','WinGo_5M','TrxWinGo_1M'] as $g) @le_settle_pending_bets($g);

// 2) sab settled bets (7 din) recalculate against lottery_results
$rs = $conn->query(
    "SELECT b.id, b.user_id, b.order_no, b.game_code, b.issue_number, b.bet_content,
            b.real_amount, b.fee, b.state, b.premium AS bet_premium, b.win_lose_amount,
            r.premium AS good_premium
     FROM lottery_bets b
     JOIN lottery_results r ON r.game_code = b.game_code AND r.issue_number = b.issue_number
     WHERE b.state IN (0,1) AND b.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
     LIMIT 2000"
);
$checked = 0; $fixed = 0; $details = [];
if ($rs) {
    while ($b = $rs->fetch_assoc()) {
        $checked++;
        $g = (string)$b['game_code'];
        $result = le_result_detail($g, (string)$b['good_premium'], (string)$b['issue_number']);
        $choice = le_extract_choice($g, (string)$b['bet_content']);
        $settings = le_get_settings($g);
        $isWin = le_result_matches($choice, $result, $g);
        $rate = le_payout_rate($g, $choice, $settings);
        $stake = (float)$b['real_amount'];
        $fee = (float)$b['fee'];
        $payout = $isWin ? round(max(0.0, $stake - $fee) * $rate, 2) : 0.0;
        $net = round($payout - $stake, 2);
        $wantState = $isWin ? 1 : 0;
        if ((int)$b['state'] === $wantState && abs((float)$b['win_lose_amount'] - $net) < 0.01) continue;

        $stmt = $conn->prepare('UPDATE lottery_bets SET premium=?, state=?, win_lose_amount=? WHERE id=?');
        $prem = (string)$result['premium'];
        $stmt->bind_param('sidi', $prem, $wantState, $net, $b['id']);
        if (!$stmt->execute()) continue;

        $oldNet = (float)$b['win_lose_amount'];
        $delta = round($net - $oldNet, 2);
        if (abs($delta) >= 0.01) {
            $stmt = $conn->prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
            $stmt->bind_param('di', $delta, $b['user_id']);
            @$stmt->execute();
            $rec = (string)$b['order_no'] . 'R2' . $b['id'];
            $remark = 'BigSmall fix — ' . $g . ' ' . $b['bet_content'] . ' result ' . $prem;
            $type = $delta >= 0 ? 'GameWin' : 'GameLose';
            $amt = abs($delta); $back = 0.0; $vendor = 'ARLottery';
            $stmt = $conn->prepare('INSERT IGNORE INTO financial_records(user_id, record_no, order_no, vendor_code, type, amount, back_amount, remark, created_at) VALUES(?,?,?,?,?,?,?,?,NOW())');
            $stmt->bind_param('issssdds', $b['user_id'], $rec, (string)$b['order_no'], $vendor, $type, $amt, $back, $remark);
            @$stmt->execute();
        }
        if (count($details) < 12) {
            $details[] = $b['issue_number'] . ' [' . substr((string)$b['bet_content'], 0, 14) . '] result=' . $prem
                . ' ' . ((int)$b['state'] === 1 ? 'WIN' : 'LOSE') . '->' . ($isWin ? 'WIN' : 'LOSE')
                . ' net ' . $oldNet . '->' . $net . ' wallet ' . ($delta >= 0 ? '+' : '') . $delta;
        }
        $fixed++;
    }
}
$R['ok'] = true;
$R['bets_checked'] = $checked;
$R['bets_fixed'] = $fixed;
$R['fix_details'] = $details;
$R['note'] = 'Ab naye bets sahi settle honge; purane bhi theek. Game refresh karke ek Big bet test karo.';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
echo json_encode($R, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
