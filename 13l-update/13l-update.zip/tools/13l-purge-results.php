<?php
// ONE-SHOT PURGE — clear pre-patch RANDOM lottery results so the shared
// deterministic (DhaniWin-style crc32) engine takes over for every period.
// Old rows were generated with random_int() before the patch and the engine
// gives DB rows priority, so they must be wiped once.
// Run: https://yourdomain.com/tools/13l-purge-results.php?key=13lpurge2026
// THEN DELETE THIS FILE.

if (($_GET['key'] ?? '') !== '13lpurge2026') {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'wrong key']);
    exit;
}

require_once __DIR__ . '/../api/_core/config.php';

$out = ['ok' => false, 'deleted' => 0, 'left' => -1, 'games' => []];
$mysqli = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_errno) {
    $out['error'] = 'db connect failed: ' . $mysqli->connect_error;
    header('Content-Type: application/json');
    echo json_encode($out);
    exit;
}

$rs = $mysqli->query('SELECT COUNT(*) c FROM lottery_results');
if ($rs) {
    $out['deleted'] = (int)$rs->fetch_assoc()['c'];
}
if ($mysqli->query('DELETE FROM lottery_results')) {
    $rs2 = $mysqli->query('SELECT COUNT(*) c FROM lottery_results');
    $out['left'] = $rs2 ? (int)$rs2->fetch_assoc()['c'] : -1;
    $out['ok'] = ($out['left'] === 0);
} else {
    $out['error'] = 'delete failed: ' . $mysqli->error;
}

// Seed nothing else — next API call regenerates every visible period
// deterministically (same digits as the DhaniWin engine).
header('Content-Type: application/json');
echo json_encode($out);
