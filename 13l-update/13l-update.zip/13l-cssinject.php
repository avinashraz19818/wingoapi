<?php
// =====================================================================
// 13L CSS INJECTOR v14 — overlay.css ki taqat wapas, bina index.html
// chhue. Ye marker ke saath SAARE theme css files ke END me append karta
// hai: (a) 13l-overlay.css ka poora content (purane mobile fixes), (b)
// My-History list ke liye un-clip + readable-text rules (embedded tab me
// rows kat rahi thi / teesri row ka period invisible tha).
// Idempotent: dobara chalane par duplicate nahi judega.
// URL: https://13l.club9.eu.cc/13l-cssinject.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
header('Content-Type: text/plain; charset=utf-8');
$ROOT = rtrim(__DIR__, '/');
$MARKER = '13L-INJECT-v14';

$overlay = (string)@file_get_contents($ROOT . '/css/13l-overlay.css');

$extra = "\n\n/* ===== {$MARKER}: history un-clip + readable rows ===== */\n"
    . ".my_r,.my\\_r,.my_r-body,.my\\_r-body,"
    . ".MyGameRecord__C,.MyGameRecord\\_\\_C,.MyGameRecord__C-body,.MyGameRecord\\_\\_C-body,"
    . ".my_r-body .list{height:auto!important;max-height:none!important;overflow:visible!important}\n"
    . ".my_r-body .list-item{height:auto!important;min-height:1.55rem;box-sizing:border-box;padding:.10rem 0}\n"
    . ".my_r-body .list-item-m-top,.MyGameRecord__C-body .list-item-m-top{color:#fff!important}\n"
    . ".my_r-body .list-item-m-bottom,.MyGameRecord__C-body .list-item-m-bottom{color:#9a9a9a!important}\n"
    /* purane overlay fixes ka fallback: chip row + balls kabhi clip na hon */
    . ".mutiplyContent,.radioContent{flex-wrap:wrap!important}\n"
    /* overlay.css ka poora content bhi same file me daal dete hain (link missing hai index me) */
    . (($overlay !== '' && strpos($overlay, $MARKER) === false) ? "\n/* ===== overlay.css copy ===== */\n" . $overlay : "");

// targets: index.html ke <link rel=stylesheet> + css/ dir ke saare files
$html = (string)@file_get_contents($ROOT . '/index.html');
$targets = [];
if (preg_match_all('#<link[^>]+href="([^"]+\.css[^"]*)"#i', $html, $mm)) {
    foreach ($mm[1] as $h) {
        $p = parse_url($h);
        $path = $p['path'] ?? '';
        if ($path !== '' && strpos($path, '..') === false) { $targets[] = $ROOT . $path; }
    }
}
foreach (glob($ROOT . '/css/*.css') ?: [] as $g) $targets[] = $g;
$targets = array_values(array_unique($targets));

$done = []; $skipped = [];
foreach ($targets as $f) {
    $bn = basename($f);
    if ($bn === '13l-overlay.css') { continue; }
    if (!is_file($f) || !is_writable($f)) { $skipped[] = $bn . ' (missing/nowrite)'; continue; }
    if (filesize($f) > 3000000) { $skipped[] = $bn . ' (too big)'; continue; }
    $c = (string)file_get_contents($f);
    if (strpos($c, $MARKER) !== false) { $skipped[] = $bn . ' (already injected)'; continue; }
    @copy($f, $f . '.bak13l'); // ek baar backup
    if (@file_put_contents($f, $c . $extra) !== false) { $done[] = $bn; }
    else { $skipped[] = $bn . ' (write fail)'; }
}
echo "CSS inject v14\n";
echo "updated (" . count($done) . "):\n  " . implode("\n  ", $done ?: ['(none)']) . "\n";
echo "skipped (" . count($skipped) . "):\n  " . implode("\n  ", $skipped ?: ['(none)']) . "\n";
echo "\nDONE ✅ — app ko puri tarah band karke (recent se swipe) dobara khol → My history scroll karke dekh.\n";
echo "Rollback chahiye to: har file ka .bak13l copy hai, ya inject block marker se delete kar dena.\n";
