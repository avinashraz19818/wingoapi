<?php
// =====================================================================
// 13L ROWS v21 — VERIFICATION DUMP (kuch nahi badalta, sirf dikhata hai):
//  A) demo user ki last 12 bets: DB raw + exact API row jo skin ko milti hai
//     (issueNumber/betTime/betContent/premium present? per-row tick)
//  B) Game history (chart source) ka pehla 5-row sample, same checks
//  C) Installed-markers: entry JS (v16/v17/v19), theme css (v14), restore
//  D) .netlog tail (app live fetch kar raha ya cache de raha hai)
// URL: https://13l.club9.eu.cc/13l-rows.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
error_reporting(E_ALL & ~E_DEPRECATED); @ini_set('display_errors', '1');
header('Content-Type: text/plain; charset=utf-8');
$R = rtrim(__DIR__, '/');
require_once $R . '/api/_core/bootstrap.php';

echo "=== ROWS v21 VERIFY ===\n\n";

// ---- A) my-history rows, exactly as API sends ----
$conn = function_exists('db') ? db() : null;
echo "--- A) My history (last 12 bets of uid 117224), RAW -> API row ---\n";
if (!$conn) echo "DB connect FAIL\n";
else {
    $res = $conn->query('SELECT * FROM lottery_bets WHERE user_id=117224 ORDER BY id DESC LIMIT 12');
    $n = 0;
    while ($r = $res->fetch_assoc()) {
        $n++;
        $row = function_exists("bet_row_response") ? bet_row_response($r) : le_response_row($r);
        $chk = [];
        $chk[] = 'issue:' . (strlen((string)$row['issueNumber']) >= 17 ? 'OK' : 'BAD(' . $row['issueNumber'] . ')');
        $chk[] = 'betC:' . (preg_match('/_/', (string)$row['betContent']) ? 'OK' : 'BAD(' . $row['betContent'] . ')');
        $chk[] = 'betTime:' . ($row['betTime'] > 1600000000000 ? 'OK' : 'BAD(' . $row['betTime'] . ')');
        $chk[] = 'prem:' . (trim((string)$row['premium']) !== '' ? 'OK' : 'EMPTY');
        $numB = (int)preg_match('/\d/', (string)$row['betContent']) || preg_match('/Number|Num_/', (string)$row['betContent']);
        echo str_pad("#{$n} " . ($row['issueNumber'] ?: '?'), 24) . str_pad(substr((string)$r['bet_content'], 0, 18), 20)
           . ' raw.created=' . ($r['created_at'] ?: 'NULL') . "\n   " . implode(' | ', $chk) . "\n";
    }
    echo "rows: {$n}\n";
}

// ---- B) game history sample ----
echo "\n--- B) Game history sample (WinGo_30S, what chart/Game-history tab gets) ---\n";
for ($i = 2; $i <= 6; $i++) {
    $issue = le_issue_by_offset('WinGo_30S', $i);
    $rr = le_result_for_issue('WinGo_30S', $issue, false);
    echo str_pad($issue, 22) . ' number=' . $rr['number'] . ' color=' . $rr['color'] . ' bs=' . $rr['bigSmall'] . ' prem=' . (trim((string)$rr['premium']) !== '' ? 'yes' : 'EMPTY') . "\n";
}

// ---- C) markers ----
echo "\n--- C) installed markers ---\n";
$entry = null;
$html = (string)@file_get_contents($R . '/index.html');
if (preg_match('#<script[^>]+src="(/js/index-[\w\-]+\.js)"#i', $html, $m)) $entry = $R . $m[1];
if (!$entry) { $g = glob($R . '/js/index-*.js'); $entry = $g[0] ?? null; }
if ($entry && is_file($entry)) {
    $c = (string)file_get_contents($entry);
    $bn = basename($entry);
    echo "entry js: {$bn} (" . filesize($entry) . " B)\n";
    echo "  v16 cache-clear : " . (strpos($c, '13L-JSINJECT-v16') !== false ? 'YES' : 'no') . "\n";
    echo "  v17 watchdog    : " . (strpos($c, '13L-UNCLIP-v17') !== false ? 'YES' : 'no') . "\n";
    echo "  v19 unstuck     : " . (strpos($c, '13L-V19-UNSTUCK') !== false ? 'YES' : 'NO — 13l-v19.php kholo') . "\n";
} else echo "entry js NOT FOUND — restore adhoora?\n";
$files = glob($R . '/css/*.css') ?: [];
$n14 = 0; $n18 = 0;
foreach ($files as $f) { $cc = (string)@file_get_contents($f); if (strpos($cc, '13L-INJECT-v14') !== false) $n14++; if (strpos($cc, '13L-CSS-v18') !== false) $n18++; }
echo "theme css: v14 {$n14}/" . count($files) . " · v18 {$n18}/" . count($files) . "\n";
echo "index.html: " . filesize($R . '/index.html') . " B" . (is_file($R . '/index.html.bakskin') ? " (bakskin present)" : "") . "\n";

// ---- D) netlog tail ----
echo "\n--- D) app requests (last 8) ---\n";
$log = $R . '/api/_core/.netlog';
if (is_file($log)) {
    foreach (array_slice(file($log), -8) as $l) {
        $j = json_decode(trim((string)$l), true);
        if ($j) echo ($j['t'] ?? '') . '  ' . ($j['ep'] ?? '') . '  ' . ($j['g'] ?? '') . '  rows=' . ($j['rows'] ?? '?') . '  total=' . ($j['total'] ?? '-') . "\n";
    }
} else echo "(no log)\n";
echo "\nend.\n";
