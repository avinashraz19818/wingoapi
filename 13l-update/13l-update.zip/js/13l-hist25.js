/* 13L-HIST25-v38: native per-game rows; stop hide/fill race; scoped layout */
(function(){
  'use strict';
  var lastPing={},pending=false;
  var style=document.createElement('style');style.id='13l-history38';
  style.textContent="/* Poppins font files from DhaniWin; SIL OFL 1.1, full license in README-13L.txt. */\n/* 13L-PATCH25-v31: targeted DhaniWin/native history layout.\n   The legacy limitHistory timers hide nested cells, not only rows.\n   Explicit display rules win BEFORE paint; no text rewriting / all-game filler.\n   No home, header, betting panel, empty-state or unopened-detail selectors. */\nhtml[data-13l-history=\"1\"] .my_r,\nhtml[data-13l-history=\"1\"] .my_r-body,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C-body,\nhtml[data-13l-history=\"1\"] .my_r-body .list,\nhtml[data-13l-history=\"1\"] .history .t,\nhtml[data-13l-history=\"1\"] .history .t-b2,\nhtml[data-13l-history=\"1\"] .history .record-body {\n  height:auto!important;max-height:none!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list > div {\n  display:block!important;visibility:visible!important;max-height:none!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item {\n  display:flex!important;align-items:center;gap:0;\n  height:auto!important;min-height:1.76rem;box-sizing:border-box;\n  padding:0!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l > div {\n  display:block!important;visibility:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l {\n  flex:0 0 .96rem;width:.96rem!important;height:.96rem!important;\n  line-height:.96rem!important;border-radius:.26667rem!important;\n  margin-right:.29333rem!important;overflow:hidden!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m {\n  display:block!important;visibility:visible!important;\n  flex:1 1 auto!important;min-width:0;height:auto!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top {\n  display:flex!important;align-items:center;visibility:visible!important;\n  height:auto!important;min-height:.56rem;line-height:.56rem!important;\n  font-size:.37333rem!important;font-weight:500;overflow-wrap:anywhere;\n  color:var(--text_color_L1,#fff)!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top > svg {flex:none;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-bottom {\n  display:block!important;visibility:visible!important;\n  height:auto!important;line-height:.48rem!important;font-size:.32rem!important;\n  overflow-wrap:anywhere;color:var(--text_secondary,#9a9a9a)!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r {\n  display:flex!important;visibility:visible!important;flex:0 1 auto!important;max-width:30%;font-size:.32rem!important;\n  min-width:0;height:auto!important;align-items:flex-end;flex-direction:column;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > span {\n  display:block!important;height:auto!important;max-width:100%;box-sizing:border-box;\n  line-height:.64rem!important;overflow-wrap:anywhere;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div:first-child {padding:0 .48rem!important;font-size:.29333rem!important;line-height:.48rem!important;}\n/* Native chart nodes, not a text search for a particular year/translation. */\nhtml[data-13l-history=\"1\"] .history .t-b2 > .t-b2-item {\n  display:block!important;visibility:visible!important;box-sizing:border-box;\n  height:1.33333rem!important;min-height:1.33333rem;max-height:none!important;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-i {\n  display:block!important;font-size:.32rem!important;\n  white-space:nowrap;letter-spacing:normal;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-Num {\n  display:flex!important;min-width:0;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-Num > div {\n  display:block!important;flex-shrink:1;box-sizing:border-box;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-item .van-col {min-width:0;}\nhtml[data-13l-history=\"1\"] .history .t-b1-l-n {min-width:0;}\nhtml[data-13l-history=\"1\"] .history .record-body > .van-row {display:flex!important;}\n/* Legacy selector also counts the van-row INSIDE every chart row. */\nhtml[data-13l-history=\"1\"] .history .t-b2-item > .van-row {display:flex!important;}\n\n/* v31: native/DhaniWin typography; inherited 13L font and palette stay intact. */\nhtml[data-13l-history=\"1\"] .my_r-foot-page,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C-foot-page,\nhtml[data-13l-history=\"1\"] .history .t-foot-page {font-size:.32rem!important;}\n\n/* 13L-FONT31: Actual DhaniWin Poppins faces, scoped to history UI only.\n   Body/home/header stay untouched; icon glyphs keep their own icon font. */\nhtml[data-13l-history=\"1\"] .history,\nhtml[data-13l-history=\"1\"] .my_r,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l > div,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-bottom,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > span,\nhtml[data-13l-history=\"1\"] .my_r-foot-page,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C-foot-page,\nhtml[data-13l-history=\"1\"] .history .t-b2-i {\n  font-family:\"13L History Poppins\",Poppins,Arial,sans-serif!important;\n  font-style:normal; font-synthesis:weight;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l > div {\n  width:100%!important;height:100%!important;border-radius:inherit!important;\n  overflow:hidden!important;display:block!important;text-align:center;\n}\n/* Exact native/DhaniWin box and text metrics (root 40px => 38.4px box / 10.67px radius). */\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l {font-size:.64rem;font-weight:400;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l-big,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l-small,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l-Big,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l-Small {\n  font-size:.32rem!important;font-weight:400!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top {font-weight:500!important;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-bottom,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r {font-weight:400!important;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div:first-child {\n  border-radius:.13333rem!important;margin-bottom:.08rem;\n  font-weight:400!important;\n}\n\n/* 13L-TOP32: screenshot reference. WinGo route ONLY, not home/other games.\n   Removes the red Wallet::before backdrop, not the wallet or live timer.\n   No timer text, values, issue, event handlers, countdown/settlement changes. */\nhtml[data-13l-wingo-ui=\"1\"] .game-header,\nhtml[data-13l-wingo-ui=\"1\"] .winGo3,\nhtml[data-13l-wingo-ui=\"1\"] #wingo {background:#282828!important;}\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C {background:transparent!important;}\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C::before {\n  content:none!important;display:none!important;background:none!important;\n}\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance {\n  background:#3b3b3b!important;border-radius:.53333rem!important;\n}\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance,\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance-l1,\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance-l2,\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance-l3 > div,\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C,\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-rule,\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-name,\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-text,\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-id,\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-time > div {\n  font-family:\"13L History Poppins\",Poppins,Arial,sans-serif!important;\n  font-style:normal;\n}\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance-l1 {color:#fff!important;font-weight:700;}\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance-l2 {color:#fff!important;}\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance-l3 > div:first-child {background:#ff5360!important;}\nhtml[data-13l-wingo-ui=\"1\"] .Wallet__C-balance-l3 > div + div {background:#12b965!important;}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C {\n  background-color:transparent!important;background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20400%20114%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x2%3D%220%22%20y2%3D%221%22%3E%3Cstop%20stop-color%3D%22%23f33443%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%23cd1630%22%2F%3E%3C%2FlinearGradient%3E%3Cmask%20id%3D%22m%22%3E%3Crect%20width%3D%22400%22%20height%3D%22114%22%20rx%3D%2211%22%20fill%3D%22white%22%2F%3E%3Ccircle%20cx%3D%22200%22%20cy%3D%220%22%20r%3D%228%22%20fill%3D%22black%22%2F%3E%3Ccircle%20cx%3D%22200%22%20cy%3D%22114%22%20r%3D%228%22%20fill%3D%22black%22%2F%3E%3C%2Fmask%3E%3C%2Fdefs%3E%3Cg%20mask%3D%22url%28%23m%29%22%3E%3Crect%20width%3D%22400%22%20height%3D%22114%22%20fill%3D%22url%28%23g%29%22%2F%3E%3Cpath%20d%3D%22M200%2015V99%22%20stroke%3D%22white%22%20stroke-opacity%3D%22.32%22%20stroke-width%3D%221%22%20stroke-dasharray%3D%224%204%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E\")!important;\n  background-size:100% 100%!important;background-position:center!important;\n  background-repeat:no-repeat!important;color:#fff!important;\n}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-rule {\n  color:#fff!important;border:1px solid rgba(255,255,255,.4)!important;\n  max-width:calc(50% - .58667rem);box-sizing:border-box;\n}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-rule svg {color:#fff!important;}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-name {color:#fff!important;font-weight:400;}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-text {\n  color:#fff!important;font-size:.32rem!important;font-weight:700!important;\n}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-id {\n  color:#fff!important;font-size:.37333rem!important;font-weight:700!important;\n}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-time {height:.8rem!important;line-height:.8rem!important;}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-time > div {\n  background:#fff!important;color:#b51b32!important;font-size:.53333rem!important;\n  font-weight:700!important;font-variant-numeric:tabular-nums;\n  width:.53333rem!important;height:.8rem!important;line-height:.8rem!important;\n  padding:0!important;text-align:center;box-sizing:border-box;\n}\nhtml[data-13l-wingo-ui=\"1\"] .TimeLeft__C-time > div:nth-child(3) {width:.4rem!important;}\n\n/* 13L-BACKDROP33: native lottery-info has a separate 9rem red .bg div.\n   Wallet::before is already disabled by this native skin; v32 missed .bg.\n   Hide ONLY the direct decorative child on WinGo, not wallet/header content. */\nhtml[data-13l-wingo-ui=\"1\"] .lottery-info {background:#282828!important;}\nhtml[data-13l-wingo-ui=\"1\"] .lottery-info > .bg {\n  display:none!important;background:none!important;\n}\n\n/* 13L-HEADER35: reference logo size and functional header controls, WinGo only. */\nhtml[data-13l-wingo-ui=\"1\"] .game-header > .head-right {display:none!important;}\nhtml[data-13l-wingo-ui=\"1\"] .game-header img.logo {object-fit:contain!important;}\nhtml[data-13l-wingo-ui=\"1\"] .header-controls35 {\n  position:absolute;right:.34667rem;top:50%;transform:translateY(-50%);\n  display:flex;align-items:center;gap:.13333rem;z-index:12;\n}\nhtml[data-13l-wingo-ui=\"1\"] .header-controls35 button {\n  display:flex;align-items:center;justify-content:center;width:.85333rem;height:.96rem;\n  padding:.08rem;border:0;border-radius:.13333rem;background:transparent;color:#fff;cursor:pointer;\n}\nhtml[data-13l-wingo-ui=\"1\"] .header-controls35 button svg {width:.64rem;height:.64rem;display:block;}\nhtml[data-13l-wingo-ui=\"1\"] .header-controls35 button:focus-visible {outline:2px solid #fff;outline-offset:1px;}\nhtml[data-13l-wingo-ui=\"1\"] .header-controls35 button:disabled {opacity:.45;cursor:default;}\nhtml[data-13l-wingo-ui=\"1\"] .header-voice35[aria-pressed=\"true\"] .mute-line35 {display:none;}\n\n/* 13L-SWITCH36: only uninitialised/switched-game values get placeholders.\n   Valid live zero at an actual round boundary remains visible. No fake time. */\nhtml[data-13l-wingo-ui=\"1\"][data-13l-timer-ready=\"0\"] .TimeLeft__C-time > div:not(:nth-child(3)) {\n  color:transparent!important;position:relative;\n}\nhtml[data-13l-wingo-ui=\"1\"][data-13l-timer-ready=\"0\"] .TimeLeft__C-time > div:not(:nth-child(3))::after {\n  content:\"–\";position:absolute;inset:0;color:#b51b32;text-align:center;\n  font:inherit;line-height:inherit;\n}\nhtml[data-13l-wingo-ui=\"1\"][data-13l-timer-ready=\"0\"] .TimeLeft__C-id {visibility:hidden;}\n\n/* 13L-LOADING37: pending game data is not a closing countdown.\n   Keep the native blocking overlay; only replace its uninitialised digit tiles.\n   Valid closing 05..00 and native v-show/canBet remain entirely native. */\nhtml[data-13l-wingo-ui=\"1\"][data-13l-timer-ready=\"0\"] .winGo3 .Betting__C-mark > div {\n  visibility:hidden!important;\n}\nhtml[data-13l-wingo-ui=\"1\"][data-13l-timer-ready=\"0\"] .winGo3 .Betting__C-mark::before {\n  content:\"\";position:absolute;left:calc(50% - .24rem);top:calc(50% - .56rem);\n  width:.48rem;height:.48rem;box-sizing:border-box;border:.06rem solid #ffffff40;\n  border-top-color:#fff;border-radius:50%;animation:loading37 .85s linear infinite;\n  pointer-events:none;\n}\nhtml[data-13l-wingo-ui=\"1\"][data-13l-timer-ready=\"0\"] .winGo3 .Betting__C-mark::after {\n  content:\"Loading game…\";position:absolute;left:0;right:0;top:calc(50% + .14rem);\n  color:#fff;font-family:inherit;font-size:.32rem;font-weight:500;\n  line-height:1.5;text-align:center;pointer-events:none;\n}\n@keyframes loading37 {to{transform:rotate(360deg)}}\n@media(prefers-reduced-motion:reduce){\n  html[data-13l-wingo-ui=\"1\"][data-13l-timer-ready=\"0\"] .winGo3 .Betting__C-mark::before {animation:none;}\n}\n\n/* 13L-ART38: original missing native win artwork restored by installer.\n   Versioned URL bypasses a cached404; no layout/result/lose-popup changes. */\nhtml[data-13l-wingo-ui=\"1\"] .winning-body.isWin[data-v-a91426ba] {\n  background-image:url(\"/images/missningBg-CVBJxzJu.webp?art=38\")!important;\n}\n";
  document.head.appendChild(style);
  function gamePage(){return /(?:wingo|mygamerecord|myhistory)/i.test(location.pathname);}
  // Warm the original local artwork before the first real winning popup.
  var winArt38=null;
  function popupArt38(){
    if(winArt38||!/^\/WinGo\//i.test(location.pathname))return;
    winArt38=new Image();
    winArt38.onload=function(){ping('art38 '+activeGame()+' loaded=1','size='+this.naturalWidth+'x'+this.naturalHeight);};
    winArt38.onerror=function(){ping('art38 '+activeGame()+' loaded=0');};
    winArt38.src='/images/missningBg-CVBJxzJu.webp?art=38';
  }
  function gate(){
    var value=gamePage()?'1':'0';
    if(document.documentElement.getAttribute('data-13l-history')!==value)
      document.documentElement.setAttribute('data-13l-history',value);
    var topValue=/^\/WinGo\//i.test(location.pathname)?'1':'0';
    if(document.documentElement.getAttribute('data-13l-wingo-ui')!==topValue)
      document.documentElement.setAttribute('data-13l-wingo-ui',topValue);
    headerUI35();timerPaint36();popupArt38();
  }
  function ping(msg,geometry){
    if(!gamePage())return;
    var key=/^(switch37|overlay37|ui36|audio36) /.test(msg)?msg:msg.split(' ').slice(0,2).join(' '),now=Date.now();
    if(lastPing[key]&&now-lastPing[key]<20000)return;lastPing[key]=now;
    fetch('/api/_router.php?path=Site/OverlayPing',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({msg:msg,dom:geometry||''})
    }).catch(function(){});
  }
  function shown(el){
    if(!el)return false;
    var r=el.getBoundingClientRect(),cs=getComputedStyle(el);
    return r.width>0&&r.height>0&&cs.visibility!=='hidden'&&cs.display!=='none';
  }
  function inspect(){
    if(!gamePage()||document.hidden)return;
    if(/^\/WinGo\//i.test(location.pathname)){
      var lock37=document.querySelector('.winGo3 .Betting__C-mark');
      if(lock37)ping('overlay37 '+activeGame()+' pending='+(document.documentElement.getAttribute('data-13l-timer-ready')==='0'?1:0),
        'lockShown='+(shown(lock37)?1:0)+';visibleDigits='+Array.from(lock37.children).filter(shown).length);
    }
    var ticket=document.querySelector('.TimeLeft__C'),wallet=document.querySelector('.Wallet__C');
    if(ticket&&shown(ticket)){
      var cell=ticket.querySelector('.TimeLeft__C-time > div'),label=ticket.querySelector('.TimeLeft__C-text');
      if(cell&&label){
        var cs=getComputedStyle(cell),ls=getComputedStyle(label),back=wallet?getComputedStyle(wallet,'::before').display:'missing';
        var bg=document.querySelector('.lottery-info > .bg'),info=document.querySelector('.lottery-info'),card=document.querySelector('.Wallet__C-balance');
        ping('top33 '+activeGame()+' redLayer='+back+' infoBG='+(bg?getComputedStyle(bg).display:'missing'),
          'cell='+cs.backgroundColor+'/'+cs.color+';font='+cs.fontFamily+';size='+cs.fontSize+';weight='+cs.fontWeight+';label='+ls.color+';surface='+(info?getComputedStyle(info).backgroundColor:'missing')+';wallet='+(card?getComputedStyle(card).backgroundColor:'missing'));
      }
    }
    var lists=document.querySelectorAll('.my_r-body .list');
    for(var j=0;j<lists.length;j++){
      if(!shown(lists[j]))continue;
      var rows=lists[j].querySelectorAll('.list-item'),ok=0,hidden=0,blank=0;
      for(var i=0;i<rows.length;i++){
        var top=rows[i].querySelector('.list-item-m-top');
        var bot=rows[i].querySelector('.list-item-m-bottom');
        var chip=rows[i].querySelector('.list-item-l');
        if(!shown(rows[i])||!shown(top)||!shown(bot)||!shown(chip))hidden++;
        else if(!/20[0-9]{15}/.test(top.textContent)||!bot.textContent.trim()||/Invalid/.test(bot.textContent))blank++;
        else ok++;
      }
      var sample=rows[0],box=sample&&sample.querySelector('.list-item-l'),title=sample&&sample.querySelector('.list-item-m-top');
      if(box&&title){
        var rect=box.getBoundingClientRect(),bc=getComputedStyle(box),tc=getComputedStyle(title);
        var fontReady=document.fonts&&Array.from(document.fonts).some(function(f){return f.family.replace(/['"]/g,'')==='13L History Poppins'&&f.status==='loaded';});
        ping('font31 '+activeGame()+' ready='+(fontReady?1:0),
          'family='+tc.fontFamily+';period='+tc.fontSize+';weight='+tc.fontWeight+';box='+Math.round(rect.width*10)/10+'x'+Math.round(rect.height*10)/10+';radius='+bc.borderRadius);
      }
      var expected=activeGame(),prefixMap={WinGo_30S:'10005',WinGo_1M:'10001',WinGo_3M:'10002',WinGo_5M:'10003',WinGo_10M:'10004'},wrong=0;
      for(var z=0;z<rows.length;z++){var text=rows[z].querySelector('.list-item-m-top');var match=text&&(text.textContent||'').match(/20[0-9]{15}/);if(match&&prefixMap[expected]&&match[0].slice(8,13)!==prefixMap[expected])wrong++;}
      ping('history31 '+expected+' rows='+rows.length+' wrong='+wrong+' hidden='+hidden+' blank='+blank,
        'font='+getComputedStyle(lists[j].querySelector('.list-item-m-top')||lists[j]).fontSize+';viewport='+innerWidth);
    }
    var charts=document.querySelectorAll('.history .t-b2');
    for(var c=0;c<charts.length;c++){
      if(!shown(charts[c]))continue;
      var cr=charts[c].querySelectorAll(':scope > .t-b2-item'),visible=0,clipped=0;
      for(var k=0;k<cr.length;k++){
        if(!shown(cr[k]))continue;visible++;
        var r=cr[k].getBoundingClientRect();
        for(var a=cr[k].parentElement;a&&a!==document.body;a=a.parentElement){
          var s=getComputedStyle(a),box=a.getBoundingClientRect();
          if(/hidden|clip/.test(s.overflowY)&&(r.bottom>box.bottom+2||r.top<box.top-2)){clipped++;break;}
        }
      }
      ping('chart31 '+activeGame()+' rows='+cr.length+' visible='+visible+' clip='+clipped,
        'viewport='+innerWidth+';container='+charts[c].clientHeight+';scroll='+charts[c].scrollHeight);
    }
  }
  // v34: Native composable adapter. No DOM period/result writes or guessed draws.
  // Readiness is supplied by the native v34 round adapter, never guessed from 00.
  var timerSource36=null,soundSource36=null;
  function timerPaint36(){
    var ready=!!(timerSource36&&timerSource36()),value=ready?'1':'0';
    if(document.documentElement.getAttribute('data-13l-timer-ready')!==value){
      document.documentElement.setAttribute('data-13l-timer-ready',value);
      if(/^\/WinGo\//i.test(location.pathname))ping('switch37 '+activeGame()+' ready='+value);
    }
    document.querySelectorAll('.TimeLeft__C-time,.Betting__C-mark').forEach(function(el){
      if(document.documentElement.getAttribute('data-13l-wingo-ui')!=='1'){el.removeAttribute('aria-busy');return;}
      el.setAttribute('aria-busy',ready?'false':'true');
    });
  }

  window.__13lRound34=function(io){
    var code='',issue='',deadline=0,last=-1,dead=false,timer=null,busy=false;
    var retryAt=0,failures=0,historyAt=0,historyBusy=false,latest='',signature='',waiting='',notified='';
    var prefixes={WinGo_30S:'10005',WinGo_1M:'10001',WinGo_3M:'10002',WinGo_5M:'10003'};
    var ready36=function(){return !dead&&!!issue&&code===io.game()&&code===activeGame();};
    timerSource36=ready36;soundSource36=function(){return !dead&&io.game()===activeGame()?io.soundEffects:null;};timerPaint36();
    function valid(id,g){return /^\d{17}$/.test(String(id||''))&&String(id).slice(8,13)===prefixes[g];}
    function active(){return !dead&&!document.hidden&&/^\/WinGo\//i.test(location.pathname)&&!!prefixes[io.game()];}
    function event(kind){ping(kind+' '+code+' issue='+issue+' latest='+(latest||'none'),'left='+io.seconds()+';waiting='+(waiting||'none')+';failures='+failures);}
    function acceptIssue(data,g){
      if(dead||g!==io.game()||!valid(data.issueNumber,g))return false;
      var duration={WinGo_30S:30,WinGo_1M:60,WinGo_3M:180,WinGo_5M:300}[g];
      var left=Number(data.countdown);
      if(Number.isFinite(+data.endTime)&&+data.__server34>0)left=(+data.endTime-+data.__server34)/1000;
      if(!Number.isFinite(left)||left>duration+5)return false;
      if(code===g&&issue&&data.issueNumber<issue)return false;
      data.__left34=Math.max(0,left);return true;
    }
    function received(data){
      var g=io.game(),previous=code===g?issue:'';
      if(code!==g){latest='';signature='';waiting='';notified='';io.rows([],0);}
      code=g;issue=String(data.issueNumber);deadline=performance.now()+data.__left34*1000;
      last=Math.max(0,Math.ceil(data.__left34));io.setSeconds(last);failures=0;timerPaint36();
      if(previous&&previous!==issue){waiting=previous;historyAt=0;event('roll34');}
      else if(!latest)historyAt=0;
    }
    function filter(rows,g){
      if(g!==io.game()||g!==code||!issue)return [];
      var seen=new Set();return (Array.isArray(rows)?rows:[]).filter(function(row){
        var id=String(row.issueNumber||''),num=String(row.number);
        if(!valid(id,g)||id>=issue||!/^\d$/.test(num)||seen.has(id)||(row.gameCode&&row.gameCode!==g))return false;
        seen.add(id);return true;
      }).sort(function(a,b){return String(b.issueNumber).localeCompare(String(a.issueNumber));});
    }
    function apply(rows,total,g){
      g=g||io.game();if(dead||code!==g||g!==io.game())return false;
      rows=filter(rows,g);if(!rows.length)return false;
      var first=String(rows[0].issueNumber);if(latest&&first<latest)return false;
      var sig=rows.map(function(r){return r.issueNumber+':'+r.number;}).join('|');
      if(signature!==sig){signature=sig;latest=first;io.rows(rows,total);}
      if(waiting&&first>=waiting){if(notified!==waiting){notified=waiting;io.notify();event('result34');}waiting='';}
      return true;
    }
    async function history(){
      if(!active()||code!==io.game()||!issue||historyBusy||performance.now()<historyAt)return;
      historyBusy=true;historyAt=performance.now()+(waiting?1000:5000);
      try{await io.history();}catch(e){}finally{historyBusy=false;}
    }
    async function tick(){
      if(!active())return;
      if(code&&code!==io.game()){code='';issue='';deadline=0;latest='';signature='';waiting='';io.setSeconds(0);io.rows([],0);retryAt=0;timerPaint36();}
      var now=performance.now();
      if(issue){var left=Math.max(0,Math.ceil((deadline-now)/1000));if(left!==last){last=left;io.setSeconds(left);if(left<=5)io.sound(left);}}
      if((!issue||now>=deadline)&&now>=retryAt&&!busy){
        busy=true;retryAt=now+1000;
        try{await io.issue();}catch(e){}finally{
          busy=false;if(performance.now()>=deadline){failures++;retryAt=performance.now()+Math.min(5000,1000*Math.max(1,failures));event('retry34');}
        }
      }
      await history();event('round34');
    }
    function start(){if(!timer&&!dead)timer=setInterval(function(){tick().catch(function(){});},250);}
    function stop(){dead=true;if(timer)clearInterval(timer);timer=null;if(timerSource36===ready36){timerSource36=null;soundSource36=null;}timerPaint36();}
    function visible(){if(!document.hidden){retryAt=0;historyAt=0;tick().catch(function(){});}}
    document.addEventListener('visibilitychange',visible);
    return {acceptIssue:acceptIssue,received:received,filter:filter,apply:apply,tick:tick,start:start,
      matches:function(g){return g===code&&!!issue;},stop:function(){stop();document.removeEventListener('visibilitychange',visible);}};
  };

  // v35 UI-only: label and header controls, using the native sound ref/router.
  var labels35=[],logos35=[];
  var headset35="<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"48\" height=\"48\" viewBox=\"0 0 48 48\" fill=\"none\">\n  <mask id=\"mask0_24395_6175\" style=\"mask-type:alpha\" maskUnits=\"userSpaceOnUse\" x=\"5\" y=\"5\" width=\"38\" height=\"39\">\n    <path d=\"M41.0282 19.3746C40.8298 15.4711 39.0607 11.8991 35.9953 9.24756C32.8244 6.50944 28.5642 5 24 5C19.4337 5 15.1756 6.50944 12.0047 9.24756C8.93933 11.8991 7.17022 15.4711 6.97178 19.3767C5.79589 20.0396 5 21.2978 5 22.7376V30.4473C5 32.5753 6.73111 34.3043 8.86333 34.3043C8.97311 34.3043 9.08289 34.3001 9.19056 34.2896V41.8896C9.19056 42.5039 9.68878 43.0021 10.3031 43.0021H37.7307C38.345 43.0021 38.8432 42.5039 38.8432 41.8896V34.2917C38.9403 34.3001 39.0374 34.3043 39.1388 34.3043C41.2668 34.3043 43 32.5732 43 30.4473V22.7376C43 21.2978 42.2041 20.0396 41.0282 19.3767V19.3746ZM13.4613 10.9301C16.2269 8.54033 19.9699 7.223 24 7.223C28.0322 7.223 31.7731 8.54033 34.5387 10.9301C36.9812 13.0412 38.4527 15.8363 38.7609 18.8974C38.1487 18.9587 37.5787 19.1613 37.0826 19.4717C35.5921 13.645 30.2911 9.32778 24 9.32778C17.7089 9.32778 12.4079 13.6471 10.9174 19.4717C10.4234 19.1613 9.85344 18.9587 9.24122 18.8974C9.54733 15.8363 11.0188 13.0412 13.4634 10.9301H13.4613ZM24 40.777C19.7081 40.777 15.9693 38.3703 14.0651 34.8363H18.4393V35.2396C18.4393 36.3437 19.3366 37.2409 20.4428 37.2409H27.5572C28.6634 37.2409 29.5628 36.3437 29.5628 35.2396V32.2122C29.5628 31.1081 28.6634 30.2109 27.5572 30.2109H20.4428C19.3366 30.2109 18.4372 31.1081 18.4372 32.2122V32.6133H13.1594C12.8766 31.6296 12.7246 30.5909 12.7246 29.5184V22.8093C12.7246 22.6468 12.7288 22.4842 12.7372 22.3238H26.375C26.7444 22.3238 27.0886 22.1422 27.2954 21.8382L28.7732 19.6638L30.2299 21.8319C30.4347 22.1401 30.783 22.3238 31.1546 22.3238H35.2649C35.2712 22.4842 35.2754 22.6468 35.2754 22.8093V29.5184C35.2754 35.7251 30.2172 40.777 24 40.777ZM20.6644 32.4339H27.3356V35.0179H20.6644V32.4339ZM13.056 20.1008C14.272 15.1967 18.718 11.5508 24 11.5508C29.282 11.5508 33.728 15.1967 34.944 20.1008H31.7478L29.7063 17.0566C29.5016 16.7504 29.1553 16.5647 28.7859 16.5647H28.7817C28.4122 16.5647 28.0681 16.7462 27.8612 17.0502L25.786 20.1008H13.056ZM7.22722 30.4452V22.7354C7.22722 21.8361 7.95978 21.1014 8.86333 21.1014C9.76478 21.1014 10.4994 21.8361 10.4994 22.7354V30.4452C10.4994 31.3467 9.76478 32.0792 8.86333 32.0792C7.95978 32.0792 7.22722 31.3467 7.22722 30.4452ZM11.4178 34.4078C12.4417 37.0256 14.2636 39.2507 16.5816 40.7791H11.4178V34.4078ZM31.4184 40.7791C33.7618 39.2317 35.5984 36.977 36.616 34.3191V40.7791H31.4184ZM40.7728 30.4473C40.7728 31.3488 40.0402 32.0813 39.1367 32.0813C38.2352 32.0813 37.5006 31.3488 37.5006 30.4473V22.7376C37.5006 21.8382 38.2352 21.1036 39.1367 21.1036C40.0402 21.1036 40.7728 21.8382 40.7728 22.7376V30.4473Z\" fill=\"white\"/>\n  </mask>\n  <g mask=\"url(#mask0_24395_6175)\">\n    <path d=\"M41.0282 19.3746C40.8298 15.4711 39.0607 11.8991 35.9953 9.24756C32.8244 6.50944 28.5642 5 24 5C19.4337 5 15.1756 6.50944 12.0047 9.24756C8.93933 11.8991 7.17022 15.4711 6.97178 19.3767C5.79589 20.0396 5 21.2978 5 22.7376V30.4473C5 32.5753 6.73111 34.3043 8.86333 34.3043C8.97311 34.3043 9.08289 34.3001 9.19056 34.2896V41.8896C9.19056 42.5039 9.68878 43.0021 10.3031 43.0021H37.7307C38.345 43.0021 38.8432 42.5039 38.8432 41.8896V34.2917C38.9403 34.3001 39.0374 34.3043 39.1388 34.3043C41.2668 34.3043 43 32.5732 43 30.4473V22.7376C43 21.2978 42.2041 20.0396 41.0282 19.3767V19.3746ZM13.4613 10.9301C16.2269 8.54033 19.9699 7.223 24 7.223C28.0322 7.223 31.7731 8.54033 34.5387 10.9301C36.9812 13.0412 38.4527 15.8363 38.7609 18.8974C38.1487 18.9587 37.5787 19.1613 37.0826 19.4717C35.5921 13.645 30.2911 9.32778 24 9.32778C17.7089 9.32778 12.4079 13.6471 10.9174 19.4717C10.4234 19.1613 9.85344 18.9587 9.24122 18.8974C9.54733 15.8363 11.0188 13.0412 13.4634 10.9301H13.4613ZM24 40.777C19.7081 40.777 15.9693 38.3703 14.0651 34.8363H18.4393V35.2396C18.4393 36.3437 19.3366 37.2409 20.4428 37.2409H27.5572C28.6634 37.2409 29.5628 36.3437 29.5628 35.2396V32.2122C29.5628 31.1081 28.6634 30.2109 27.5572 30.2109H20.4428C19.3366 30.2109 18.4372 31.1081 18.4372 32.2122V32.6133H13.1594C12.8766 31.6296 12.7246 30.5909 12.7246 29.5184V22.8093C12.7246 22.6468 12.7288 22.4842 12.7372 22.3238H26.375C26.7444 22.3238 27.0886 22.1422 27.2954 21.8382L28.7732 19.6638L30.2299 21.8319C30.4347 22.1401 30.783 22.3238 31.1546 22.3238H35.2649C35.2712 22.4842 35.2754 22.6468 35.2754 22.8093V29.5184C35.2754 35.7251 30.2172 40.777 24 40.777ZM20.6644 32.4339H27.3356V35.0179H20.6644V32.4339ZM13.056 20.1008C14.272 15.1967 18.718 11.5508 24 11.5508C29.282 11.5508 33.728 15.1967 34.944 20.1008H31.7478L29.7063 17.0566C29.5016 16.7504 29.1553 16.5647 28.7859 16.5647H28.7817C28.4122 16.5647 28.0681 16.7462 27.8612 17.0502L25.786 20.1008H13.056ZM7.22722 30.4452V22.7354C7.22722 21.8361 7.95978 21.1014 8.86333 21.1014C9.76478 21.1014 10.4994 21.8361 10.4994 22.7354V30.4452C10.4994 31.3467 9.76478 32.0792 8.86333 32.0792C7.95978 32.0792 7.22722 31.3467 7.22722 30.4452ZM11.4178 34.4078C12.4417 37.0256 14.2636 39.2507 16.5816 40.7791H11.4178V34.4078ZM31.4184 40.7791C33.7618 39.2317 35.5984 36.977 36.616 34.3191V40.7791H31.4184ZM40.7728 30.4473C40.7728 31.3488 40.0402 32.0813 39.1367 32.0813C38.2352 32.0813 37.5006 31.3488 37.5006 30.4473V22.7376C37.5006 21.8382 38.2352 21.1036 39.1367 21.1036C40.0402 21.1036 40.7728 21.8382 40.7728 22.7376V30.4473Z\" fill=\"currentColor\"/>\n    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M-1.33398 -1.33398H49.3327V49.3327H-1.33398V-1.33398Z\" fill=\"currentColor\"/>\n  </g>\n</svg>";
  var mute36="<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"48\" height=\"48\" viewBox=\"0 0 48 48\" fill=\"none\">\n  <g clip-path=\"url(#clip0_24394_170196)\">\n    <path d=\"M48 0H0V48H48V0Z\" fill=\"currentColor\" fill-opacity=\"0.01\"/>\n    <path d=\"M8.52344 16.9561C7.54508 19.1022 7 21.4874 7 24C7 33.3888 14.6112 41 24 41C29.3464 41 34.1151 38.5308 37.2314 34.6719L38.9463 35.7305C35.4677 40.1566 30.0662 43 24 43C13.5066 43 5 34.4934 5 24C5 21.1024 5.64958 18.3567 6.80957 15.8994L8.52344 16.9561ZM39.4053 14.6318C39.8921 14.3711 40.4989 14.5543 40.7598 15.041C41.0524 15.5874 41.3184 16.1507 41.5576 16.7275C42.487 18.969 43 21.4258 43 24C43 26.9938 42.3057 29.8248 41.0723 32.3438L39.3613 31.2871C40.411 29.0784 41 26.6082 41 24C41 21.6933 40.5415 19.496 39.7109 17.4932C39.4971 16.9774 39.2578 16.474 38.9961 15.9854C38.7357 15.4987 38.9188 14.8926 39.4053 14.6318ZM19.0312 23.4404C19.0108 23.6241 19 23.8108 19 24C19 26.7614 21.2386 29 24 29C25.0063 29 25.9421 28.701 26.7266 28.1895L28.5508 29.3154C27.3268 30.3643 25.7383 31 24 31C20.134 31 17 27.866 17 24C17 23.4188 17.0716 22.8544 17.2051 22.3145L19.0312 23.4404ZM33.5996 5C35.9616 5 38.2002 6.62789 38.2002 9C38.2002 11.3721 35.9616 13 33.5996 13C32.6707 12.9999 31.7619 12.7467 31 12.2969V24C31 24.6788 30.901 25.3344 30.7207 25.9551L28.9268 24.8477C28.9738 24.5721 29 24.289 29 24C29 21.2386 26.7614 19 24 19C22.8888 19 21.8623 19.3624 21.0322 19.9756L19.2383 18.8691C20.4875 17.7093 22.1609 17 24 17C25.9588 17 27.7295 17.8048 29 19.1016V8.40039C29 8.17115 29.0773 7.95968 29.207 7.79102C29.8135 6.09231 31.665 5.00015 33.5996 5ZM24 5C24.5523 5 25 5.44772 25 6C25 6.55228 24.5523 7 24 7C18.5567 7 13.7111 9.55832 10.5996 13.5381L8.88867 12.4814C12.3601 7.93412 17.8373 5 24 5ZM33.5996 7C31.9855 7.00017 31 8.05849 31 9C31 9.94151 31.9855 10.9998 33.5996 11C35.214 11 36.2002 9.94159 36.2002 9C36.2002 8.05841 35.214 7 33.5996 7Z\" fill=\"currentColor\"/>\n    <path d=\"M5.37329 12.6624L44 36.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n  </g>\n  <defs>\n    <clipPath id=\"clip0_24394_170196\">\n      <rect width=\"48\" height=\"48\" fill=\"currentColor\"/>\n    </clipPath>\n  </defs>\n</svg>";
  var unmute36="<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"48\" height=\"48\" viewBox=\"0 0 48 48\" fill=\"none\">\n  <g clip-path=\"url(#clip0_24394_170204)\">\n    <path d=\"M48 0H0V48H48V0Z\" fill=\"currentColor\" fill-opacity=\"0.01\"/>\n    <path d=\"M24 6C14.0589 6 6 14.0589 6 24C6 33.9411 14.0589 42 24 42C33.9411 42 42 33.9411 42 24C42 21.5595 41.5143 19.2323 40.6342 17.1101C40.4077 16.5638 40.1551 16.0311 39.8779 15.5136\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n    <path d=\"M33.6 12C35.5882 12 37.2 10.6568 37.2 9C37.2 7.34315 35.5882 6 33.6 6C31.6118 6 30 7.34315 30 9C30 10.6568 31.6118 12 33.6 12Z\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n    <path d=\"M24 30C27.3137 30 30 27.3137 30 24C30 20.6863 27.3137 18 24 18C20.6863 18 18 20.6863 18 24C18 27.3137 20.6863 30 24 30Z\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n    <path d=\"M30 8.40039V24.0004\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n  </g>\n  <defs>\n    <clipPath id=\"clip0_24394_170204\">\n      <rect width=\"48\" height=\"48\" fill=\"currentColor\"/>\n    </clipPath>\n  </defs>\n</svg>";
  function nativeSound35(){
    var direct36=soundSource36&&soundSource36();
    if(direct36&&typeof direct36.value==='boolean')return direct36;
    var section=document.querySelector('.history'),owner=section&&historyOwner(section);
    for(var p=owner;p;p=p.parent){
      var provides=p.provides;if(!provides)continue;
      var keys=Reflect.ownKeys(provides);
      for(var i=0;i<keys.length;i++){
        var ctx=provides[keys[i]];
        if(ctx&&ctx.soundEffects&&ctx.gameCode&&ctx.historyIssues&&ctx.gameCode.value===activeGame()&&typeof ctx.soundEffects.value==='boolean')return ctx.soundEffects;
      }
    }
    return null;
  }
  function support35(){
    var app=document.getElementById('app'),vue=app&&app.__vue_app__,router=vue&&vue.config.globalProperties.$router;
    if(router){Promise.resolve(router.push(router.hasRoute&&router.hasRoute('workOrder')?{name:'workOrder'}:'/workOrder')).catch(function(){location.assign('/workOrder');});}
    else location.assign('/workOrder');
  }
  function headerUI35(){
    if(!/^\/WinGo\//i.test(location.pathname)){
      document.querySelectorAll('[data-13l-controls35]').forEach(function(el){el.remove();});
      labels35.forEach(function(item){if(item.node.nodeValue==='Deposit')item.node.nodeValue=item.before;});labels35=[];logos35.forEach(function(item){if(item.style===null)item.node.removeAttribute('style');else item.node.setAttribute('style',item.style);});logos35=[];return;
    }
    document.querySelectorAll('.Wallet__C-balance-l3 > :nth-child(2)').forEach(function(button){
      // Change only the native text node; preserve click handlers and recharge route.
      Array.from(button.childNodes).forEach(function(node){if(node.nodeType===3&&/^\s*recharge\s*$/i.test(node.nodeValue)){labels35.push({node:node,before:node.nodeValue});node.nodeValue='Deposit';}});
    });
    document.querySelectorAll('.game-header').forEach(function(header){
      // This actual site's header has head-left/logo + recharge head-right.
      if(!header.querySelector('.head-left'))return;
      var tools=header.querySelector('[data-13l-controls35]');
      if(!tools){
        tools=document.createElement('div');tools.setAttribute('data-13l-controls35','');tools.className='header-controls35';
        var support=document.createElement('button');support.type='button';support.className='header-service35';support.setAttribute('aria-label','Customer service');support.title='Customer service';support.innerHTML=headset35;support.addEventListener('click',support35);
        var voice=document.createElement('button');voice.type='button';voice.className='header-voice35';voice.innerHTML=mute36;
        voice.addEventListener('click',function(){var sound=nativeSound35();if(sound){var muted=!sound.value;muted=!muted;sound.value=!muted;headerUI35();ping('audio36 '+activeGame()+' muted='+(muted?1:0));}});
        tools.append(support,voice);header.appendChild(tools);
      }
      var sound=nativeSound35(),voice=tools.querySelector('.header-voice35'),on=!!(sound&&sound.value);
      var iconName=on?'gamesaas_unmute':'gamesaas_mute';
      if(voice.getAttribute('data-icon36')!==iconName){voice.innerHTML=on?unmute36:mute36;voice.setAttribute('data-icon36',iconName);}
      voice.disabled=!sound;voice.setAttribute('aria-pressed',on?'true':'false');voice.setAttribute('aria-label',on?'Turn sound off':'Turn sound on');voice.title=sound?(on?'Turn sound off':'Turn sound on'):'Sound controls loading';
      var logo=header.querySelector('img.logo'),r=logo&&logo.getBoundingClientRect();
      ping('ui36 '+activeGame()+' controls=2 soundReady='+(sound?1:0),'logo='+(r?Math.round(r.width)+'x'+Math.round(r.height):'missing')+';deposit='+Array.from(document.querySelectorAll('.Wallet__C-balance-l3 > :nth-child(2)')).some(function(e){return e.textContent.trim()==='Deposit';}));
    });
  }

  function headFix(){
    if(!/^\/WinGo\//i.test(location.pathname))return;
    // A scrolled clock/ball is NEVER a header logo. Repair old marked clocks.
    document.querySelectorAll('.timer-cards img[style*="13lc"]').forEach(function(im){
      ['position','left','top','transform','max-width','height','max-height','z-index'].forEach(function(k){im.style.removeProperty(k);});
      var p=im.parentElement;
      while(p&&p.closest('.timer-cards')){if(p.style.getPropertyPriority('position')==='important')p.style.removeProperty('position');p=p.parentElement;}
      im.setAttribute('style',(im.getAttribute('style')||'').replace(/\/\*13lc\*\//g,''));
    });
    document.querySelectorAll('.game-header,.head-main,.navbar__content,.van-nav-bar').forEach(function(header){
      if(header.closest('.timer-cards,.Betting__C,.Wallet__C,.history'))return;
      var im=header.querySelector('img.logo,.logo img,.head-logo img,img[alt*="13L" i],img[src*="logo" i]');
      if(im&&!im.closest('.timer-cards,.Wallet__C')){
        if(!logos35.some(function(item){return item.node===im;}))logos35.push({node:im,style:im.getAttribute('style')});
        if(getComputedStyle(header).position==='static')header.style.setProperty('position','relative','important');
        var p=im.parentElement;
        while(p&&p!==header){p.style.setProperty('position','static','important');p=p.parentElement;}
        [['position','absolute'],['left','50%'],['top','50%'],['transform','translate(-50%,-50%)'],['width','2.13333rem'],['max-width','2.13333rem'],['height','.8rem'],['max-height','.8rem'],['z-index','2']].forEach(function(k){im.style.setProperty(k[0],k[1],'important');});
      }
      header.querySelectorAll('a,button,.deposit').forEach(function(el){
        if((el.textContent||'').trim().toLowerCase()==='deposit')el.style.setProperty('display','none','important');
      });
    });
    headerUI35();
    ping('header34 '+activeGame()+' strayClocks='+document.querySelectorAll('.timer-cards img[style*="13lc"]').length);
  }

  // v30: Give ONLY history's native KeepAlive a game key. A game switch then
  // destroys old row/page/chart state; late requests belong to unmounted views.
  // Betting/header components, wallet, core modules and native row templates stay intact.
  function activeGame(){
    var stateCode=window.state&&window.state.gameCode;
    var route=(location.pathname||'').match(/\/(?:WinGo|TrxWinGo)\/([^/?#]+)/i);
    var code=String(stateCode||(route&&route[1])||'');
    return /^(?:WinGo|TrxWinGo)_(?:30S|1M|3M|5M|10M)$/i.test(code)?code:'';
  }
  function hasHistoryClass(vnode){
    var cls=vnode&&vnode.props&&vnode.props.class;
    return typeof cls==='string'&&/(^|\s)history(\s|$)/.test(cls);
  }
  function keyHistory(vnode,game,inside){
    if(!vnode||typeof vnode!=='object')return 0;
    if(Array.isArray(vnode)){var total=0;for(var i=0;i<vnode.length;i++)total+=keyHistory(vnode[i],game,inside);return total;}
    inside=inside||hasHistoryClass(vnode);
    if(inside&&vnode.type&&vnode.type.__isKeepAlive){
      vnode.key='13l-history:'+game;
      vnode.props=Object.assign({},vnode.props||{},{key:vnode.key});
      return 1;
    }
    return Array.isArray(vnode.children)?keyHistory(vnode.children,game,inside):0;
  }
  function historyOwner(section){
    if(section.__vueParentComponent)return section.__vueParentComponent;
    // Vue production builds omit DOM.__vueParentComponent. Follow the mounted
    // root VNode instead; never depend on minified component variable names.
    var app=document.getElementById('app'),root=app&&app._vnode;
    var seen=new Set(),budget=5000;
    function walk(v,owner){
      if(!v||typeof v!=='object'||--budget<0||seen.has(v))return null;
      seen.add(v);
      if(Array.isArray(v)){for(var i=0;i<v.length;i++){var hit=walk(v[i],owner);if(hit)return hit;}return null;}
      if(v.el===section&&hasHistoryClass(v))return owner;
      if(v.component){var child=walk(v.component.subTree,v.component);if(child)return child;}
      if(v.suspense){var branch=walk(v.suspense.activeBranch,owner);if(branch)return branch;}
      return walk(v.children,owner);
    }
    return walk(root,null);
  }
  function installGameKeys(){
    if(!gamePage()||!activeGame())return;
    var sections=document.querySelectorAll('.history');
    for(var i=0;i<sections.length;i++){
      var owner=historyOwner(sections[i]);
      if(!owner||owner._13lGameKey30||typeof owner.render!=='function')continue;
      // Limit this adapter to a render tree that actually owns history + KeepAlive.
      function containsHistoryCache(v,inside){
        if(!v||typeof v!=='object')return false;
        if(Array.isArray(v))return v.some(function(x){return containsHistoryCache(x,inside);});
        inside=inside||hasHistoryClass(v);
        return !!(inside&&v.type&&v.type.__isKeepAlive)||containsHistoryCache(v.children,inside);
      }
      if(!containsHistoryCache(owner.subTree,false))continue;
      owner._13lGameKey30=true;
      (function(instance,render){
        instance.render=function(){
          var tree=render.apply(this,arguments);
          // Reading the native reactive gameCode here registers a render dependency.
          var game=activeGame(),count=game?keyHistory(tree,game,false):0;timerPaint36();
          if(count&&instance._13lGameSeen30!==game){
            instance._13lGameSeen30=game;
            ping('key30 '+game+' historyScopes='+count);
          }
          return tree;
        };
        if(instance.proxy&&instance.proxy.$forceUpdate)instance.proxy.$forceUpdate();
      })(owner,owner.render);
    }
  }

  function mount(){gate();installGameKeys();if(gamePage()){headFix();ping('boot38 '+location.pathname.slice(0,44));requestScan();}}
  function requestScan(){if(pending)return;pending=true;requestAnimationFrame(function(){pending=false;timerPaint36();installGameKeys();inspect();});}
  // Read-only diagnostics: the native component owns period/time/amount and pagination.
  // No JWT scan, all-game fetch, guessed amount matching or Vue textContent mutation.
  new MutationObserver(function(records){
    for(var i=0;i<records.length;i++){
      var el=records[i].target;
      if(records[i].type==='childList'||(el.closest&&el.closest('.history,.my_r,.MyGameRecord__C'))){requestScan();break;}
    }
  }).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
  ['pushState','replaceState'].forEach(function(name){
    var original=history[name];history[name]=function(){var r=original.apply(this,arguments);mount();return r;};
  });
  window.addEventListener('popstate',mount);window.addEventListener('hashchange',mount);
  window.addEventListener('resize',requestScan);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)mount();});
  setInterval(function(){if(!document.hidden){if(gamePage())headFix();inspect();}},900);
  if(document.fonts&&document.fonts.addEventListener)document.fonts.addEventListener('loadingdone',function(){
    Object.keys(lastPing).forEach(function(k){if(k.indexOf('font31 ')===0)delete lastPing[k];});requestScan();
  });
  mount();
})();