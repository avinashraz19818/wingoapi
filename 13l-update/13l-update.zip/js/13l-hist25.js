/* 13L-HIST25-v29: native per-game rows; stop hide/fill race; scoped layout */
(function(){
  'use strict';
  var lastPing={},pending=false;
  var style=document.createElement('style');style.id='13l-history29';
  style.textContent="/* 13L-PATCH25-v29: targeted DhaniWin/native history layout.\n   The legacy limitHistory timers hide nested cells, not only rows.\n   Explicit display rules win BEFORE paint; no text rewriting / all-game filler.\n   No home, header, betting panel, empty-state or unopened-detail selectors. */\nhtml[data-13l-history=\"1\"] .my_r,\nhtml[data-13l-history=\"1\"] .my_r-body,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C-body,\nhtml[data-13l-history=\"1\"] .my_r-body .list,\nhtml[data-13l-history=\"1\"] .history .t,\nhtml[data-13l-history=\"1\"] .history .t-b2,\nhtml[data-13l-history=\"1\"] .history .record-body {\n  height:auto!important;max-height:none!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list > div {\n  display:block!important;visibility:visible!important;max-height:none!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item {\n  display:flex!important;align-items:center;gap:.16rem;\n  height:auto!important;min-height:1.76rem;box-sizing:border-box;\n  padding:.16rem 0;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l > div {\n  display:block!important;visibility:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l {\n  flex:0 0 1.06667rem;margin-right:0!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m {\n  display:block!important;visibility:visible!important;\n  flex:1 1 auto!important;min-width:0;height:auto!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top {\n  display:flex!important;align-items:center;visibility:visible!important;\n  height:auto!important;min-height:.56rem;line-height:1.45!important;\n  font-size:clamp(10px,2.9vw,13px)!important;overflow-wrap:anywhere;\n  color:var(--text_color_L1,#fff)!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top > svg {flex:none;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-bottom {\n  display:block!important;visibility:visible!important;\n  height:auto!important;line-height:1.5!important;font-size:clamp(9px,2.65vw,12px)!important;\n  overflow-wrap:anywhere;color:var(--text_secondary,#9a9a9a)!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r {\n  display:flex!important;visibility:visible!important;flex:0 1 2.5rem!important;\n  min-width:0;height:auto!important;align-items:flex-end;flex-direction:column;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > span {\n  display:block!important;height:auto!important;max-width:100%;box-sizing:border-box;\n  line-height:1.5!important;overflow-wrap:anywhere;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div:first-child {padding:0 .2rem!important;}\n/* Native chart nodes, not a text search for a particular year/translation. */\nhtml[data-13l-history=\"1\"] .history .t-b2 > .t-b2-item {\n  display:block!important;visibility:visible!important;box-sizing:border-box;\n  height:1.33333rem!important;min-height:1.33333rem;max-height:none!important;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-i {\n  display:block!important;font-size:clamp(8px,2.6vw,11px)!important;\n  white-space:nowrap;letter-spacing:-.2px;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-Num {\n  display:flex!important;min-width:0;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-Num > div {\n  display:block!important;flex-shrink:1;box-sizing:border-box;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-item .van-col {min-width:0;}\nhtml[data-13l-history=\"1\"] .history .t-b1-l-n {min-width:0;}\nhtml[data-13l-history=\"1\"] .history .record-body > .van-row {display:flex!important;}\n/* Legacy selector also counts the van-row INSIDE every chart row. */\nhtml[data-13l-history=\"1\"] .history .t-b2-item > .van-row {display:flex!important;}\n";
  document.head.appendChild(style);
  function gamePage(){return /(?:wingo|mygamerecord|myhistory)/i.test(location.pathname);}
  function gate(){
    var value=gamePage()?'1':'0';
    if(document.documentElement.getAttribute('data-13l-history')!==value)
      document.documentElement.setAttribute('data-13l-history',value);
  }
  function ping(msg,geometry){
    if(!gamePage())return;
    var key=msg.split(' ')[0],now=Date.now();
    if(lastPing[key]&&now-lastPing[key]<20000)return;lastPing[key]=now;
    fetch('/api/_router.php?path=Site/OverlayPing',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({msg:msg,dom:geometry||''})
    }).catch(function(){});
  }
  function shown(el){
    if(!el)return false;
    var r=el.getBoundingClientRect(),cs=getComputedStyle(el);
    return r.width>0&&r.height>0&&cs.visibility!=='hidden'&&cs.display!=='none';
  }
  function inspect(){
    if(!gamePage()||document.hidden)return;
    var lists=document.querySelectorAll('.my_r-body .list');
    for(var j=0;j<lists.length;j++){
      if(!shown(lists[j]))continue;
      var rows=lists[j].querySelectorAll('.list-item'),ok=0,hidden=0,blank=0;
      for(var i=0;i<rows.length;i++){
        var top=rows[i].querySelector('.list-item-m-top');
        var bot=rows[i].querySelector('.list-item-m-bottom');
        var chip=rows[i].querySelector('.list-item-l');
        if(!shown(rows[i])||!shown(top)||!shown(bot)||!shown(chip))hidden++;
        else if(!/20[0-9]{15}/.test(top.textContent)||!bot.textContent.trim()||/Invalid/.test(bot.textContent))blank++;
        else ok++;
      }
      ping('history29 rows='+rows.length+' ok='+ok+' hidden='+hidden+' blank='+blank);
    }
    var charts=document.querySelectorAll('.history .t-b2');
    for(var c=0;c<charts.length;c++){
      if(!shown(charts[c]))continue;
      var cr=charts[c].querySelectorAll(':scope > .t-b2-item'),visible=0,clipped=0;
      for(var k=0;k<cr.length;k++){
        if(!shown(cr[k]))continue;visible++;
        var r=cr[k].getBoundingClientRect();
        for(var a=cr[k].parentElement;a&&a!==document.body;a=a.parentElement){
          var s=getComputedStyle(a),box=a.getBoundingClientRect();
          if(/hidden|clip/.test(s.overflowY)&&(r.bottom>box.bottom+2||r.top<box.top-2)){clipped++;break;}
        }
      }
      ping('chart29 rows='+cr.length+' visible='+visible+' clipped='+clipped,
        'viewport='+innerWidth+';container='+charts[c].clientHeight+';scroll='+charts[c].scrollHeight);
    }
  }
  function headFix(){
    try{
      var pn=(location.pathname||'').toLowerCase().replace(/\/+$/,'');
      if(pn===''||pn==='/index.html')return;
      var vw=window.innerWidth;
      var imgs=document.images,i,im,p;
      for(i=0;i<imgs.length;i++){
        im=imgs[i];var r=im.getBoundingClientRect();
        if(r.top<84&&r.top>=0&&r.width>28&&r.height>10&&im.offsetParent){
          p=im.parentElement;
          while(p&&p.parentElement&&(p.getBoundingClientRect().width<vw*0.55)){p=p.parentElement;}
          if(p&&p.getBoundingClientRect().width>=vw*0.55&&p.getBoundingClientRect().height<96&&p.contains(im)){
            if(getComputedStyle(p).position==='static')p.style.setProperty('position','relative','important');
            var q=im.parentElement,ok=false;
            while(q){
              if(q===p){ok=true;break;}
              if(getComputedStyle(q).position!=='static')q.style.setProperty('position','static','important');
              q=q.parentElement;
            }
            if(ok){
              var css=(im.getAttribute('style')||'');
              if(css.indexOf('13lc')===-1){
                im.style.setProperty('position','absolute','important');
                im.style.setProperty('left','50%','important');
                im.style.setProperty('top','50%','important');
                im.style.setProperty('transform','translate(-50%,-50%)','important');
                im.style.setProperty('max-width','62%','important');
                im.style.setProperty('height','auto','important');
                im.style.setProperty('max-height','70%','important');
                im.style.setProperty('z-index','2','important');
                im.setAttribute('style',im.getAttribute('style')+';/*13lc*/');
              }
            }
          }
          break;
        }
      }
      function depCand(n){
        if(!n||n===document.body||n===document.documentElement)return null;
        var b=n.getBoundingClientRect();
        if(b.width===0||b.height===0)return null;
        if(b.width>vw*0.6||b.height>64)return null;
        if(n.querySelector('img'))return null;
        var tx=(n.textContent||'').replace(/\s+/g,' ').trim();
        if(!/deposit/i.test(tx))return null;
        if(tx.replace(/deposit/ig,'').trim()!=='')return null;
        return n;
      }
      var els=document.querySelectorAll('a,button,div,span');
      for(i=0;i<els.length;i++){
        var el=els[i];
        if(el.children.length)continue;
        var tx0=(el.textContent||'').trim();
        if(tx0!=='Deposit'&&tx0!=='deposit')continue;
        var rr=el.getBoundingClientRect();
        if(rr.top>90||rr.top<0||rr.width===0||!el.offsetParent)continue;
        var hide=depCand(el.closest('a,button'))||depCand(el.parentElement)||el;
        if(hide)hide.style.setProperty('display','none','important');
      }
    }catch(e){}
  }

  function mount(){gate();if(gamePage()){headFix();ping('boot29 '+location.pathname.slice(0,44));requestScan();}}
  function requestScan(){if(pending)return;pending=true;requestAnimationFrame(function(){pending=false;inspect();});}
  // Read-only diagnostics: the native component owns period/time/amount and pagination.
  // No JWT scan, all-game fetch, guessed amount matching or Vue textContent mutation.
  new MutationObserver(function(records){
    for(var i=0;i<records.length;i++){
      var el=records[i].target;
      if(records[i].type==='childList'||(el.closest&&el.closest('.history,.my_r,.MyGameRecord__C'))){requestScan();break;}
    }
  }).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
  ['pushState','replaceState'].forEach(function(name){
    var original=history[name];history[name]=function(){var r=original.apply(this,arguments);mount();return r;};
  });
  window.addEventListener('popstate',mount);window.addEventListener('hashchange',mount);
  window.addEventListener('resize',requestScan);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)mount();});
  setInterval(function(){if(!document.hidden){if(gamePage())headFix();inspect();}},900);
  mount();
})();