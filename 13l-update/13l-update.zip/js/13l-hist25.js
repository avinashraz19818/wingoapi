/* 13L-HIST25-v31: native per-game rows; stop hide/fill race; scoped layout */
(function(){
  'use strict';
  var lastPing={},pending=false;
  var style=document.createElement('style');style.id='13l-history31';
  style.textContent="/* 13L-PATCH25-v31: targeted DhaniWin/native history layout.\n   The legacy limitHistory timers hide nested cells, not only rows.\n   Explicit display rules win BEFORE paint; no text rewriting / all-game filler.\n   No home, header, betting panel, empty-state or unopened-detail selectors. */\nhtml[data-13l-history=\"1\"] .my_r,\nhtml[data-13l-history=\"1\"] .my_r-body,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C-body,\nhtml[data-13l-history=\"1\"] .my_r-body .list,\nhtml[data-13l-history=\"1\"] .history .t,\nhtml[data-13l-history=\"1\"] .history .t-b2,\nhtml[data-13l-history=\"1\"] .history .record-body {\n  height:auto!important;max-height:none!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list > div {\n  display:block!important;visibility:visible!important;max-height:none!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item {\n  display:flex!important;align-items:center;gap:0;\n  height:auto!important;min-height:1.76rem;box-sizing:border-box;\n  padding:0!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l > div {\n  display:block!important;visibility:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l {\n  flex:0 0 .96rem;width:.96rem!important;height:.96rem!important;\n  line-height:.96rem!important;border-radius:.26667rem!important;\n  margin-right:.29333rem!important;overflow:hidden!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m {\n  display:block!important;visibility:visible!important;\n  flex:1 1 auto!important;min-width:0;height:auto!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top {\n  display:flex!important;align-items:center;visibility:visible!important;\n  height:auto!important;min-height:.56rem;line-height:.56rem!important;\n  font-size:.37333rem!important;font-weight:500;overflow-wrap:anywhere;\n  color:var(--text_color_L1,#fff)!important;overflow:visible!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top > svg {flex:none;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-bottom {\n  display:block!important;visibility:visible!important;\n  height:auto!important;line-height:.48rem!important;font-size:.32rem!important;\n  overflow-wrap:anywhere;color:var(--text_secondary,#9a9a9a)!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r {\n  display:flex!important;visibility:visible!important;flex:0 1 auto!important;max-width:30%;font-size:.32rem!important;\n  min-width:0;height:auto!important;align-items:flex-end;flex-direction:column;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > span {\n  display:block!important;height:auto!important;max-width:100%;box-sizing:border-box;\n  line-height:.64rem!important;overflow-wrap:anywhere;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div:first-child {padding:0 .48rem!important;font-size:.29333rem!important;line-height:.48rem!important;}\n/* Native chart nodes, not a text search for a particular year/translation. */\nhtml[data-13l-history=\"1\"] .history .t-b2 > .t-b2-item {\n  display:block!important;visibility:visible!important;box-sizing:border-box;\n  height:1.33333rem!important;min-height:1.33333rem;max-height:none!important;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-i {\n  display:block!important;font-size:.32rem!important;\n  white-space:nowrap;letter-spacing:normal;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-Num {\n  display:flex!important;min-width:0;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-Num > div {\n  display:block!important;flex-shrink:1;box-sizing:border-box;\n}\nhtml[data-13l-history=\"1\"] .history .t-b2-item .van-col {min-width:0;}\nhtml[data-13l-history=\"1\"] .history .t-b1-l-n {min-width:0;}\nhtml[data-13l-history=\"1\"] .history .record-body > .van-row {display:flex!important;}\n/* Legacy selector also counts the van-row INSIDE every chart row. */\nhtml[data-13l-history=\"1\"] .history .t-b2-item > .van-row {display:flex!important;}\n\n/* v31: native/DhaniWin typography; inherited 13L font and palette stay intact. */\nhtml[data-13l-history=\"1\"] .my_r-foot-page,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C-foot-page,\nhtml[data-13l-history=\"1\"] .history .t-foot-page {font-size:.32rem!important;}\n\n/* 13L-FONT31: Actual DhaniWin Poppins faces, scoped to history UI only.\n   Body/home/header stay untouched; icon glyphs keep their own icon font. */\nhtml[data-13l-history=\"1\"] .history,\nhtml[data-13l-history=\"1\"] .my_r,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l > div,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-bottom,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > span,\nhtml[data-13l-history=\"1\"] .my_r-foot-page,\nhtml[data-13l-history=\"1\"] .MyGameRecord__C-foot-page,\nhtml[data-13l-history=\"1\"] .history .t-b2-i {\n  font-family:\"13L History Poppins\",Poppins,Arial,sans-serif!important;\n  font-style:normal; font-synthesis:weight;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l > div {\n  width:100%!important;height:100%!important;border-radius:inherit!important;\n  overflow:hidden!important;display:block!important;text-align:center;\n}\n/* Exact native/DhaniWin box and text metrics (root 40px => 38.4px box / 10.67px radius). */\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l {font-size:.64rem;font-weight:400;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l-big,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l-small,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l-Big,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-l-Small {\n  font-size:.32rem!important;font-weight:400!important;\n}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-top {font-weight:500!important;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-m-bottom,\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r {font-weight:400!important;}\nhtml[data-13l-history=\"1\"] .my_r-body .list-item-r > div:first-child {\n  border-radius:.13333rem!important;margin-bottom:.08rem;\n  font-weight:400!important;\n}\n";
  document.head.appendChild(style);
  function gamePage(){return /(?:wingo|mygamerecord|myhistory)/i.test(location.pathname);}
  function gate(){
    var value=gamePage()?'1':'0';
    if(document.documentElement.getAttribute('data-13l-history')!==value)
      document.documentElement.setAttribute('data-13l-history',value);
  }
  function ping(msg,geometry){
    if(!gamePage())return;
    var key=msg.split(' ').slice(0,2).join(' '),now=Date.now();
    if(lastPing[key]&&now-lastPing[key]<20000)return;lastPing[key]=now;
    fetch('/api/_router.php?path=Site/OverlayPing',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({msg:msg,dom:geometry||''})
    }).catch(function(){});
  }
  function shown(el){
    if(!el)return false;
    var r=el.getBoundingClientRect(),cs=getComputedStyle(el);
    return r.width>0&&r.height>0&&cs.visibility!=='hidden'&&cs.display!=='none';
  }
  function inspect(){
    if(!gamePage()||document.hidden)return;
    var lists=document.querySelectorAll('.my_r-body .list');
    for(var j=0;j<lists.length;j++){
      if(!shown(lists[j]))continue;
      var rows=lists[j].querySelectorAll('.list-item'),ok=0,hidden=0,blank=0;
      for(var i=0;i<rows.length;i++){
        var top=rows[i].querySelector('.list-item-m-top');
        var bot=rows[i].querySelector('.list-item-m-bottom');
        var chip=rows[i].querySelector('.list-item-l');
        if(!shown(rows[i])||!shown(top)||!shown(bot)||!shown(chip))hidden++;
        else if(!/20[0-9]{15}/.test(top.textContent)||!bot.textContent.trim()||/Invalid/.test(bot.textContent))blank++;
        else ok++;
      }
      var sample=rows[0],box=sample&&sample.querySelector('.list-item-l'),title=sample&&sample.querySelector('.list-item-m-top');
      if(box&&title){
        var rect=box.getBoundingClientRect(),bc=getComputedStyle(box),tc=getComputedStyle(title);
        var fontReady=document.fonts&&Array.from(document.fonts).some(function(f){return f.family.replace(/['"]/g,'')==='13L History Poppins'&&f.status==='loaded';});
        ping('font31 '+activeGame()+' ready='+(fontReady?1:0),
          'family='+tc.fontFamily+';period='+tc.fontSize+';weight='+tc.fontWeight+';box='+Math.round(rect.width*10)/10+'x'+Math.round(rect.height*10)/10+';radius='+bc.borderRadius);
      }
      var expected=activeGame(),prefixMap={WinGo_30S:'10005',WinGo_1M:'10001',WinGo_3M:'10002',WinGo_5M:'10003',WinGo_10M:'10004'},wrong=0;
      for(var z=0;z<rows.length;z++){var text=rows[z].querySelector('.list-item-m-top');var match=text&&(text.textContent||'').match(/20[0-9]{15}/);if(match&&prefixMap[expected]&&match[0].slice(8,13)!==prefixMap[expected])wrong++;}
      ping('history31 '+expected+' rows='+rows.length+' wrong='+wrong+' hidden='+hidden+' blank='+blank,
        'font='+getComputedStyle(lists[j].querySelector('.list-item-m-top')||lists[j]).fontSize+';viewport='+innerWidth);
    }
    var charts=document.querySelectorAll('.history .t-b2');
    for(var c=0;c<charts.length;c++){
      if(!shown(charts[c]))continue;
      var cr=charts[c].querySelectorAll(':scope > .t-b2-item'),visible=0,clipped=0;
      for(var k=0;k<cr.length;k++){
        if(!shown(cr[k]))continue;visible++;
        var r=cr[k].getBoundingClientRect();
        for(var a=cr[k].parentElement;a&&a!==document.body;a=a.parentElement){
          var s=getComputedStyle(a),box=a.getBoundingClientRect();
          if(/hidden|clip/.test(s.overflowY)&&(r.bottom>box.bottom+2||r.top<box.top-2)){clipped++;break;}
        }
      }
      ping('chart31 '+activeGame()+' rows='+cr.length+' visible='+visible+' clip='+clipped,
        'viewport='+innerWidth+';container='+charts[c].clientHeight+';scroll='+charts[c].scrollHeight);
    }
  }
  function headFix(){
    try{
      var pn=(location.pathname||'').toLowerCase().replace(/\/+$/,'');
      if(pn===''||pn==='/index.html')return;
      var vw=window.innerWidth;
      var imgs=document.images,i,im,p;
      for(i=0;i<imgs.length;i++){
        im=imgs[i];var r=im.getBoundingClientRect();
        if(r.top<84&&r.top>=0&&r.width>28&&r.height>10&&im.offsetParent){
          p=im.parentElement;
          while(p&&p.parentElement&&(p.getBoundingClientRect().width<vw*0.55)){p=p.parentElement;}
          if(p&&p.getBoundingClientRect().width>=vw*0.55&&p.getBoundingClientRect().height<96&&p.contains(im)){
            if(getComputedStyle(p).position==='static')p.style.setProperty('position','relative','important');
            var q=im.parentElement,ok=false;
            while(q){
              if(q===p){ok=true;break;}
              if(getComputedStyle(q).position!=='static')q.style.setProperty('position','static','important');
              q=q.parentElement;
            }
            if(ok){
              var css=(im.getAttribute('style')||'');
              if(css.indexOf('13lc')===-1){
                im.style.setProperty('position','absolute','important');
                im.style.setProperty('left','50%','important');
                im.style.setProperty('top','50%','important');
                im.style.setProperty('transform','translate(-50%,-50%)','important');
                im.style.setProperty('max-width','62%','important');
                im.style.setProperty('height','auto','important');
                im.style.setProperty('max-height','70%','important');
                im.style.setProperty('z-index','2','important');
                im.setAttribute('style',im.getAttribute('style')+';/*13lc*/');
              }
            }
          }
          break;
        }
      }
      function depCand(n){
        if(!n||n===document.body||n===document.documentElement)return null;
        var b=n.getBoundingClientRect();
        if(b.width===0||b.height===0)return null;
        if(b.width>vw*0.6||b.height>64)return null;
        if(n.querySelector('img'))return null;
        var tx=(n.textContent||'').replace(/\s+/g,' ').trim();
        if(!/deposit/i.test(tx))return null;
        if(tx.replace(/deposit/ig,'').trim()!=='')return null;
        return n;
      }
      var els=document.querySelectorAll('a,button,div,span');
      for(i=0;i<els.length;i++){
        var el=els[i];
        if(el.children.length)continue;
        var tx0=(el.textContent||'').trim();
        if(tx0!=='Deposit'&&tx0!=='deposit')continue;
        var rr=el.getBoundingClientRect();
        if(rr.top>90||rr.top<0||rr.width===0||!el.offsetParent)continue;
        var hide=depCand(el.closest('a,button'))||depCand(el.parentElement)||el;
        if(hide)hide.style.setProperty('display','none','important');
      }
    }catch(e){}
  }

  // v30: Give ONLY history's native KeepAlive a game key. A game switch then
  // destroys old row/page/chart state; late requests belong to unmounted views.
  // Betting/header components, wallet, core modules and native row templates stay intact.
  function activeGame(){
    var stateCode=window.state&&window.state.gameCode;
    var route=(location.pathname||'').match(/\/(?:WinGo|TrxWinGo)\/([^/?#]+)/i);
    var code=String(stateCode||(route&&route[1])||'');
    return /^(?:WinGo|TrxWinGo)_(?:30S|1M|3M|5M|10M)$/i.test(code)?code:'';
  }
  function hasHistoryClass(vnode){
    var cls=vnode&&vnode.props&&vnode.props.class;
    return typeof cls==='string'&&/(^|\s)history(\s|$)/.test(cls);
  }
  function keyHistory(vnode,game,inside){
    if(!vnode||typeof vnode!=='object')return 0;
    if(Array.isArray(vnode)){var total=0;for(var i=0;i<vnode.length;i++)total+=keyHistory(vnode[i],game,inside);return total;}
    inside=inside||hasHistoryClass(vnode);
    if(inside&&vnode.type&&vnode.type.__isKeepAlive){
      vnode.key='13l-history:'+game;
      vnode.props=Object.assign({},vnode.props||{},{key:vnode.key});
      return 1;
    }
    return Array.isArray(vnode.children)?keyHistory(vnode.children,game,inside):0;
  }
  function historyOwner(section){
    if(section.__vueParentComponent)return section.__vueParentComponent;
    // Vue production builds omit DOM.__vueParentComponent. Follow the mounted
    // root VNode instead; never depend on minified component variable names.
    var app=document.getElementById('app'),root=app&&app._vnode;
    var seen=new Set(),budget=5000;
    function walk(v,owner){
      if(!v||typeof v!=='object'||--budget<0||seen.has(v))return null;
      seen.add(v);
      if(Array.isArray(v)){for(var i=0;i<v.length;i++){var hit=walk(v[i],owner);if(hit)return hit;}return null;}
      if(v.el===section&&hasHistoryClass(v))return owner;
      if(v.component){var child=walk(v.component.subTree,v.component);if(child)return child;}
      if(v.suspense){var branch=walk(v.suspense.activeBranch,owner);if(branch)return branch;}
      return walk(v.children,owner);
    }
    return walk(root,null);
  }
  function installGameKeys(){
    if(!gamePage()||!activeGame())return;
    var sections=document.querySelectorAll('.history');
    for(var i=0;i<sections.length;i++){
      var owner=historyOwner(sections[i]);
      if(!owner||owner._13lGameKey30||typeof owner.render!=='function')continue;
      // Limit this adapter to a render tree that actually owns history + KeepAlive.
      function containsHistoryCache(v,inside){
        if(!v||typeof v!=='object')return false;
        if(Array.isArray(v))return v.some(function(x){return containsHistoryCache(x,inside);});
        inside=inside||hasHistoryClass(v);
        return !!(inside&&v.type&&v.type.__isKeepAlive)||containsHistoryCache(v.children,inside);
      }
      if(!containsHistoryCache(owner.subTree,false))continue;
      owner._13lGameKey30=true;
      (function(instance,render){
        instance.render=function(){
          var tree=render.apply(this,arguments);
          // Reading the native reactive gameCode here registers a render dependency.
          var game=activeGame(),count=game?keyHistory(tree,game,false):0;
          if(count&&instance._13lGameSeen30!==game){
            instance._13lGameSeen30=game;
            ping('key30 '+game+' historyScopes='+count);
          }
          return tree;
        };
        if(instance.proxy&&instance.proxy.$forceUpdate)instance.proxy.$forceUpdate();
      })(owner,owner.render);
    }
  }

  function mount(){gate();installGameKeys();if(gamePage()){headFix();ping('boot31 '+location.pathname.slice(0,44));requestScan();}}
  function requestScan(){if(pending)return;pending=true;requestAnimationFrame(function(){pending=false;installGameKeys();inspect();});}
  // Read-only diagnostics: the native component owns period/time/amount and pagination.
  // No JWT scan, all-game fetch, guessed amount matching or Vue textContent mutation.
  new MutationObserver(function(records){
    for(var i=0;i<records.length;i++){
      var el=records[i].target;
      if(records[i].type==='childList'||(el.closest&&el.closest('.history,.my_r,.MyGameRecord__C'))){requestScan();break;}
    }
  }).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
  ['pushState','replaceState'].forEach(function(name){
    var original=history[name];history[name]=function(){var r=original.apply(this,arguments);mount();return r;};
  });
  window.addEventListener('popstate',mount);window.addEventListener('hashchange',mount);
  window.addEventListener('resize',requestScan);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)mount();});
  setInterval(function(){if(!document.hidden){if(gamePage())headFix();inspect();}},900);
  if(document.fonts&&document.fonts.addEventListener)document.fonts.addEventListener('loadingdone',function(){
    Object.keys(lastPing).forEach(function(k){if(k.indexOf('font31 ')===0)delete lastPing[k];});requestScan();
  });
  mount();
})();