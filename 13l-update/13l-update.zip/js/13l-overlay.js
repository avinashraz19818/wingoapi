/* 13L overlay — v4: intentionally empty (no-op).
   The pill close (✕) injection was REMOVED because this skin already ships
   its own native close button on the "Download APP" bar — the injected one
   caused a second X. Nothing else needs JS here; layout guard lives in
   css/13l-overlay.css. This file is kept so index.html does not 404. */
(function () { /* no-op */ }());
