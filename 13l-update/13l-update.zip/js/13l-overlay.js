/* 13L overlay — Add-to-Desktop pill gets a ✕ close button.
   Clicking it hides the pill for the current session only. */
(function () {
    'use strict';

    function addPillClose() {
        var pills = document.querySelectorAll('#app .pwa-btn');
        pills.forEach(function (pill) {
            var closed = false;
            try { closed = sessionStorage.getItem('13l-pwa-closed') === '1'; } catch (e) {}
            if (closed) { pill.style.setProperty('display', 'none', 'important'); return; }
            if (pill.querySelector('.sw-close')) return;
            var x = document.createElement('span');
            x.className = 'sw-close';
            x.setAttribute('role', 'button');
            x.setAttribute('aria-label', 'Close');
            x.textContent = '\u00d7';
            x.addEventListener('click', function (ev) {
                ev.stopPropagation();
                ev.preventDefault();
                pill.style.setProperty('display', 'none', 'important');
                try { sessionStorage.setItem('13l-pwa-closed', '1'); } catch (e) {}
            });
            pill.appendChild(x);
        });
    }

    function start() {
        addPillClose();
        var observer = new MutationObserver(addPillClose);
        observer.observe(document.documentElement, { childList: true, subtree: true });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
}());
