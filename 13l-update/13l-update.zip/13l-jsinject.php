<?php
// =====================================================================
// 13L JS INJECTOR v16 — skin ki ENTRY JS file ke end me ek chhota patch
// append karta hai jo app ke purANE localStorage history-cache (allGames /
// gameList / record-type keys) ko ek baar saaf karke page reload karta hai.
// Uske baad app hamesha LIVE server data use karega (jo ab 100% sahi hai).
// Token/session keys ko CHHUTA NAHI — sirf history-cache.
// URL: https://13l.club9.eu.cc/13l-jsinject.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
header('Content-Type: text/plain; charset=utf-8');
$R = rtrim(__DIR__, '/');
$MARK = '13L-JSINJECT-v16';

$patch = <<<JS

/* ===== {$MARK} ===== */
(function(){
  try{
    if(sessionStorage.getItem('13l_jrcleared')) return;
    var doomed=[], i, k, v;
    for(i=0;i<localStorage.length;i++){
      k=localStorage.key(i); if(!k) continue;
      var lk=k.toLowerCase();
      if(lk.indexOf('token')>-1||lk.indexOf('login')>-1||lk.indexOf('auth')>-1||lk.indexOf('user')>-1) continue;
      v=''; try{ v=localStorage.getItem(k)||''; }catch(e){}
      if(/allgames|gamehistory|myhistory|gamerecord|betlist|betrecord|recordlist|gamehistorylist/.test(lk)
         || (v.length>1 && (v.indexOf('allGames')>-1 || v.indexOf('gameList')>-1 || v.indexOf('mayrecord')>-1))) doomed.push(k);
    }
    for(i=0;i<doomed.length;i++){ try{ localStorage.removeItem(doomed[i]); }catch(e){} }
    // vuex-persist style single store blob se sirf nested cache keys hatao
    for(i=0;i<localStorage.length;i++){
      k=localStorage.key(i); if(!k) continue;
      v=''; try{ v=localStorage.getItem(k)||''; }catch(e){}
      if(v && v.charAt(0)==='{'){
        try{
          var o=JSON.parse(v), hit=false, walk=function(obj,depth){
            if(!obj||typeof obj!=='object'||depth>4) return;
            ['allGames','gameList','mayrecord','myHistoryList','historyList'].forEach(function(key){
              if(Object.prototype.hasOwnProperty.call(obj,key)){ delete obj[key]; hit=true; }
            });
            for(var p in obj){ if(obj[p]&&typeof obj[p]==='object') walk(obj[p],depth+1); }
          };
          walk(o,0);
          if(hit) localStorage.setItem(k, JSON.stringify(o));
        }catch(e){}
      }
    }
    sessionStorage.setItem('13l_jrcleared','1');
    location.reload();
  }catch(err){ try{console.warn('13l-jrclear',err);}catch(e){} }
})();
/* ===== /{$MARK} ===== */
JS;

$html = (string)@file_get_contents($R . '/index.html');
$targets = [];
if (preg_match_all('#<script[^>]+src="(/[^"]+\.js[^"]*)"#i', $html, $mm)) {
    foreach ($mm[1] as $s) { $p = parse_url($s); if (!empty($p['path'])) $targets[] = $R . $p['path']; }
}
// fallback: entry bundle(s)
if (!$targets) $targets = glob($R . '/js/index-*.js') ?: [];
$done = []; $skipped = [];
foreach ($targets as $f) {
    $bn = basename((string)$f);
    if (!is_file($f)) { $skipped[] = $bn . ' (missing)'; continue; }
    if (!is_writable($f)) { $skipped[] = $bn . ' (nowrite)'; continue; }
    if (filesize($f) > 8000000) { $skipped[] = $bn . ' (too big)'; continue; }
    $c = (string)file_get_contents($f);
    if (strpos($c, $MARK) !== false) { $skipped[] = $bn . ' (already patched)'; continue; }
    @copy($f, $f . '.bak13l');
    if (@file_put_contents($f, $c . $patch) !== false) $done[] = $bn;
    else $skipped[] = $bn . ' (write fail)';
}
echo "JS inject v16 (history-cache clearer)\n";
echo "patched (" . count($done) . "):\n  " . implode("\n  ", $done ?: ['(none)']) . "\n";
echo "skipped (" . count($skipped) . "):\n  " . implode("\n  ", $skipped ?: ['(none)']) . "\n";
echo "\nAb app band→khol: pehli baar wo khud-cache clear karke reload karega, phir LIVE data.\n";
echo "Rollback: same file ka .bak13l restore kar dena.\n";
