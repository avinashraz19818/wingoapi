<?php
// =====================================================================
// 13L SKINSYNC v20 — DhaniWin (reference site) ka poora working skin
// (js/css chunk graph) idhar server par download karo, 13L ke js/ css/
// me rakho, aur 13L index.html ki ENTRY bundle/css links un par swap karo.
//   • Branding: 13L ka index.html/title/favicon/custom fix scripts UNTOUCHED
//   • Hardcoded dhaniwin domains/brand strings → 13L wale (string-safe)
//   • Purani files delete NAHI hoti — rollback = entry link wapas (bak me)
// DRY RUN pehle:  13l-skinsync.php?key=13l2026&dry=1   (kuch likhta nahi)
// REAL:          13l-skinsync.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
@set_time_limit(600); @ini_set('memory_limit', '512M');
header('Content-Type: text/plain; charset=utf-8');
$DRY = isset($_GET['dry']);
$R = rtrim(__DIR__, '/');
$SRC = 'https://dhaniwin.club9.eu.cc';
$ME = (string)($_SERVER['HTTP_HOST'] ?? '13l.club9.eu.cc');

function http_get(string $url): ?string {
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'header' => "User-Agent: Mozilla/5.0\r\nAccept: */*\r\n"], 'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
    $c = @file_get_contents($url, false, $ctx);
    if ($c === false) { // curl fallback
        if (function_exists('curl_init')) {
            $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>1, CURLOPT_FOLLOWLOCATION=>1, CURLOPT_TIMEOUT=>20, CURLOPT_SSL_VERIFYPEER=>0, CURLOPT_USERAGENT=>'Mozilla/5.0']);
            $c2 = curl_exec($ch); curl_close($ch); return ($c2 === false || $c2 === '') ? null : $c2;
        }
        return null;
    }
    return $c;
}

echo "SKINSYNC v20 " . ($DRY ? "[DRY RUN]" : "[LIVE]") . "\n";

// 1) unka index.html
$theirHtml = http_get($SRC . '/index.html');
if (!$theirHtml || strlen($theirHtml) < 200) { exit("FATAL: $SRC/index.html fetch fail (host server se reachable nahi?)\n"); }
echo "their index.html: " . strlen($theirHtml) . " B\n";

// entry asset tags (js/css ke) unke html se — /webapi wale skip (13L ka config rahega)
$tags = [];
if (preg_match_all('#<(script[^>]*src="/(js|css)/[^"]+"[^>]*|link[^>]*href="/(js|css)/[^"]+"[^>]*)>#i', $theirHtml, $tm)) {
    foreach ($tm[1] as $t) {
        if (preg_match('#/(js|css)/([\w.\-]+\.(?:js|css))#i', $t, $mm2)) $tags[] = [strtolower($mm2[1]), $mm2[2], '<'.$t.'>'];
    }
}
if (!$tags) {
    // manual entry (unke html ke tags regex miss karein to)
    if (preg_match_all('#"/(js|css)/([\w.\-]+\.(?:js|css))"#', $theirHtml, $mm3)) {
        foreach ($mm3[1] as $i => $dir) $tags[] = [strtolower($dir), $mm3[2][$i], ($dir === 'js' ? '<script type="module" crossorigin src="/js/'.$mm3[2][$i].'"></script>' : '<link rel="stylesheet" href="/css/'.$mm3[2][$i].'">')];
    }
}
$tags = array_values(array_unique($tags, SORT_REGULAR));
if (!$tags) exit("FATAL: unke html me /js//css asset tag nahi mila\n");
echo "entry tags: " . count($tags) . "\n";

// 2) BFS crawl poore chunk graph ka
$queue = []; $seen = [];
foreach ($tags as $t) { $queue[$t[0] . '/' . $t[1]] = true; $seen[$t[0] . '/' . $t[1]] = true; }
$downloaded = 0; $bytes = 0; $fail = 0; $files = [];
$max = 800;
while ($queue && $downloaded < $max) {
    $batch = [];
    foreach ($queue as $rel => $_) { $batch[] = $rel; unset($queue[$rel]); if (count($batch) >= 12) break; }
    foreach ($batch as $rel) {
        $txt = http_get($SRC . '/' . $rel);
        if ($txt === null || strlen($txt) < 1) { $fail++; $files[$rel] = 'FAIL'; continue; }
        if (preg_match('#/css/#', $rel) && preg_match('#<html#i', substr($txt, 0, 500))) { $fail++; $files[$rel] = 'HTMLPAGE(skip)'; continue; }
        // brand/domain fix: hardcoded origins/naam → 13L
        $txt = str_replace('https://dhaniwin.club9.eu.cc', '', $txt);
        $txt = str_replace('//dhaniwin.club9.eu.cc', '', $txt);
        $txt = str_replace('dhaniwin.club9.eu.cc', $ME, $txt);
        $txt = str_replace(['DhaniWin', 'DHANIWIN', 'dhaniwin'], ['13L', '13L', '13l'], $txt);
        $files[$rel] = strlen($txt);
        $bytes += strlen($txt); $downloaded++;
        if (!$DRY) { @file_put_contents($R . '/' . $rel, $txt); }
        // js ke andar aur chunks/css refs — follow only in .js
        if (preg_match('#\.js$#', $rel)) {
            $more = [];
            if (preg_match_all('#\./([\w.\-]+\.js)#', $txt, $m4)) foreach ($m4[1] as $x) $more[] = 'js/' . $x;
            if (preg_match_all('#["\'`](/js/[\w.\-]+\.js|/css/[\w.\-]+\.css)#', $txt, $m5)) foreach ($m5[1] as $x) $more[] = ltrim($x, '/');
            if (preg_match_all('#__vitePreload\(\(\)=>import\("([^"]+)"\),\["([^"]+)"#', $txt, $m6)) { /* relative hi aayega */ }
            foreach ($more as $rel2) {
                $rel2 = preg_replace('#^/?(src|dist)/#', '', $rel2);
                if (!isset($seen[$rel2]) && (preg_match('#^js/#', $rel2) || preg_match('#^css/#', $rel2))) { $seen[$rel2] = true; $queue[$rel2] = true; }
            }
        }
    }
}
echo "downloaded: {$downloaded} files, " . number_format($bytes) . " B  (fail: $fail)\n";

// 3) 13L index.html ka entry swap — SIRF /js/index-*.js aur /css/index-*.css
//    (custom fix scripts, config, title, favicon sab jaisa tha waisa rahega)
$ourHtml = (string)file_get_contents($R . '/index.html');
$theirEntries = []; $theirCss = [];
foreach ($tags as $t) { if ($t[0] === 'js' && preg_match('#^index-#i', $t[1])) $theirEntries[] = $t[1]; if ($t[0] === 'css' && preg_match('#^index-#i', $t[1])) $theirCss[] = $t[1]; }
$newHtml = $ourHtml;
if ($theirEntries) $newHtml = preg_replace('#(<script[^>]*src=")/js/index-[\w\-]+\.js#i', '$1/js/' . $theirEntries[0], $newHtml, 1);
if ($theirCss)     $newHtml = preg_replace('#(<link[^>]*href=")/css/index-[\w\-]+\.css#i', '$1/css/' . $theirCss[0], $newHtml, 1);
$changed = ($newHtml !== $ourHtml);
echo "index.html: " . ($changed ? "ENTRY SWAP → js/" . ($theirEntries[0] ?? '?') . " css/" . ($theirCss[0] ?? ' (unchanged)') : "no change (pattern nahi mila — manual report karo)") . "\n";
if (!$DRY && $changed) {
    @copy($R . '/index.html', $R . '/index.html.bakskin');
    file_put_contents($R . '/index.html', $newHtml);
}
echo ($DRY ? "[dry] kuch nahi likha — real ke liye bina &dry=1 kholo\n" : "WROTE ✓ — js/ css/ files + index.html (backup: index.html.bakskin)\n");
if ($fail) echo "NOTE: $fail file fail — agar entry bundle me se ho to app kharab dikhega; ek baar aur chalao (retry ho jaayega, jo hai wo skip nahi hoga kyunki file already hai to dobara download thoda slow par safe)\n";
echo "\nApp swipe-close → reopen: ab DhaniWin wala hi skin chalega (13L branding ke saath), history/period/color sab uske working format me.\n";
