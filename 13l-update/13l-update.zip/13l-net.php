<?php
// 13L NET VIEWER v15 — app ke history requests ka log + deploy status.
// URL: https://13l.club9.eu.cc/13l-net.php?key=13l2026
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
header('Content-Type: text/plain; charset=utf-8');
$R = rtrim(__DIR__, '/');
$eng = @filesize($R . '/api/_core/lottery_engine.php');
$rout = @filesize($R . '/api/_router.php');
echo "deploy check: engine={$eng}B router={$rout}B (v13.1 engine=34538, v15 router me netlog)\n";
echo "v15 spy on: " . (strpos((string)@file_get_contents($R . '/api/_router.php'), '.netlog') !== false ? "yes" : "NO — deploy pending!") . "\n";
$css = glob($R . '/css/*.css') ?: [];
$inj = 0; foreach ($css as $f) { if (strpos((string)@file_get_contents($f), '13L-INJECT-v14') !== false) $inj++; }
echo "cssinject applied in: $inj / " . count($css) . " theme files" . ($inj ? "" : "  ← cssinject.php abhi nahi chala!") . "\n";
$log = $R . '/api/_core/.netlog';
echo "\n--- app ke history requests (latest 30) ---\n";
if (is_file($log)) {
    $lines = array_slice(file($log), -30);
    foreach ($lines as $l) {
        $j = json_decode(trim((string)$l), true);
        if ($j && ($j['ep'] ?? '') === 'ping') { echo $j['t'] . '  PING  ' . ($j['g'] ?? '') . (isset($j['dom']) && $j['dom'] !== '' ? "\n        DOM: " . $j['dom'] : '') . "\n"; continue; }
        echo $j ? ($j['t'] . '  ' . $j['ep'] . '  ' . ($j['g'] ?? '') . '  wantSize=' . ($j['wantSize'] ?? 'x') . '  rows=' . ($j['rows'] ?? '?') . '  total=' . ($j['total'] ?? '-')) . "\n" : $l;
    }
} else {
    echo "(abhi ek bhi request nahi aayi — app ne history API call hi nahi ki!)\n";
}
echo "\nAb: app swipe-close → reopen → My history khol → ye page refresh kar (rows/total badla dikhega).\n";
