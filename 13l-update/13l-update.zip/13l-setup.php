<?php
// =====================================================================
// 13L555 — ONE-SHOT SETUP (v4-final)
// Run this ONCE in the browser after extracting the zip:
//   https://13l555.com/13l-setup.php?key=13l2026
// It: 1) clears old generated results, 2) backfills the OFFICIAL AR draw
// feed into the DB, 3) sets the 2% bet tax, 4) deletes itself.
// Nothing else to do. Wallet/users/bets are untouched.
// =====================================================================

if (($_GET['key'] ?? '') !== '13l2026') {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'wrong key — open the exact URL from the README']);
    exit;
}

require_once __DIR__ . '/api/_core/bootstrap.php';

$out = ['ok' => false, 'steps' => []];
$conn = db();
if (!$conn) {
    $out['error'] = 'DB connect failed — check api/_core/config.php';
    header('Content-Type: application/json');
    echo json_encode($out);
    exit;
}

// 1) purge old lottery_results (pre-bridge rows would take priority)
$before = 0;
$rs = @$conn->query('SELECT COUNT(*) c FROM lottery_results');
if ($rs) $before = (int)$rs->fetch_assoc()['c'];
@$conn->query('DELETE FROM lottery_results');
$out['steps']['purged_old_results'] = $before;

// 2) backfill official draws for every WinGo-family game
$games = [
    'WinGo_30S', 'WinGo_1M', 'WinGo_3M', 'WinGo_5M',
    'TrxWinGo_1M', 'TrxWinGo_3M', 'TrxWinGo_5M',
    'K3_1M', 'K3_3M', 'K3_5M',
    'D5_1M', 'D5_3M', 'D5_5M',
];
$backfilled = 0;
$perGame = [];
foreach ($games as $g) {
    $n = function_exists('lb_sync') ? lb_sync($g, 30) : 0;
    $perGame[$g] = $n;
    $backfilled += $n;
}
$out['steps']['bridge_enabled'] = (function_exists('lb_enabled') && lb_enabled()) ? 'yes: ' . lb_cfg()['base'] : 'NO — api/_core/bridge.php missing!';
$out['steps']['backfilled_rows'] = $backfilled;
$out['steps']['per_game'] = $perGame;

// 3) bet tax: 2% off the payout (reference platform default)
$up = @$conn->query("UPDATE lottery_game_settings SET fee_percent=2.00");
$out['steps']['fee_percent_set'] = $up ? 2.0 : 'failed (set it in /admin → Lottery → Fee)';

$out['ok'] = $backfilled > 0;
$out['note'] = $out['ok']
    ? 'Done. Official draws now feed 13L555 — open the WinGo game and check history at timer 0.'
    : 'Backfill got 0 rows — feed unreachable from host right now. Game still runs on local draw; re-check the feed URL/firewall with host.';

// 4) self-delete
$out['setup_file'] = @unlink(__FILE__) ? 'self-deleted ✓' : 'DELETE THIS FILE manually now (public_html/13l-setup.php)';

header('Content-Type: application/json');
echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
