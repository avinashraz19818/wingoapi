<?php
// =====================================================================
// 13L V19 UNSTUCK — entry JS me final cache-buster patch:
//  (a) CONTENT-based localStorage purge: jo bhi key history-row data
//      rakhe (issueNumber/betContent fields wale objects/arrays — key ka
//      naam kuch bhi ho) usse hata/re-strip karo, tokens untouched.
//  (b) Agar app phir bhi stale row render kare (empty period/chip) to
//      pagination poke karke LIVE refetch karwa do.
// URL: https://13l.club9.eu.cc/13l-v19.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
header('Content-Type: text/plain; charset=utf-8');
$R = rtrim(__DIR__, '/');
$MARK = '13L-V19-UNSTUCK';

$patch = <<<JS

/* ===== {$MARK} ===== */
(function(){
  var G='13l_v19_purged';
  function deepStrip(o, d){
    if(!o || typeof o!=='object' || d>3) return false;
    var ch=false;
    for(var k in o){
      var x=o[k];
      if(Array.isArray(x) && x.length && x[0] && typeof x[0]==='object' && ('issueNumber' in x[0] || 'betContent' in x[0] || 'winLoseAmount' in x[0])){ o[k]=[]; ch=true; }
      else if(x && typeof x==='object'){ if(deepStrip(x,d+1)) ch=true; }
    }
    return ch;
  }
  try{
    if(!sessionStorage.getItem(G)){
      sessionStorage.setItem(G,'1');
      var hit=false;
      var keys=[];
      for(var i=0;i<localStorage.length;i++){ keys.push(localStorage.key(i)); }
      for(var j=0;j<keys.length;j++){
        var k=keys[j]; if(!k) continue;
        if(/token|login|auth|user|lang|currency|theme|siteSetting/i.test(k)) continue;
        var v=localStorage.getItem(k)||'';
        if(/"(issueNumber|betContent|winLoseAmount|mayrecord)"/.test(v)){
          try{
            var o=JSON.parse(v);
            if(o && typeof o==='object'){
              if(deepStrip(o,0)){ localStorage.setItem(k, JSON.stringify(o)); hit=true; }
              else { localStorage.removeItem(k); hit=true; }
            } else { localStorage.removeItem(k); hit=true; }
          }catch(e){ localStorage.removeItem(k); hit=true; }
        }
      }
      if(hit){ try{ location.reload(); }catch(e){} }
    }
  }catch(e){}
  // (b) stale-format rows dikhe (empty period) to live refetch poke karo
  var poked=false;
  setInterval(function(){
    try{
      if(poked || document.hidden) return;
      var ms=document.querySelectorAll('[class*="list-item-m-top"]');
      if(!ms.length) return;
      var bad=0;
      for(var i=0;i<ms.length;i++){
        var t=(ms[i].textContent||'').replace(/\\s|\\u200b/g,'');
        if(!t.length) bad++;
      }
      if(!bad) return;
      var nx=document.querySelector('[class*="foot-next"]');
      var pv=document.querySelector('[class*="foot-previous"]');
      if(!nx) return;
      poked=true;
      nx.click();
      setTimeout(function(){ if(pv) pv.click(); setTimeout(function(){ poked=false; },1500); },600);
    }catch(e){}
  },1500);
})();
/* ===== /{$MARK} ===== */
JS;

$html = (string)@file_get_contents($R . '/index.html');
$targets = [];
if (preg_match_all('#<script[^>]+src="(/[^"]+\.js[^"]*)"#i', $html, $mm)) {
    foreach ($mm[1] as $s) { $p = parse_url($s); if (!empty($p['path']) && preg_match('#/js/index-[^/]+\.js$#', $p['path'])) $targets[] = $R . $p['path']; }
}
foreach (glob($R . '/js/index-*.js') ?: [] as $g) $targets[] = $g;
$targets = array_values(array_unique(array_filter($targets, 'is_file')));

$done = []; $skip = [];
foreach ($targets as $f) {
    $bn = basename((string)$f);
    if (!is_writable($f)) { $skip[] = $bn; continue; }
    if (filesize($f) > 8000000) { $skip[] = $bn . ' (big)'; continue; }
    $c = (string)file_get_contents($f);
    if (strpos($c, $MARK) !== false) { $skip[] = $bn . ' (already)'; continue; }
    @copy($f, $f . '.bak19');
    if (@file_put_contents($f, $c . $patch) !== false) $done[] = $bn;
    else $skip[] = $bn . ' (write fail)';
}
echo "V19 UNSTUCK\n";
echo "patched (" . count($done) . "): " . implode(', ', $done ?: ['(none)']) . "\n";
echo "skipped (" . count($skip) . "): " . implode(', ', $skip ?: ['(none)']) . "\n";
echo "main bundle: " . (in_array('index-xnhGKCfe.js', $done, true) || strpos((string)@file_get_contents($R . '/js/index-xnhGKCfe.js'), $MARK) !== false ? "HAS v19 patch ✓" : "NOT patched — report karo!") . "\n";
