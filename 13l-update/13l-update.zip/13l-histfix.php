<?php
// =====================================================================
// 13L HISTFIX v25 — CACHE-BREAK EDITION (phone purani cached files chala
// raha tha, isliye patches kabhi pohnche hi nahi!). Ab:
//  1) FILLER+BEACON nayi file /js/13l-hist25.js (fresh URL = cache no issue)
//  2) index.html me <script ...13l-hist25.js?cb=13l25> + <link 13l-patch25.css?cb=13l25>
//  3) /css/13l-patch25.css — fresh standalone un-clip/readability rules
//  4) /sw.js overwrite → saare caches delete + self-unregister (PWA kill)
//  5) .htaccess → html/js/css par no-cache (ab se hamesha fresh)
//  6) .netlog 200KB se bada ho to trim
// Deploy auto-run karta hai. Standalone: ?key=13l2026
// =====================================================================
if (!isset($GLOBALS['13L_CHAIN'])) {
    if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
    if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');
}
$R = rtrim(__DIR__, '/');
$CB = '13l250907';

$fillerJs = <<<JS
/* 13L-FILLER-25: my-history live cell filler + beacon (cache-bust edition) */
(function(){
  var EPS=['/webapi/Lottery/GetMyGameRecord','/api/Lottery/GetMyGameRecord','/api/_router.php?path=Lottery/GetMyGameRecord','/Lottery/GetMyGameRecord'];
  var PING='/api/_router.php?path=Site/OverlayPing';
  var EP=null,cache=null,cacheT=0,probing=false,lastPing={};
  function ping(m,dom){
    try{
      var key=String(m).slice(0,24);var now=Date.now();
      if(lastPing[key]&&now-lastPing[key]<20000)return;lastPing[key]=now;
      fetch(PING,{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({msg:m,dom:dom||''})}).catch(function(){});
    }catch(e){}
  }
  ping('boot25 '+location.href.slice(-46)+' ua:'+navigator.userAgent.slice(0,26));
  function tk(){
    try{
      for(var i=0;i<localStorage.length;i++){
        var k=localStorage.key(i),v=localStorage.getItem(k)||'';
        if(!/token|auth/i.test(k))continue;
        if(v.length>30&&v.length<3000){var m2=v.match(/[A-Za-z0-9_-]{15,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}/);if(m2)return m2[0];}
      }
    }catch(e){}
    return '';
  }
  function callEp(u,cb){
    fetch(u,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tk()},
      body:JSON.stringify({pageNo:1,pageSize:50,gameCode:''})})
    .then(function(r){return r.json();})
    .then(function(j){var d=(j&&j.data&&j.data.list)||[];cb(d.length?d:null);})
    .catch(function(){cb(null);});
  }
  function getRows(cb){
    var t=Date.now();
    if(EP&&cache&&(t-cacheT)<5000){cb(cache);return;}
    if(probing)return;
    if(EP){callEp(EP,function(d){if(d){cache=d;cacheT=Date.now();}cb(cache||[]);});return;}
    probing=true;
    (function tryEp(i){
      if(i>=EPS.length){probing=false;ping('fetch-fail-all-EPS');cb([]);return;}
      callEp(EPS[i],function(d){
        if(d){EP=EPS[i];probing=false;cache=d;cacheT=Date.now();ping('fetch-ok ep'+i+' n'+d.length);cb(d);return;}
        tryEp(i+1);
      });
    })(0);
  }
  function fmtN(x){return '\u20B9'+Number(x||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function amtOf(r){return r.state==1?('+'+fmtN((+r.realAmount||0)+(+r.fee||0)+(+r.winLoseAmount||0))):fmtN(r.winLoseAmount);}
  function num(x){return String(x).replace(/[^0-9.]/g,'');}
  function tstr(ms){ms=+ms;if(!(ms>0))return'';var d=new Date(ms),p=function(n){return(n<10?'0':'')+n;};
    return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());}
  function chipOf(r){var b=String(r.betContent||'');var c=b.indexOf(',')>-1?b.split(',')[0]:b;return c.split('_')[1]||c;}
  function bodies(){
    var a=document.querySelectorAll('.my_r-body,[class*="MyGameRecord__C-body"]');
    if(a.length)return a;
    var first=document.querySelector('[class*="list-item-m-top"]');
    if(first){var w=first.closest('.list')||first.parentElement;return w?[w]:[];}
    return [];
  }
  var domSent=false;
  function fill(){
    var bs=bodies();
    if(!bs.length)return;
    var anyBad=false,badN=0;
    for(var b2=0;b2<bs.length;b2++){
      var its=bs[b2].querySelectorAll('.list-item,[class*="list-item"]');
      for(var i2=0;i2<its.length;i2++){
        var t2=its[i2].querySelector('[class*="list-item-m-top"]');
        var b2x=its[i2].querySelector('[class*="list-item-m-bottom"]');
        if(!t2||!(t2.textContent||'').trim().length||(b2x&&/Invalid/i.test(b2x.textContent))){badN++;anyBad=true;}
      }
    }
    if(!anyBad){ping('scan25 ok');return;}
    if(!domSent){domSent=true;ping('scan25 bad='+badN,bs[0].innerHTML.slice(0,420));}
    getRows(function(L){
      if(!L||!L.length){ping('no-rows');return;}
      var filled=0,used={};
      for(var bi=0;bi<bs.length;bi++){
        var items=bs[bi].querySelectorAll('.list-item,[class*="list-item"]');
        for(var i=0;i<items.length;i++){
          var it=items[i];
          var top=it.querySelector('[class*="list-item-m-top"]');
          var bot=it.querySelector('[class*="list-item-m-bottom"]');
          var leftWrap=it.querySelector('[class^="list-item-l"],[class*=" list-item-l"]');
          var ra=it.querySelector('[class*="list-item-r"] div:last-child')||it.querySelector('[class*="list-item-r"]');
          var amt=ra?(ra.textContent||'').replace(/\s/g,''):'';
          if(!top&&!bot&&!leftWrap)continue;
          var m=null,j;
          if(amt){for(j=0;j<L.length;j++){if(used[j])continue;if(L[j]&&num(amtOf(L[j]))===num(amt)){m=L[j];used[j]=1;break;}}}
          if(!m){for(j=0;j<L.length;j++){if(!used[j]){m=L[j];used[j]=1;break;}}}
          if(!m)continue;
          var wantIssue=String(m.issueNumber||'');
          if(top){
            var tv=(top.textContent||'').trim();
            if(wantIssue&&(!tv||/Invalid/i.test(tv)||tv.indexOf(wantIssue)===-1)){
              var sv=top.querySelector('svg');var sV=sv?sv.cloneNode(true):null;
              var sp=document.createElement('span');sp.textContent=wantIssue+' ';
              top.textContent='';top.appendChild(sp);if(sV)top.appendChild(sV);filled++;
            }
          }
          if(bot){var bt=(bot.textContent||'').trim(),wb=tstr(m.betTime);if(wb&&(!bt||/Invalid/i.test(bt))){bot.textContent=wb;filled++;}}
          if(leftWrap){var inner=leftWrap.querySelector('div')||leftWrap;var ch=chipOf(m);
            if(ch&&(inner.textContent||'').trim()!==ch){inner.textContent=ch;inner.className='list-item-l-'+ch;filled++;}}
        }
      }
      if(filled)ping('filled='+filled);
    });
  }
  setInterval(function(){try{fill();}catch(e){ping('err25 '+String(e.message).slice(0,60));}},900);
  document.addEventListener('click',function(){setTimeout(function(){try{fill();}catch(e){}},300);setTimeout(function(){try{fill();}catch(e){}},1600);},true);
  window.addEventListener('hashchange',function(){setTimeout(function(){try{fill();}catch(e){}},800);});
  setTimeout(fill,1200);
})();
JS;

$cssPatch = "/* 13L-PATCH25: history readability, standalone fresh file */\n"
    . ".my_r-body .list,.MyGameRecord__C-body .list{height:auto!important;max-height:none!important;overflow:visible!important}\n"
    . ".my_r-body .list-item,.MyGameRecord__C-body .list-item{overflow:visible!important}\n"
    . ".my_r-body .list-item-m-top,.MyGameRecord__C-body .list-item-m-top{color:#fff!important;overflow:visible!important}\n"
    . ".my_r-body .list-item-m-bottom,.MyGameRecord__C-body .list-item-m-bottom{color:#9a9a9a!important;overflow:visible!important}\n"
    . ".my_r-body .list-item-l,.MyGameRecord__C-body .list-item-l{overflow:visible!important}\n";

$swKill = "/* 13L-25: service-worker KILL — purane caches delete, khud unregister, reload */\n"
    . "self.addEventListener('install',function(){self.skipWaiting();});\n"
    . "self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.map(function(k){return caches.delete(k);}));}).then(function(){return self.registration.unregister();}).then(function(){return self.clients.matchAll({type:'window'});}).then(function(cs){return Promise.all(cs.map(function(c){try{return c.navigate(c.url);}catch(e){}}));}));});\n"
    . "self.addEventListener('fetch',function(){});\n";

$htBlock = "# BEGIN 13L-NO-CACHE\n"
    . "<IfModule mod_headers.c>\n<FilesMatch \"\\.(html?|js|css)$\">\nHeader set Cache-Control \"no-cache, must-revalidate\"\n</FilesMatch>\n</IfModule>\n"
    . "<IfModule mod_expires.c>\nExpiresActive Off\n</IfModule>\n"
    . "# END 13L-NO-CACHE\n";

$out = "HISTFIX v25 (cache-break)\n";

// 1) filler file
$f1 = $R . '/js/13l-hist25.js';
@file_put_contents($f1, $fillerJs);
$out .= "  js/13l-hist25.js: " . (is_file($f1) ? 'WRITTEN ' . filesize($f1) . ' B ✓' : 'FAIL!!') . "\n";

// 2) css patch file
$f2 = $R . '/css/13l-patch25.css';
@file_put_contents($f2, $cssPatch);
$out .= "  css/13l-patch25.css: " . (is_file($f2) ? 'WRITTEN ✓' : 'FAIL!!') . "\n";

// 3) sw.js kill (sirf agar sw.js pehle se tha ya index me register hai — dono case me safe overwrite)
$f3 = $R . '/sw.js';
if (is_file($f3)) { @copy($f3, $f3 . '.bak25'); @file_put_contents($f3, $swKill); $out .= "  sw.js: KILL overwrite ✓ (backup .bak25)\n"; }
else { @file_put_contents($f3, $swKill); $out .= "  sw.js: naya kill file (koi purana SW nahi tha)\n"; }

// 4) .htaccess
$hta = $R . '/.htaccess';
$cur = is_file($hta) ? (string)file_get_contents($hta) : '';
if (strpos($cur, '13L-NO-CACHE') === false) {
    @copy($hta, $hta . '.bak25');
    @file_put_contents($hta, $cur . "\n" . $htBlock);
    $out .= "  .htaccess: no-cache block added ✓\n";
} else $out .= "  .htaccess: already present ✓\n";

// 5) index.html tags (script + css link) cache-busted — idempotent
$idx = $R . '/index.html';
$h = (string)file_get_contents($idx);
$changed = false;
if (strpos($h, '13l-hist25.js') === false) {
    $tag = '<script src="/js/13l-hist25.js?cb=' . $CB . '"></script>';
    $h2 = stripos($h, '</body>') !== false ? preg_replace('#</body>#i', $tag . '</body>', $h, 1) : $h . $tag;
    if ($h2 !== $h) { @copy($idx, $idx . '.bak25b'); $h = $h2; $changed = true; $out .= "  index.html: <script> hist25 add ✓\n"; }
} else $out .= "  index.html: hist25 script already\n";
if (strpos($h, '13l-patch25.css') === false) {
    $link = '<link rel="stylesheet" href="/css/13l-patch25.css?cb=' . $CB . '">';
    $h2 = stripos($h, '</head>') !== false ? preg_replace('#</head>#i', $link . '</head>', $h, 1) : $link . $h;
    if ($h2 !== $h) { if (!$changed) @copy($idx, $idx . '.bak25c'); $h = $h2; $changed = true; $out .= "  index.html: <link> patch25 css add ✓\n"; }
} else $out .= "  index.html: patch25 css already\n";
if ($changed) @file_put_contents($idx, $h);

// 6) netlog trim >200KB
$nl = $R . '/api/_core/.netlog';
if (is_file($nl) && filesize($nl) > 200000) {
    $lines = file($nl);
    @file_put_contents($nl, implode('', array_slice((array)$lines, -600)));
    $out .= "  netlog trimmed → last 600 lines\n";
}
$out .= "\nAb chain: app kholte hi 'PING boot25' netlog me aana CHAHIYE (fresh file = cache bypass). Phir scan/filled lines.\n";
echo $out;
