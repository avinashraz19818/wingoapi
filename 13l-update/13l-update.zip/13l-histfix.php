<?php
// =====================================================================
// 13L HISTFIX v26c — /js/13l-hist25.js REWRITE (same cache-busted URL,
// .htaccess no-cache ab fresh deliver karta hai). Andar:
//  A) My-history filler: khaali (period/time/chip) + INVISIBLE (height-0)
//     cells ko live API rows se theek karta hai + DOM snippet beacon
//  B) HEADER TWEAKS (user maang rahe): 13L logo beech me (center),
//     'Deposit' button hide (sirf header zone me, top<90px)
//  C) Beacon: boot26/scan26/vis/filled lines netlog me — main server se
//     khud padh leta hoon, user ko kuch nahi karna
// Deploy khud include karta hai. Standalone: ?key=13l2026
// =====================================================================
if (!isset($GLOBALS['13L_CHAIN'])) {
    if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
    if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');
}
$R = rtrim(__DIR__, '/');
$CB = '13l260908';

$js = <<<JS
/* 13L-HIST25-v26c: my-history filler + header tweaks + beacon */
(function(){
  var PING='/api/_router.php?path=Site/OverlayPing';
  var EPS=['/webapi/Lottery/GetMyGameRecord','/api/Lottery/GetMyGameRecord','/api/_router.php?path=Lottery/GetMyGameRecord','/Lottery/GetMyGameRecord'];
  var EP=null,cache=null,cacheT=0,probing=false,lastPing={};
  function ping(m,dom){
    try{
      var key=String(m).slice(0,24);var now=Date.now();
      if(lastPing[key]&&now-lastPing[key]<20000)return;lastPing[key]=now;
      fetch(PING,{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({msg:m,dom:dom||''})}).catch(function(){});
    }catch(e){}
  }
  ping('boot26 '+location.href.slice(-46));
  function tk(){
    try{
      for(var i=0;i<localStorage.length;i++){
        var k=localStorage.key(i),v=localStorage.getItem(k)||'';
        if(!/token|auth/i.test(k))continue;
        if(v.length>30&&v.length<3000){var m2=v.match(/[A-Za-z0-9_-]{15,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}/);if(m2)return m2[0];}
      }
    }catch(e){}
    return '';
  }
  function callEp(u,cb){
    fetch(u,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tk()},
      body:JSON.stringify({pageNo:1,pageSize:50,gameCode:''})})
    .then(function(r){return r.json();})
    .then(function(j){var d=(j&&j.data&&j.data.list)||[];cb(d.length?d:null);})
    .catch(function(){cb(null);});
  }
  function getRows(cb){
    var t=Date.now();
    if(EP&&cache&&(t-cacheT)<5000){cb(cache);return;}
    if(probing)return;
    if(EP){callEp(EP,function(d){if(d){cache=d;cacheT=Date.now();}cb(cache||[]);});return;}
    probing=true;
    (function tryEp(i){
      if(i>=EPS.length){probing=false;ping('fetch-fail-all-EPS');cb([]);return;}
      callEp(EPS[i],function(d){
        if(d){EP=EPS[i];probing=false;cache=d;cacheT=Date.now();ping('fetch-ok ep'+i+' n'+d.length);cb(d);return;}
        tryEp(i+1);
      });
    })(0);
  }
  function fmtN(x){return '\u20B9'+Number(x||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function amtOf(r){return r.state==1?('+'+fmtN((+r.realAmount||0)+(+r.fee||0)+(+r.winLoseAmount||0))):fmtN(r.winLoseAmount);}
  function num(x){return String(x).replace(/[^0-9.]/g,'');}
  function tstr(ms){ms=+ms;if(!(ms>0))return'';var d=new Date(ms),p=function(n){return(n<10?'0':'')+n;};
    return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());}
  function chipOf(r){var b=String(r.betContent||'');var c=b.indexOf(',')>-1?b.split(',')[0]:b;return c.split('_')[1]||c;}
  function vis(el){var r=el.getBoundingClientRect();return r.height>=4&&r.width>=2;}
  function bodies(){
    var a=document.querySelectorAll('.my_r-body,[class*="MyGameRecord__C-body"]');
    if(a.length)return a;
    var first=document.querySelector('[class*="list-item-m-top"]');
    if(first){var w=first.closest('.list')||first.parentElement;return w?[w]:[];}
    return [];
  }
  var domSent=false;
  function fill(){
    var bs=bodies();
    if(!bs.length)return;
    var rows=0,badN=0,firstBad=null;
    for(var b2=0;b2<bs.length;b2++){
      var its=bs[b2].querySelectorAll('.list-item,[class*="list-item"]');
      for(var i2=0;i2<its.length;i2++){
        var it=its[i2];
        if(!it.querySelector('[class*="list-item-m"]')&&!it.querySelector('[class*="list-item-r"]'))continue;
        rows++;
        var t2=it.querySelector('[class*="list-item-m-top"]');
        var b2x=it.querySelector('[class*="list-item-m-bottom"]');
        var bad=!t2||!(t2.textContent||'').trim().length||(b2x&&/Invalid/i.test(b2x.textContent))||(t2&&!vis(t2)&&!badN);
        if(bad){badN++;if(!firstBad)firstBad=it;}
      }
    }
    if(!rows)return;
    if(!badN){ping('scan26 ok rows='+rows);return;}
    if(!domSent){domSent=true;try{ping('scan26 bad='+badN+' rows='+rows,firstBad?firstBad.outerHTML.slice(0,430):'');}catch(e){ping('scan26 bad-nodom');}}
    /* visibility repair (text hai par dikha nahi) — hamesha karo */
    var wr=document.querySelectorAll('[class*="list-item-m"]');
    for(var w2=0;w2<wr.length;w2++){
      var el=wr[w2];
      if(el.children.length&&!vis(el)){
        el.style.setProperty('height','auto','important');
        el.style.setProperty('max-height','none','important');
        el.style.setProperty('overflow','visible','important');
        el.style.setProperty('display','block','important');
        el.style.setProperty('min-height','0.56rem','important');
      }
    }
    getRows(function(L){
      if(!L||!L.length){ping('no-rows-26');return;}
      var filled=0,used={};
      for(var bi=0;bi<bs.length;bi++){
        var items=bs[bi].querySelectorAll('.list-item,[class*="list-item"]');
        for(var i=0;i<items.length;i++){
          var it2=items[i];
          var top=it2.querySelector('[class*="list-item-m-top"]');
          var bot=it2.querySelector('[class*="list-item-m-bottom"]');
          var leftWrap=it2.querySelector('[class^="list-item-l"],[class*=" list-item-l"]');
          var ra=it2.querySelector('[class*="list-item-r"] div:last-child')||it2.querySelector('[class*="list-item-r"]');
          var amt=ra?(ra.textContent||'').replace(/\s/g,''):'';
          if(!top&&!bot&&!leftWrap)continue;
          var m=null,j;
          if(amt){for(j=0;j<L.length;j++){if(used[j])continue;if(L[j]&&num(amtOf(L[j]))===num(amt)){m=L[j];used[j]=1;break;}}}
          if(!m){for(j=0;j<L.length;j++){if(!used[j]){m=L[j];used[j]=1;break;}}}
          if(!m)continue;
          var wantIssue=String(m.issueNumber||'');
          if(top){
            var tv=(top.textContent||'').trim();
            if(wantIssue&&(!tv||/Invalid/i.test(tv)||tv.indexOf(wantIssue)===-1)){
              var sv=top.querySelector('svg');var sV=sv?sv.cloneNode(true):null;
              var sp=document.createElement('span');sp.textContent=wantIssue+' ';
              top.textContent='';top.appendChild(sp);if(sV)top.appendChild(sV);
              top.style.setProperty('height','auto','important');top.style.setProperty('color','#fff','important');
              filled++;
            }
          }
          if(bot){var bt=(bot.textContent||'').trim(),wb=tstr(m.betTime);if(wb&&(!bt||/Invalid/i.test(bt))){bot.textContent=wb;bot.style.setProperty('color','#9a9a9a','important');filled++;}}
          if(leftWrap){var inner=leftWrap.querySelector('div')||leftWrap;var ch=chipOf(m);
            if(ch&&(inner.textContent||'').trim()!==ch){inner.textContent=ch;inner.className='list-item-l-'+ch;filled++;}}
        }
      }
      if(filled)ping('filled26='+filled);
    });
  }
  /* ---- header tweaks: logo center + deposit hide ---- */
  function headFix(){
    try{
      var vw=window.innerWidth;
      var imgs=document.images,i,im,p;
      for(i=0;i<imgs.length;i++){
        im=imgs[i];var r=im.getBoundingClientRect();
        if(r.top<84&&r.top>=0&&r.width>28&&r.height>10&&im.offsetParent){
          p=im.parentElement;
          while(p&&p.parentElement&&(p.getBoundingClientRect().width<vw*0.55)){p=p.parentElement;}
          if(p&&p.getBoundingClientRect().width>=vw*0.55&&p.getBoundingClientRect().height<96&&p.contains(im)){
            if(getComputedStyle(p).position==='static')p.style.setProperty('position','relative','important');
            var q=im.parentElement,ok=false;
            while(q){
              if(q===p){ok=true;break;}
              if(getComputedStyle(q).position!=='static')q.style.setProperty('position','static','important');
              q=q.parentElement;
            }
            if(ok){
              im.style.setProperty('position','absolute','important');
              im.style.setProperty('left','0','important');
              im.style.setProperty('right','0','important');
              im.style.setProperty('top','0','important');
              im.style.setProperty('bottom','0','important');
              im.style.setProperty('margin','auto','important');
              im.style.setProperty('width','fit-content','important');
              im.style.setProperty('height','fit-content','important');
            }
          }
          break;
        }
      }
      function depCand(n){
        if(!n||n===document.body||n===document.documentElement)return null;
        var b=n.getBoundingClientRect();
        if(b.width===0||b.height===0)return null;
        if(b.width>vw*0.6||b.height>64)return null;
        if(n.querySelector('img'))return null;
        var tx=(n.textContent||'').replace(/\s+/g,' ').trim();
        if(!/deposit/i.test(tx))return null;
        if(tx.replace(/deposit/ig,'').trim()!=='')return null;
        return n;
      }
      var els=document.querySelectorAll('a,button,div,span');
      for(i=0;i<els.length;i++){
        var el=els[i];
        if(el.children.length)continue;
        var tx0=(el.textContent||'').trim();
        if(tx0!=='Deposit'&&tx0!=='deposit')continue;
        var rr=el.getBoundingClientRect();
        if(rr.top>90||rr.top<0||rr.width===0||!el.offsetParent)continue;
        var hide=depCand(el.closest('a,button'))||depCand(el.parentElement)||el;
        if(hide)hide.style.setProperty('display','none','important');
      }
    }catch(e){}
  }
  function tick(){try{fill();headFix();}catch(e){ping('err26 '+String(e.message).slice(0,60));}}
  setInterval(tick,900);
  document.addEventListener('click',function(){setTimeout(tick,300);setTimeout(tick,1600);},true);
  window.addEventListener('hashchange',function(){setTimeout(tick,800);});
  setTimeout(tick,1000);
})();
JS;

$target = $R . '/js/13l-hist25.js';
@file_put_contents($target, $js);
$out = "HISTFIX v26c\n";
$out .= "  js/13l-hist25.js: REWRITTEN " . (is_file($target) ? filesize($target) . ' B ✓' : 'FAIL!') . " (URL same, no-cache headers se phone fresh lega)\n";

// index.html me tag check (agar kisi wajah se na ho)
$idx = $R . '/index.html';
$h = (string)file_get_contents($idx);
$changed = false;
if (strpos($h, '13l-hist25.js') === false) {
    $tag = '<script src="/js/13l-hist25.js?cb=' . $CB . '"></script>';
    $h2 = stripos($h, '</body>') !== false ? preg_replace('#</body>#i', $tag . '</body>', $h, 1) : $h . $tag;
    if ($h2 !== $h) { @copy($idx, $idx . '.bak26'); $h = $h2; $changed = true; $out .= "  index.html: <script> add ✓\n"; }
} else $out .= "  index.html: hist25 script linked ✓\n";
if ($changed) @file_put_contents($idx, $h);

// .htaccess no-cache dobara confirm
$hta = $R . '/.htaccess';
$cur = is_file($hta) ? (string)file_get_contents($hta) : '';
if (strpos($cur, '13L-NO-CACHE') === false) {
    @file_put_contents($hta, $cur . "\n# BEGIN 13L-NO-CACHE\n<IfModule mod_headers.c>\n<FilesMatch \"\\.(html?|js|css)$\">\nHeader set Cache-Control \"no-cache, must-revalidate\"\n</FilesMatch>\n</IfModule>\n# END 13L-NO-CACHE\n");
    $out .= "  .htaccess: no-cache added ✓\n";
} else $out .= "  .htaccess: no-cache present ✓\n";

// netlog trim
$nl = $R . '/api/_core/.netlog';
if (is_file($nl) && filesize($nl) > 200000) {
    @file_put_contents($nl, implode('', array_slice((array)file($nl), -600)));
    $out .= "  netlog trimmed\n";
}
$out .= "Status: " . (strpos((string)file_get_contents($target), '13L-HIST25-v26c') !== false ? 'v26c live ✓' : 'MISSING!') . "\n";
echo $out;
