<?php
// =====================================================================
// 13L HISTFIX v23 — DOM-filler in js/13l-overlay.js (index.html already
// loads it). My-history rows ke khaali/galat cells (period, bet-time,
// bet-chip) ko LIVE GetMyGameRecord data se bhar deta hai — API base
// auto-probe (4 candidates) + amount-numeric row match. Purana v22 block
// replace ho jaata hai. (13l-deploy.php isse khud include karta hai.)
// Standalone: https://13l.club9.eu.cc/13l-histfix.php?key=13l2026
// =====================================================================
if (!isset($GLOBALS['13L_CHAIN'])) {
    if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
    if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');
}
$R = rtrim(__DIR__, '/');
$MARK = '13L-HISTFIX-v23.1';

$block = <<<JS

/* ===== {$MARK}: my-history live cell filler ===== */
(function(){
  var EPS=['/webapi/Lottery/GetMyGameRecord','/api/Lottery/GetMyGameRecord','/api/_router.php?path=Lottery/GetMyGameRecord','/Lottery/GetMyGameRecord'];
  var EP=null,cache=null,cacheT=0,probing=false;
  function tk(){
    try{
      for(var i=0;i<localStorage.length;i++){
        var k=localStorage.key(i),v=localStorage.getItem(k)||'';
        if(!/token|auth/i.test(k))continue;
        if(v.length>30&&v.length<3000){var m=v.match(/[A-Za-z0-9_-]{15,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}/);if(m)return m[0];}
      }
    }catch(e){}
    return '';
  }
  function callEp(u,cb){
    fetch(u,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tk()},
      body:JSON.stringify({pageNo:1,pageSize:50,gameCode:''})})
    .then(function(r){return r.json();})
    .then(function(j){var d=(j&&j.data&&j.data.list)||[];cb(d.length?d:null);})
    .catch(function(){cb(null);});
  }
  function getRows(cb){
    var t=Date.now();
    if(EP&&cache&&(t-cacheT)<5000){cb(cache);return;}
    if(probing)return;
    if(EP){callEp(EP,function(d){if(d){cache=d;cacheT=Date.now();}cb(cache||[]);});return;}
    probing=true;
    (function tryEp(i){
      if(i>=EPS.length){probing=false;cb([]);return;}
      callEp(EPS[i],function(d){
        if(d){EP=EPS[i];probing=false;cache=d;cacheT=Date.now();cb(d);return;}
        tryEp(i+1);
      });
    })(0);
  }
  function fmtN(x){return '\\u20B9'+Number(x||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function amtOf(r){return r.state==1?('+'+fmtN((+r.realAmount||0)+(+r.fee||0)+(+r.winLoseAmount||0))):fmtN(r.winLoseAmount);}
  function num(x){return String(x).replace(/[^0-9.]/g,'');}
  function tstr(ms){ms=+ms;if(!(ms>0))return'';var d=new Date(ms),p=function(n){return(n<10?'0':'')+n;};
    return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());}
  function chipOf(r){var b=String(r.betContent||'');var c=b.indexOf(',')>-1?b.split(',')[0]:b;return c.split('_')[1]||c;}
  function setText(el,s){if(el&&(el.textContent||'')!==s)el.textContent=s;}
  function fill(){
    var bodies=document.querySelectorAll('.my_r-body,[class*="MyGameRecord__C-body"]');
    if(!bodies.length){var first=document.querySelector('[class*="list-item-m-top"]');if(first){var w=first.closest('.list')||first.parentElement;bodies=w?[w]:[];}}
    if(!bodies.length)return;
    var anyBad=false,bs=[];
    for(var b2=0;b2<bodies.length;b2++){
      var its=bodies[b2].querySelectorAll('.list-item');
      var bad=0;
      for(var i2=0;i2<its.length;i2++){
        var t2=its[i2].querySelector('[class*="list-item-m-top"]');
        var b2x=its[i2].querySelector('[class*="list-item-m-bottom"]');
        if(!t2||!(t2.textContent||'').trim().length||(b2x&&/Invalid/i.test(b2x.textContent))){bad++;anyBad=true;}
      }
      if(its.length)bs.push([bodies[b2],its.length,bad]);
    }
    if(!anyBad)return;
    getRows(function(L){
      if(!L||!L.length)return;
      for(var bi=0;bi<bodies.length;bi++){
        var items=bodies[bi].querySelectorAll('.list-item');
        if(!items.length)continue;
        var used={};
        for(var i=0;i<items.length;i++){
          var it=items[i];
          var top=it.querySelector('[class*="list-item-m-top"]');
          var bot=it.querySelector('[class*="list-item-m-bottom"]');
          var leftWrap=it.querySelector('[class^="list-item-l"],[class*=" list-item-l"]');
          var left=leftWrap&&leftWrap!==it?leftWrap:null;
          var ra=it.querySelector('[class*="list-item-r"] div:last-child');
          var amt=ra?(ra.textContent||'').replace(/\\s/g,''):'';
          if(!top&&!bot&&!left)continue;
          var m=null,j;
          if(amt){for(j=0;j<L.length;j++){if(used[j])continue;if(L[j]&&num(amtOf(L[j]))===num(amt)){m=L[j];used[j]=1;break;}}}
          if(!m&&!used[i]&&L[i]){m=L[i];used[i]=1;}
          if(!m)continue;
          var wantIssue=String(m.issueNumber||'')+' ';
          if(top){
            var tv=(top.textContent||'').trim();
            if(tv!==wantIssue.trim()){
              var sv=top.querySelector('svg');var sV=sv?sv.cloneNode(true):null;
              var sp=document.createElement('span');sp.textContent=wantIssue;
              top.textContent='';top.appendChild(sp);if(sV)top.appendChild(sV);
            }
          }
          if(bot){var bt=(bot.textContent||'').trim(),wb=tstr(m.betTime);if(wb&&bt!==wb)setText(bot,wb);}
          if(left){var inner=left.querySelector('div')||left;var ch=chipOf(m);
            if(ch&&(inner.textContent||'').trim()!==ch){inner.textContent=ch;inner.className='list-item-l-'+ch;}}
        }
      }
    });
  }
  setInterval(function(){try{fill();}catch(e){}},800);
  document.addEventListener('click',function(){setTimeout(function(){try{fill();}catch(e){}},250);setTimeout(function(){try{fill();}catch(e){}},1400);},true);
  window.addEventListener('hashchange',function(){setTimeout(function(){try{fill();}catch(e){}},700);});
  fill();
})();
/* ===== /{$MARK} ===== */
JS;

$target = $R . '/js/13l-overlay.js';
$out = "HISTFIX v23\n";
if (!is_file($target)) { $g = glob($R . '/js/13l-overlay*.js'); $target = $g[0] ?? $target; }
if (is_file($target)) {
    $c = (string)file_get_contents($target);
    if (strpos($c, $MARK) !== false) {
        $out .= "  " . basename($target) . ": v23 already applied (skip)\n";
    } else {
        // purane v22/v23 blocks hata do (replace)
        $c2 = preg_replace('#\n?/\* ===== 13L-HISTFIX-v2[23]:.*?/13L-HISTFIX-v2[23] ===== \*/\n#s', "\n", $c);
        @copy($target, $target . '.bak23');
        @file_put_contents($target, ($c2 !== null ? $c2 : $c) . $block);
        $out .= "  " . basename($target) . ": v23 PATCHED ✓" . ($c2 !== $c ? ' (old blocks stripped)' : '') . " (backup .bak23)\n";
    }
    // index.html me overlay link hona chahiye — na ho to add (guarded, single tag)
    $idx = $R . '/index.html';
    $h = (string)@file_get_contents($idx);
    if ($h && stripos($h, '13l-overlay') === false) {
        $bn2 = basename($target);
        $h2 = preg_replace('#(</body>)#i', '<script src="/js/' . $bn2 . '"></script>$1', $h, 1);
        if ($h2 !== $h) { @copy($idx, $idx . '.bak23'); @file_put_contents($idx, $h2); $out .= "index.html: overlay <script> tag ADD kiya (backup .bak23)\n"; }
    } else {
        $out .= "index.html: overlay already linked\n";
    }
} else $out .= "  overlay js MISSING — deploy phir se khol!\n";
$out .= "Status: " . (strpos((string)@file_get_contents($target), $MARK) !== false ? "v23 in overlay ✓" : "MARKER MISSING!") . "\n";
echo $out;
