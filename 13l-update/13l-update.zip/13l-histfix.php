<?php
// =====================================================================
// 13L HISTFIX v24 — overlay me DOM-filler + DIAGNOSTIC BEACON:
//  • phone se hi uski actual row-DOM mere server log (netlog 'PING' lines)
//    tak bhejta hai — bina screenshot ke main exact class-structure dekh leta hoon
//  • khaali period/time/chip cells ko live API rows se fill karta hai
//  • index.html me overlay <script> tag check/add (css link se galat-pass
//    hone ka purana bug fixed)
// 13l-deploy.php isse auto-run karta hai.
// URL: https://13l.club9.eu.cc/13l-histfix.php?key=13l2026
// =====================================================================
if (!isset($GLOBALS['13L_CHAIN'])) {
    if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
    if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');
}
$R = rtrim(__DIR__, '/');
$MARK = '13L-HISTFIX-v24';

$block = <<<JS

/* ===== {$MARK}: my-history filler + beacon ===== */
(function(){
  var EPS=['/webapi/Lottery/GetMyGameRecord','/api/Lottery/GetMyGameRecord','/api/_router.php?path=Lottery/GetMyGameRecord','/Lottery/GetMyGameRecord'];
  var EP=null,cache=null,cacheT=0,probing=false;
  var lastPing={};
  function ping(m,dom){
    try{
      var key=m.slice(0,24);
      var now=Date.now();
      if(lastPing[key]&&now-lastPing[key]<20000)return;
      lastPing[key]=now;
      fetch('/api/_router.php?path=Site/OverlayPing',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({msg:m,dom:dom||''})}).catch(function(){});
    }catch(e){}
  }
  ping('boot '+location.href.slice(-40));
  function tk(){
    try{
      for(var i=0;i<localStorage.length;i++){
        var k=localStorage.key(i),v=localStorage.getItem(k)||'';
        if(!/token|auth/i.test(k))continue;
        if(v.length>30&&v.length<3000){var m=v.match(/[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/);if(m)return m[0];}
      }
    }catch(e){}
    return '';
  }
  function callEp(u,cb){
    fetch(u,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tk()},
      body:JSON.stringify({pageNo:1,pageSize:50,gameCode:''})})
    .then(function(r){return r.json();})
    .then(function(j){var d=(j&&j.data&&j.data.list)||[];cb(d.length?d:null);})
    .catch(function(){cb(null);});
  }
  function getRows(cb){
    var t=Date.now();
    if(EP&&cache&&(t-cacheT)<5000){cb(cache);return;}
    if(probing)return;
    if(EP){callEp(EP,function(d){if(d){cache=d;cacheT=Date.now();}cb(cache||[]);});return;}
    probing=true;
    (function tryEp(i){
      if(i>=EPS.length){probing=false;ping('fetch-fail all EPS');cb([]);return;}
      callEp(EPS[i],function(d){
        if(d){EP=EPS[i];probing=false;cache=d;cacheT=Date.now();ping('fetch-ok ep'+i+' rows'+d.length);cb(d);return;}
        tryEp(i+1);
      });
    })(0);
  }
  function fmtN(x){return '\u20B9'+Number(x||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function amtOf(r){return r.state==1?('+'+fmtN((+r.realAmount||0)+(+r.fee||0)+(+r.winLoseAmount||0))):fmtN(r.winLoseAmount);}
  function num(x){return String(x).replace(/[^0-9.]/g,'');}
  function tstr(ms){ms=+ms;if(!(ms>0))return'';var d=new Date(ms),p=function(n){return(n<10?'0':'')+n;};
    return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());}
  function chipOf(r){var b=String(r.betContent||'');var c=b.indexOf(',')>-1?b.split(',')[0]:b;return c.split('_')[1]||c;}
  function bodies(){
    var a=document.querySelectorAll('.my_r-body,[class*="MyGameRecord__C-body"]');
    if(a.length)return a;
    var first=document.querySelector('[class*="list-item-m-top"]');
    if(first){var w=first.closest('.list')||first.parentElement;return w?[w]:[];}
    return [];
  }
  var domSent=false;
  function fill(){
    var bs=bodies();
    if(!bs.length)return;
    var anyBad=false,badN=0;
    for(var b2=0;b2<bs.length;b2++){
      var its=bs[b2].querySelectorAll('.list-item');
      for(var i2=0;i2<its.length;i2++){
        var t2=its[i2].querySelector('[class*="list-item-m-top"]');
        var b2x=its[i2].querySelector('[class*="list-item-m-bottom"]');
        if(!t2||!(t2.textContent||'').trim().length||(b2x&&/Invalid/i.test(b2x.textContent))){badN++;anyBad=true;}
      }
    }
    if(!anyBad){ping('scan ok');return;}
    if(!domSent){domSent=true;ping('scan bad='+badN,bs[0].innerHTML.slice(0,400));}
    getRows(function(L){
      if(!L||!L.length){ping('no rows');return;}
      var filled=0,used={};
      for(var bi=0;bi<bs.length;bi++){
        var items=bs[bi].querySelectorAll('.list-item');
        for(var i=0;i<items.length;i++){
          var it=items[i];
          var top=it.querySelector('[class*="list-item-m-top"]');
          var bot=it.querySelector('[class*="list-item-m-bottom"]');
          var leftWrap=it.querySelector('[class^="list-item-l"],[class*=" list-item-l"]');
          var ra=it.querySelector('[class*="list-item-r"] div:last-child');
          var amt=ra?(ra.textContent||'').replace(/\s/g,''):'';
          if(!top&&!bot&&!leftWrap)continue;
          var m=null,j;
          if(amt){for(j=0;j<L.length;j++){if(used[j])continue;if(L[j]&&num(amtOf(L[j]))===num(amt)){m=L[j];used[j]=1;break;}}}
          if(!m){for(j=0;j<L.length;j++){if(!used[j]){m=L[j];used[j]=1;break;}}}
          if(!m)continue;
          var wantIssue=String(m.issueNumber||'');
          if(top){
            var tv=(top.textContent||'').trim();
            if(wantIssue&&tv!==wantIssue&&(!tv||/Invalid/i.test(tv)||!/[0-9]{10,}/.test(tv))){
              var sv=top.querySelector('svg');var sV=sv?sv.cloneNode(true):null;
              var sp=document.createElement('span');sp.textContent=wantIssue+' ';
              top.textContent='';top.appendChild(sp);if(sV)top.appendChild(sV);
              filled++;
            }
          }
          if(bot){var bt=(bot.textContent||'').trim(),wb=tstr(m.betTime);if(wb&&(!bt||/Invalid/i.test(bt))){bot.textContent=wb;filled++;}}
          if(leftWrap){var inner=leftWrap.querySelector('div')||leftWrap;var ch=chipOf(m);
            if(ch&&(inner.textContent||'').trim()!==ch){inner.textContent=ch;inner.className='list-item-l-'+ch;filled++;}}
        }
      }
      if(filled)ping('filled='+filled);
    });
  }
  setInterval(function(){try{fill();}catch(e){ping('err '+String(e.message).slice(0,50));}},900);
  document.addEventListener('click',function(){setTimeout(function(){try{fill();}catch(e){}},300);setTimeout(function(){try{fill();}catch(e){}},1500);},true);
  window.addEventListener('hashchange',function(){setTimeout(function(){try{fill();}catch(e){}},800);});
  setTimeout(fill,1500);
})();
/* ===== /{$MARK} ===== */
JS;

$target = $R . '/js/13l-overlay.js';
$out = "HISTFIX v24\n";
if (!is_file($target)) { $g = glob($R . '/js/13l-overlay*.js'); $target = $g[0] ?? $target; }
if (is_file($target)) {
    $c = (string)file_get_contents($target);
    if (strpos($c, $MARK) !== false) {
        $out .= "  " . basename($target) . ": v24 already applied (skip)\n";
    } else {
        $c2 = preg_replace('#\n?/\* ===== 13L-HISTFIX-v2[23](?:\.1)?:.*?/13L-HISTFIX-v2[23](?:\.1)? ===== \*/\n#s', "\n", $c);
        if ($c2 === null) $c2 = $c;
        @copy($target, $target . '.bak24');
        @file_put_contents($target, $c2 . $block);
        $out .= "  " . basename($target) . ": v24 PATCHED ✓" . ($c2 !== $c ? ' (purane blocks replace hue)' : '') . " (backup .bak24)\n";
    }
    // index.html me overlay JS ka <script> tag HONA chahiye (sirf css link se nahi chalega)
    $idx = $R . '/index.html';
    $h = (string)@file_get_contents($idx);
    $bn2 = basename($target);
    if ($h && !preg_match('#<script[^>]+src="[^"]*' . preg_quote($bn2, '#') . '#i', $h)) {
        $tag = '<script src="/js/' . $bn2 . '"></script>';
        if (stripos($h, '</body>') !== false) $h2 = preg_replace('#</body>#i', $tag . '</body>', $h, 1);
        else $h2 = $h . $tag;
        @copy($idx, $idx . '.bak24');
        @file_put_contents($idx, $h2);
        $out .= "index.html: overlay <script> TAG ADD kiya (pehle sirf css link tha? backup .bak24)\n";
    } else {
        $out .= "index.html: overlay <script> pehle se linked ✓\n";
    }
    $out .= "Status: " . (strpos((string)@file_get_contents($target), $MARK) !== false ? "v24 in overlay ✓" : "MARKER MISSING!") . "\n";
} else $out .= "  overlay js MISSING — deploy phir se khol!\n";
$out .= "Note: phone se 'PING boot...' line netlog me aayi = filler live. 'scan bad=N' + DOM snippet aayi = main exact structure fix karunga.\n";
echo $out;
