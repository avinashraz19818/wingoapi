<?php
// =====================================================================
// 13L HISTFIX v22 — DOM-filler overlay (js/13l-overlay.js me append):
// My-history ki khaali cells (period / bet-time / bet-chip) ko LIVE
// API rows se bhar deta hai. Row match = amount text se (fallback: order).
// Jo row already sahi render ho rahi hai use chhuta nahi. Idempotent
// (data-13lf marker), koi delete/rebuild nahi.
// URL: https://13l.club9.eu.cc/13l-histfix.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
header('Content-Type: text/plain; charset=utf-8');
$R = rtrim(__DIR__, '/');
$MARK = '13L-HISTFIX-v22';

$block = <<<JS

/* ===== {$MARK}: my-history cell filler ===== */
(function(){
  var EP='/webapi/Lottery/GetMyGameRecord';
  function tk(){
    try{
      for(var i=0;i<localStorage.length;i++){
        var k=localStorage.key(i), v=localStorage.getItem(k)||'';
        if(!/token|auth/i.test(k)) continue;
        if(v.length>30 && v.length<3000){
          var m=v.match(/[A-Za-z0-9_-]{15,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}/);
          if(m) return m[0];
        }
      }
    }catch(e){}
    return '';
  }
  var cache=null,cacheT=0;
  function getRows(cb){
    var t=Date.now();
    if(cache&&(t-cacheT)<4000){cb(cache);return;}
    fetch(EP,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tk()},
      body:JSON.stringify({pageNo:1,pageSize:50,gameCode:''})})
    .then(function(r){return r.json();})
    .then(function(j){var d=(j&&j.data&&j.data.list)||[];if(d.length){cache=d;cacheT=t;}cb(d);})
    .catch(function(){cb([]);});
  }
  function fmtN(x){return '\\u20B9'+Number(x||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function amtOf(r){return r.state==1?('+'+fmtN((+r.realAmount||0)+(+r.fee||0)+(+r.winLoseAmount||0))):fmtN(r.winLoseAmount);}
  function tstr(ms){ms=+ms;if(!(ms>0))return'';var d=new Date(ms),p=function(n){return(n<10?'0':'')+n;};
    return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());}
  function chipOf(r){var b=String(r.betContent||'');var c=b.indexOf(',')>-1?b.split(',')[0]:b;return c.split('_')[1]||c;}
  function fill(){
    var body=document.querySelector('.my_r-body')||document.querySelector('[class*="MyGameRecord__C-body"]');
    if(!body)return;
    var items=body.querySelectorAll('.list-item');
    if(!items.length)return;
    getRows(function(L){
      if(!L||!L.length)return;
      var used={},gi;
      for(gi=0;gi<items.length;gi++){
        var it=items[gi];
        if(it.getAttribute('data-13lf')==='1')continue;
        var top=it.querySelector('[class*="list-item-m-top"]');
        var bot=it.querySelector('[class*="list-item-m-bottom"]');
        var left=it.querySelector('[class^="list-item-l"],[class*=" list-item-l"]');
        var ra=it.querySelector('[class*="list-item-r"] div:last-child');
        var amt=ra?(ra.textContent||'').replace(/\\s/g,''):'';
        var badTop=!top||!(top.textContent||'').trim().length;
        var badBot=!bot||!(bot.textContent||'').trim().length||/Invalid/i.test(bot.textContent);
        var badLeft=!left||!(left.textContent||'').trim().length;
        if(!(badTop||badBot||badLeft)){it.setAttribute('data-13lf','1');continue;}
        var m=null,j;
        function num(x){return String(x).replace(/[^0-9.]/g,'');}
        if(amt){for(j=0;j<L.length;j++){if(used[j])continue;if(num(amtOf(L[j]))===num(amt)){m=L[j];used[j]=1;break;}}}
        if(!m){for(j=0;j<L.length;j++){if(!used[j]){m=L[j];used[j]=1;break;}}}
        if(!m)continue;
        if(badTop&&top){var sv=top.querySelector('svg');var sV=sv?sv.cloneNode(true):null;var sp=document.createElement('span');sp.textContent=String(m.issueNumber||'')+' ';top.textContent='';top.appendChild(sp);if(sV)top.appendChild(sV);}
        if(badBot&&bot){bot.textContent=tstr(m.betTime);}
        if(badLeft&&left){var inner=left.querySelector('div')||left;var ch=chipOf(m);inner.textContent=ch;inner.className='list-item-l-'+ch;}
        it.setAttribute('data-13lf','1');
      }
    });
  }
  setInterval(function(){try{fill();}catch(e){}},700);
  document.addEventListener('click',function(){setTimeout(function(){try{fill();}catch(e){}},200);setTimeout(function(){try{fill();}catch(e){}},1200);},true);
  window.addEventListener('hashchange',function(){setTimeout(function(){try{fill();}catch(e){}},600);});
  fill();
})();
/* ===== /{$MARK} ===== */
JS;

$targets = [ $R . '/js/13l-overlay.js' ];
$fallback = glob($R . '/js/index-*.js');
$html = (string)@file_get_contents($R . '/index.html');
if (preg_match('#<script[^>]+src="/js/(13l-overlay[^"]*\.js)"#i', $html, $mo)) $targets = [ $R . '/js/' . $mo[1] ];
$out = "HISTFIX v22\n";
foreach ($targets as $f) {
    $bn = basename((string)$f);
    if (!is_file($f)) { $out .= "  {$bn}: missing\n"; continue; }
    if (!is_writable($f)) { $out .= "  {$bn}: NOT writable\n"; continue; }
    $c = (string)file_get_contents($f);
    if (strpos($c, $MARK) !== false) { $out .= "  {$bn}: already patched (skip)\n"; continue; }
    @copy($f, $f . '.bak22');
    @file_put_contents($f, $c . $block);
    $out .= "  {$bn}: PATCHED ✓ (backup .bak22)\n";
}
$out .= "\nVerify: " . (strpos((string)@file_get_contents($targets[0]), $MARK) !== false ? "overlay me v22 maujood ✓" : "MARKER NAHI MILA — report karo!") . "\n";
$out .= "Ab app band→khol → My history: khaali period/time/chip apne-aap bhar jaayenge (0.7 sec me).\n";
echo $out;
