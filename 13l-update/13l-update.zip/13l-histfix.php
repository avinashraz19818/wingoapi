<?php
// =====================================================================
// 13L HISTFIX v35 — /js/13l-hist25.js REWRITE (same cache-busted URL,
// .htaccess no-cache ab fresh deliver karta hai). Andar:
//  A) Native per-game history rendering; no cross-game filler.
//     Scoped CSS neutralizes legacy hide timers before paint.
//  B) HEADER TWEAKS (user maang rahe): 13L logo beech me (center),
//     'Deposit' button hide (sirf header zone me, top<90px)
//  C) Beacon: boot30/key30/history30/chart30 per-game netlog — main server se
//     khud padh leta hoon, user ko kuch nahi karna
// Deploy khud include karta hai. Standalone: ?key=13l2026
// =====================================================================
if (!isset($GLOBALS['13L_CHAIN'])) {
    if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
    if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');
}
$R = rtrim(__DIR__, '/');
$CB = '13l260908';

$js = <<<JS
/* 13L-HIST25-v35: native per-game rows; stop hide/fill race; scoped layout */
(function(){
  'use strict';
  var lastPing={},pending=false;
  var style=document.createElement('style');style.id='13l-history35';
  style.textContent="/* Poppins font files from DhaniWin; SIL OFL 1.1, full license in README-13L.txt. */\\n/* 13L-PATCH25-v31: targeted DhaniWin/native history layout.\\n   The legacy limitHistory timers hide nested cells, not only rows.\\n   Explicit display rules win BEFORE paint; no text rewriting / all-game filler.\\n   No home, header, betting panel, empty-state or unopened-detail selectors. */\\nhtml[data-13l-history=\\"1\\"] .my_r,\\nhtml[data-13l-history=\\"1\\"] .my_r-body,\\nhtml[data-13l-history=\\"1\\"] .MyGameRecord__C-body,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list,\\nhtml[data-13l-history=\\"1\\"] .history .t,\\nhtml[data-13l-history=\\"1\\"] .history .t-b2,\\nhtml[data-13l-history=\\"1\\"] .history .record-body {\\n  height:auto!important;max-height:none!important;overflow:visible!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list > div {\\n  display:block!important;visibility:visible!important;max-height:none!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item {\\n  display:flex!important;align-items:center;gap:0;\\n  height:auto!important;min-height:1.76rem;box-sizing:border-box;\\n  padding:0!important;overflow:visible!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l > div {\\n  display:block!important;visibility:visible!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l {\\n  flex:0 0 .96rem;width:.96rem!important;height:.96rem!important;\\n  line-height:.96rem!important;border-radius:.26667rem!important;\\n  margin-right:.29333rem!important;overflow:hidden!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-m {\\n  display:block!important;visibility:visible!important;\\n  flex:1 1 auto!important;min-width:0;height:auto!important;overflow:visible!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-m-top {\\n  display:flex!important;align-items:center;visibility:visible!important;\\n  height:auto!important;min-height:.56rem;line-height:.56rem!important;\\n  font-size:.37333rem!important;font-weight:500;overflow-wrap:anywhere;\\n  color:var(--text_color_L1,#fff)!important;overflow:visible!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-m-top > svg {flex:none;}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-m-bottom {\\n  display:block!important;visibility:visible!important;\\n  height:auto!important;line-height:.48rem!important;font-size:.32rem!important;\\n  overflow-wrap:anywhere;color:var(--text_secondary,#9a9a9a)!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r {\\n  display:flex!important;visibility:visible!important;flex:0 1 auto!important;max-width:30%;font-size:.32rem!important;\\n  min-width:0;height:auto!important;align-items:flex-end;flex-direction:column;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r > div,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r > span {\\n  display:block!important;height:auto!important;max-width:100%;box-sizing:border-box;\\n  line-height:.64rem!important;overflow-wrap:anywhere;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r > div:first-child {padding:0 .48rem!important;font-size:.29333rem!important;line-height:.48rem!important;}\\n/* Native chart nodes, not a text search for a particular year/translation. */\\nhtml[data-13l-history=\\"1\\"] .history .t-b2 > .t-b2-item {\\n  display:block!important;visibility:visible!important;box-sizing:border-box;\\n  height:1.33333rem!important;min-height:1.33333rem;max-height:none!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .history .t-b2-i {\\n  display:block!important;font-size:.32rem!important;\\n  white-space:nowrap;letter-spacing:normal;\\n}\\nhtml[data-13l-history=\\"1\\"] .history .t-b2-Num {\\n  display:flex!important;min-width:0;\\n}\\nhtml[data-13l-history=\\"1\\"] .history .t-b2-Num > div {\\n  display:block!important;flex-shrink:1;box-sizing:border-box;\\n}\\nhtml[data-13l-history=\\"1\\"] .history .t-b2-item .van-col {min-width:0;}\\nhtml[data-13l-history=\\"1\\"] .history .t-b1-l-n {min-width:0;}\\nhtml[data-13l-history=\\"1\\"] .history .record-body > .van-row {display:flex!important;}\\n/* Legacy selector also counts the van-row INSIDE every chart row. */\\nhtml[data-13l-history=\\"1\\"] .history .t-b2-item > .van-row {display:flex!important;}\\n\\n/* v31: native/DhaniWin typography; inherited 13L font and palette stay intact. */\\nhtml[data-13l-history=\\"1\\"] .my_r-foot-page,\\nhtml[data-13l-history=\\"1\\"] .MyGameRecord__C-foot-page,\\nhtml[data-13l-history=\\"1\\"] .history .t-foot-page {font-size:.32rem!important;}\\n\\n/* 13L-FONT31: Actual DhaniWin Poppins faces, scoped to history UI only.\\n   Body/home/header stay untouched; icon glyphs keep their own icon font. */\\nhtml[data-13l-history=\\"1\\"] .history,\\nhtml[data-13l-history=\\"1\\"] .my_r,\\nhtml[data-13l-history=\\"1\\"] .MyGameRecord__C,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l > div,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-m-top,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-m-bottom,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r > div,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r > span,\\nhtml[data-13l-history=\\"1\\"] .my_r-foot-page,\\nhtml[data-13l-history=\\"1\\"] .MyGameRecord__C-foot-page,\\nhtml[data-13l-history=\\"1\\"] .history .t-b2-i {\\n  font-family:\\"13L History Poppins\\",Poppins,Arial,sans-serif!important;\\n  font-style:normal; font-synthesis:weight;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l > div {\\n  width:100%!important;height:100%!important;border-radius:inherit!important;\\n  overflow:hidden!important;display:block!important;text-align:center;\\n}\\n/* Exact native/DhaniWin box and text metrics (root 40px => 38.4px box / 10.67px radius). */\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l {font-size:.64rem;font-weight:400;}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l-big,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l-small,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l-Big,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-l-Small {\\n  font-size:.32rem!important;font-weight:400!important;\\n}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-m-top {font-weight:500!important;}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-m-bottom,\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r {font-weight:400!important;}\\nhtml[data-13l-history=\\"1\\"] .my_r-body .list-item-r > div:first-child {\\n  border-radius:.13333rem!important;margin-bottom:.08rem;\\n  font-weight:400!important;\\n}\\n\\n/* 13L-TOP32: screenshot reference. WinGo route ONLY, not home/other games.\\n   Removes the red Wallet::before backdrop, not the wallet or live timer.\\n   No timer text, values, issue, event handlers, countdown/settlement changes. */\\nhtml[data-13l-wingo-ui=\\"1\\"] .game-header,\\nhtml[data-13l-wingo-ui=\\"1\\"] .winGo3,\\nhtml[data-13l-wingo-ui=\\"1\\"] #wingo {background:#282828!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C {background:transparent!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C::before {\\n  content:none!important;display:none!important;background:none!important;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance {\\n  background:#3b3b3b!important;border-radius:.53333rem!important;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance,\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance-l1,\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance-l2,\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance-l3 > div,\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C,\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-rule,\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-name,\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-text,\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-id,\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-time > div {\\n  font-family:\\"13L History Poppins\\",Poppins,Arial,sans-serif!important;\\n  font-style:normal;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance-l1 {color:#fff!important;font-weight:700;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance-l2 {color:#fff!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance-l3 > div:first-child {background:#ff5360!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .Wallet__C-balance-l3 > div + div {background:#12b965!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C {\\n  background-color:transparent!important;background-image:url(\\"data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20400%20114%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x2%3D%220%22%20y2%3D%221%22%3E%3Cstop%20stop-color%3D%22%23f33443%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%23cd1630%22%2F%3E%3C%2FlinearGradient%3E%3Cmask%20id%3D%22m%22%3E%3Crect%20width%3D%22400%22%20height%3D%22114%22%20rx%3D%2211%22%20fill%3D%22white%22%2F%3E%3Ccircle%20cx%3D%22200%22%20cy%3D%220%22%20r%3D%228%22%20fill%3D%22black%22%2F%3E%3Ccircle%20cx%3D%22200%22%20cy%3D%22114%22%20r%3D%228%22%20fill%3D%22black%22%2F%3E%3C%2Fmask%3E%3C%2Fdefs%3E%3Cg%20mask%3D%22url%28%23m%29%22%3E%3Crect%20width%3D%22400%22%20height%3D%22114%22%20fill%3D%22url%28%23g%29%22%2F%3E%3Cpath%20d%3D%22M200%2015V99%22%20stroke%3D%22white%22%20stroke-opacity%3D%22.32%22%20stroke-width%3D%221%22%20stroke-dasharray%3D%224%204%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E\\")!important;\\n  background-size:100% 100%!important;background-position:center!important;\\n  background-repeat:no-repeat!important;color:#fff!important;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-rule {\\n  color:#fff!important;border:1px solid rgba(255,255,255,.4)!important;\\n  max-width:calc(50% - .58667rem);box-sizing:border-box;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-rule svg {color:#fff!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-name {color:#fff!important;font-weight:400;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-text {\\n  color:#fff!important;font-size:.32rem!important;font-weight:700!important;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-id {\\n  color:#fff!important;font-size:.37333rem!important;font-weight:700!important;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-time {height:.8rem!important;line-height:.8rem!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-time > div {\\n  background:#fff!important;color:#b51b32!important;font-size:.53333rem!important;\\n  font-weight:700!important;font-variant-numeric:tabular-nums;\\n  width:.53333rem!important;height:.8rem!important;line-height:.8rem!important;\\n  padding:0!important;text-align:center;box-sizing:border-box;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .TimeLeft__C-time > div:nth-child(3) {width:.4rem!important;}\\n\\n/* 13L-BACKDROP33: native lottery-info has a separate 9rem red .bg div.\\n   Wallet::before is already disabled by this native skin; v32 missed .bg.\\n   Hide ONLY the direct decorative child on WinGo, not wallet/header content. */\\nhtml[data-13l-wingo-ui=\\"1\\"] .lottery-info {background:#282828!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .lottery-info > .bg {\\n  display:none!important;background:none!important;\\n}\\n\\n/* 13L-HEADER35: reference logo size and functional header controls, WinGo only. */\\nhtml[data-13l-wingo-ui=\\"1\\"] .game-header > .head-right {display:none!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .game-header img.logo {object-fit:contain!important;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .header-controls35 {\\n  position:absolute;right:.34667rem;top:50%;transform:translateY(-50%);\\n  display:flex;align-items:center;gap:.13333rem;z-index:12;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .header-controls35 button {\\n  display:flex;align-items:center;justify-content:center;width:.85333rem;height:.96rem;\\n  padding:.08rem;border:0;border-radius:.13333rem;background:transparent;color:#fff;cursor:pointer;\\n}\\nhtml[data-13l-wingo-ui=\\"1\\"] .header-controls35 button svg {width:.64rem;height:.64rem;display:block;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .header-controls35 button:focus-visible {outline:2px solid #fff;outline-offset:1px;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .header-controls35 button:disabled {opacity:.45;cursor:default;}\\nhtml[data-13l-wingo-ui=\\"1\\"] .header-voice35[aria-pressed=\\"true\\"] .mute-line35 {display:none;}\\n";
  document.head.appendChild(style);
  function gamePage(){return /(?:wingo|mygamerecord|myhistory)/i.test(location.pathname);}
  function gate(){
    var value=gamePage()?'1':'0';
    if(document.documentElement.getAttribute('data-13l-history')!==value)
      document.documentElement.setAttribute('data-13l-history',value);
    var topValue=/^\\/WinGo\\//i.test(location.pathname)?'1':'0';
    if(document.documentElement.getAttribute('data-13l-wingo-ui')!==topValue)
      document.documentElement.setAttribute('data-13l-wingo-ui',topValue);
    headerUI35();
  }
  function ping(msg,geometry){
    if(!gamePage())return;
    var key=msg.split(' ').slice(0,2).join(' '),now=Date.now();
    if(lastPing[key]&&now-lastPing[key]<20000)return;lastPing[key]=now;
    fetch('/api/_router.php?path=Site/OverlayPing',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({msg:msg,dom:geometry||''})
    }).catch(function(){});
  }
  function shown(el){
    if(!el)return false;
    var r=el.getBoundingClientRect(),cs=getComputedStyle(el);
    return r.width>0&&r.height>0&&cs.visibility!=='hidden'&&cs.display!=='none';
  }
  function inspect(){
    if(!gamePage()||document.hidden)return;
    var ticket=document.querySelector('.TimeLeft__C'),wallet=document.querySelector('.Wallet__C');
    if(ticket&&shown(ticket)){
      var cell=ticket.querySelector('.TimeLeft__C-time > div'),label=ticket.querySelector('.TimeLeft__C-text');
      if(cell&&label){
        var cs=getComputedStyle(cell),ls=getComputedStyle(label),back=wallet?getComputedStyle(wallet,'::before').display:'missing';
        var bg=document.querySelector('.lottery-info > .bg'),info=document.querySelector('.lottery-info'),card=document.querySelector('.Wallet__C-balance');
        ping('top33 '+activeGame()+' redLayer='+back+' infoBG='+(bg?getComputedStyle(bg).display:'missing'),
          'cell='+cs.backgroundColor+'/'+cs.color+';font='+cs.fontFamily+';size='+cs.fontSize+';weight='+cs.fontWeight+';label='+ls.color+';surface='+(info?getComputedStyle(info).backgroundColor:'missing')+';wallet='+(card?getComputedStyle(card).backgroundColor:'missing'));
      }
    }
    var lists=document.querySelectorAll('.my_r-body .list');
    for(var j=0;j<lists.length;j++){
      if(!shown(lists[j]))continue;
      var rows=lists[j].querySelectorAll('.list-item'),ok=0,hidden=0,blank=0;
      for(var i=0;i<rows.length;i++){
        var top=rows[i].querySelector('.list-item-m-top');
        var bot=rows[i].querySelector('.list-item-m-bottom');
        var chip=rows[i].querySelector('.list-item-l');
        if(!shown(rows[i])||!shown(top)||!shown(bot)||!shown(chip))hidden++;
        else if(!/20[0-9]{15}/.test(top.textContent)||!bot.textContent.trim()||/Invalid/.test(bot.textContent))blank++;
        else ok++;
      }
      var sample=rows[0],box=sample&&sample.querySelector('.list-item-l'),title=sample&&sample.querySelector('.list-item-m-top');
      if(box&&title){
        var rect=box.getBoundingClientRect(),bc=getComputedStyle(box),tc=getComputedStyle(title);
        var fontReady=document.fonts&&Array.from(document.fonts).some(function(f){return f.family.replace(/['"]/g,'')==='13L History Poppins'&&f.status==='loaded';});
        ping('font31 '+activeGame()+' ready='+(fontReady?1:0),
          'family='+tc.fontFamily+';period='+tc.fontSize+';weight='+tc.fontWeight+';box='+Math.round(rect.width*10)/10+'x'+Math.round(rect.height*10)/10+';radius='+bc.borderRadius);
      }
      var expected=activeGame(),prefixMap={WinGo_30S:'10005',WinGo_1M:'10001',WinGo_3M:'10002',WinGo_5M:'10003',WinGo_10M:'10004'},wrong=0;
      for(var z=0;z<rows.length;z++){var text=rows[z].querySelector('.list-item-m-top');var match=text&&(text.textContent||'').match(/20[0-9]{15}/);if(match&&prefixMap[expected]&&match[0].slice(8,13)!==prefixMap[expected])wrong++;}
      ping('history31 '+expected+' rows='+rows.length+' wrong='+wrong+' hidden='+hidden+' blank='+blank,
        'font='+getComputedStyle(lists[j].querySelector('.list-item-m-top')||lists[j]).fontSize+';viewport='+innerWidth);
    }
    var charts=document.querySelectorAll('.history .t-b2');
    for(var c=0;c<charts.length;c++){
      if(!shown(charts[c]))continue;
      var cr=charts[c].querySelectorAll(':scope > .t-b2-item'),visible=0,clipped=0;
      for(var k=0;k<cr.length;k++){
        if(!shown(cr[k]))continue;visible++;
        var r=cr[k].getBoundingClientRect();
        for(var a=cr[k].parentElement;a&&a!==document.body;a=a.parentElement){
          var s=getComputedStyle(a),box=a.getBoundingClientRect();
          if(/hidden|clip/.test(s.overflowY)&&(r.bottom>box.bottom+2||r.top<box.top-2)){clipped++;break;}
        }
      }
      ping('chart31 '+activeGame()+' rows='+cr.length+' visible='+visible+' clip='+clipped,
        'viewport='+innerWidth+';container='+charts[c].clientHeight+';scroll='+charts[c].scrollHeight);
    }
  }
  // v34: Native composable adapter. No DOM period/result writes or guessed draws.
  window.__13lRound34=function(io){
    var code='',issue='',deadline=0,last=-1,dead=false,timer=null,busy=false;
    var retryAt=0,failures=0,historyAt=0,historyBusy=false,latest='',signature='',waiting='',notified='';
    var prefixes={WinGo_30S:'10005',WinGo_1M:'10001',WinGo_3M:'10002',WinGo_5M:'10003'};
    function valid(id,g){return /^\\d{17}\$/.test(String(id||''))&&String(id).slice(8,13)===prefixes[g];}
    function active(){return !dead&&!document.hidden&&/^\\/WinGo\\//i.test(location.pathname)&&!!prefixes[io.game()];}
    function event(kind){ping(kind+' '+code+' issue='+issue+' latest='+(latest||'none'),'left='+io.seconds()+';waiting='+(waiting||'none')+';failures='+failures);}
    function acceptIssue(data,g){
      if(dead||g!==io.game()||!valid(data.issueNumber,g))return false;
      var duration={WinGo_30S:30,WinGo_1M:60,WinGo_3M:180,WinGo_5M:300}[g];
      var left=Number(data.countdown);
      if(Number.isFinite(+data.endTime)&&+data.__server34>0)left=(+data.endTime-+data.__server34)/1000;
      if(!Number.isFinite(left)||left>duration+5)return false;
      if(code===g&&issue&&data.issueNumber<issue)return false;
      data.__left34=Math.max(0,left);return true;
    }
    function received(data){
      var g=io.game(),previous=code===g?issue:'';
      if(code!==g){latest='';signature='';waiting='';notified='';io.rows([],0);}
      code=g;issue=String(data.issueNumber);deadline=performance.now()+data.__left34*1000;
      last=Math.max(0,Math.ceil(data.__left34));io.setSeconds(last);failures=0;
      if(previous&&previous!==issue){waiting=previous;historyAt=0;event('roll34');}
      else if(!latest)historyAt=0;
    }
    function filter(rows,g){
      if(g!==io.game()||g!==code||!issue)return [];
      var seen=new Set();return (Array.isArray(rows)?rows:[]).filter(function(row){
        var id=String(row.issueNumber||''),num=String(row.number);
        if(!valid(id,g)||id>=issue||!/^\\d\$/.test(num)||seen.has(id)||(row.gameCode&&row.gameCode!==g))return false;
        seen.add(id);return true;
      }).sort(function(a,b){return String(b.issueNumber).localeCompare(String(a.issueNumber));});
    }
    function apply(rows,total,g){
      g=g||io.game();if(dead||code!==g||g!==io.game())return false;
      rows=filter(rows,g);if(!rows.length)return false;
      var first=String(rows[0].issueNumber);if(latest&&first<latest)return false;
      var sig=rows.map(function(r){return r.issueNumber+':'+r.number;}).join('|');
      if(signature!==sig){signature=sig;latest=first;io.rows(rows,total);}
      if(waiting&&first>=waiting){if(notified!==waiting){notified=waiting;io.notify();event('result34');}waiting='';}
      return true;
    }
    async function history(){
      if(!active()||code!==io.game()||!issue||historyBusy||performance.now()<historyAt)return;
      historyBusy=true;historyAt=performance.now()+(waiting?1000:5000);
      try{await io.history();}catch(e){}finally{historyBusy=false;}
    }
    async function tick(){
      if(!active())return;
      if(code&&code!==io.game()){code='';issue='';deadline=0;latest='';signature='';waiting='';io.setSeconds(0);io.rows([],0);retryAt=0;}
      var now=performance.now();
      if(issue){var left=Math.max(0,Math.ceil((deadline-now)/1000));if(left!==last){last=left;io.setSeconds(left);if(left<=5)io.sound(left);}}
      if((!issue||now>=deadline)&&now>=retryAt&&!busy){
        busy=true;retryAt=now+1000;
        try{await io.issue();}catch(e){}finally{
          busy=false;if(performance.now()>=deadline){failures++;retryAt=performance.now()+Math.min(5000,1000*Math.max(1,failures));event('retry34');}
        }
      }
      await history();event('round34');
    }
    function start(){if(!timer&&!dead)timer=setInterval(function(){tick().catch(function(){});},250);}
    function stop(){dead=true;if(timer)clearInterval(timer);timer=null;}
    function visible(){if(!document.hidden){retryAt=0;historyAt=0;tick().catch(function(){});}}
    document.addEventListener('visibilitychange',visible);
    return {acceptIssue:acceptIssue,received:received,filter:filter,apply:apply,tick:tick,start:start,
      matches:function(g){return g===code&&!!issue;},stop:function(){stop();document.removeEventListener('visibilitychange',visible);}};
  };

  // v35 UI-only: label and header controls, using the native sound ref/router.
  var labels35=[],logos35=[];
  var headset35='<svg viewBox="0 0 40 40" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 23v-5a15 15 0 0 1 30 0v5M9 18v-2a11 11 0 0 1 22 0v2"/><rect x="4" y="19" width="6" height="11" rx="2.5"/><rect x="30" y="19" width="6" height="11" rx="2.5"/><path d="M10 21v5a10 10 0 0 0 20 0v-5M13 18c5 1 9-1 12-5l4 5M13 24h2m10 0h2m-12 6c3 2 7 2 10 0M33 30v2c0 3-5 5-11 5"/><rect x="18" y="34" width="5" height="3" rx="1.5"/></svg>';
  var voice35='<svg viewBox="0 0 40 40" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M27 5a16 16 0 1 1-14 0M16 15l10-3v14M16 15v14M16 18l10-3"/><ellipse cx="12.5" cy="29" rx="3.5" ry="2.5"/><ellipse cx="22.5" cy="26" rx="3.5" ry="2.5"/><path d="M20 2v7m-3-3 3 3 3-3"/><path class="mute-line35" d="M5 5l30 30" stroke-width="2.1"/></svg>';
  function nativeSound35(){
    var section=document.querySelector('.history'),owner=section&&historyOwner(section);
    for(var p=owner;p;p=p.parent){
      var provides=p.provides;if(!provides)continue;
      var keys=Reflect.ownKeys(provides);
      for(var i=0;i<keys.length;i++){
        var ctx=provides[keys[i]];
        if(ctx&&ctx.soundEffects&&ctx.gameCode&&ctx.historyIssues&&ctx.gameCode.value===activeGame()&&typeof ctx.soundEffects.value==='boolean')return ctx.soundEffects;
      }
    }
    return null;
  }
  function support35(){
    var app=document.getElementById('app'),vue=app&&app.__vue_app__,router=vue&&vue.config.globalProperties.\$router;
    if(router){Promise.resolve(router.push(router.hasRoute&&router.hasRoute('workOrder')?{name:'workOrder'}:'/workOrder')).catch(function(){location.assign('/workOrder');});}
    else location.assign('/workOrder');
  }
  function headerUI35(){
    if(!/^\\/WinGo\\//i.test(location.pathname)){
      document.querySelectorAll('[data-13l-controls35]').forEach(function(el){el.remove();});
      labels35.forEach(function(item){if(item.node.nodeValue==='Deposit')item.node.nodeValue=item.before;});labels35=[];logos35.forEach(function(item){if(item.style===null)item.node.removeAttribute('style');else item.node.setAttribute('style',item.style);});logos35=[];return;
    }
    document.querySelectorAll('.Wallet__C-balance-l3 > :nth-child(2)').forEach(function(button){
      // Change only the native text node; preserve click handlers and recharge route.
      Array.from(button.childNodes).forEach(function(node){if(node.nodeType===3&&/^\\s*recharge\\s*\$/i.test(node.nodeValue)){labels35.push({node:node,before:node.nodeValue});node.nodeValue='Deposit';}});
    });
    document.querySelectorAll('.game-header').forEach(function(header){
      // This actual site's header has head-left/logo + recharge head-right.
      if(!header.querySelector('.head-left'))return;
      var tools=header.querySelector('[data-13l-controls35]');
      if(!tools){
        tools=document.createElement('div');tools.setAttribute('data-13l-controls35','');tools.className='header-controls35';
        var support=document.createElement('button');support.type='button';support.className='header-service35';support.setAttribute('aria-label','Customer service');support.title='Customer service';support.innerHTML=headset35;support.addEventListener('click',support35);
        var voice=document.createElement('button');voice.type='button';voice.className='header-voice35';voice.innerHTML=voice35;
        voice.addEventListener('click',function(){var sound=nativeSound35();if(sound){sound.value=!sound.value;headerUI35();ping('audio35 '+activeGame()+' enabled='+(sound.value?1:0));}});
        tools.append(support,voice);header.appendChild(tools);
      }
      var sound=nativeSound35(),voice=tools.querySelector('.header-voice35'),on=!!(sound&&sound.value);
      voice.disabled=!sound;voice.setAttribute('aria-pressed',on?'true':'false');voice.setAttribute('aria-label',on?'Turn sound off':'Turn sound on');voice.title=sound?(on?'Turn sound off':'Turn sound on'):'Sound controls loading';
      var logo=header.querySelector('img.logo'),r=logo&&logo.getBoundingClientRect();
      ping('ui35 '+activeGame()+' controls=2 soundReady='+(sound?1:0),'logo='+(r?Math.round(r.width)+'x'+Math.round(r.height):'missing')+';deposit='+Array.from(document.querySelectorAll('.Wallet__C-balance-l3 > :nth-child(2)')).some(function(e){return e.textContent.trim()==='Deposit';}));
    });
  }

  function headFix(){
    if(!/^\\/WinGo\\//i.test(location.pathname))return;
    // A scrolled clock/ball is NEVER a header logo. Repair old marked clocks.
    document.querySelectorAll('.timer-cards img[style*="13lc"]').forEach(function(im){
      ['position','left','top','transform','max-width','height','max-height','z-index'].forEach(function(k){im.style.removeProperty(k);});
      var p=im.parentElement;
      while(p&&p.closest('.timer-cards')){if(p.style.getPropertyPriority('position')==='important')p.style.removeProperty('position');p=p.parentElement;}
      im.setAttribute('style',(im.getAttribute('style')||'').replace(/\\/\\*13lc\\*\\//g,''));
    });
    document.querySelectorAll('.game-header,.head-main,.navbar__content,.van-nav-bar').forEach(function(header){
      if(header.closest('.timer-cards,.Betting__C,.Wallet__C,.history'))return;
      var im=header.querySelector('img.logo,.logo img,.head-logo img,img[alt*="13L" i],img[src*="logo" i]');
      if(im&&!im.closest('.timer-cards,.Wallet__C')){
        if(!logos35.some(function(item){return item.node===im;}))logos35.push({node:im,style:im.getAttribute('style')});
        if(getComputedStyle(header).position==='static')header.style.setProperty('position','relative','important');
        var p=im.parentElement;
        while(p&&p!==header){p.style.setProperty('position','static','important');p=p.parentElement;}
        [['position','absolute'],['left','50%'],['top','50%'],['transform','translate(-50%,-50%)'],['width','2.13333rem'],['max-width','2.13333rem'],['height','.8rem'],['max-height','.8rem'],['z-index','2']].forEach(function(k){im.style.setProperty(k[0],k[1],'important');});
      }
      header.querySelectorAll('a,button,.deposit').forEach(function(el){
        if((el.textContent||'').trim().toLowerCase()==='deposit')el.style.setProperty('display','none','important');
      });
    });
    headerUI35();
    ping('header34 '+activeGame()+' strayClocks='+document.querySelectorAll('.timer-cards img[style*="13lc"]').length);
  }

  // v30: Give ONLY history's native KeepAlive a game key. A game switch then
  // destroys old row/page/chart state; late requests belong to unmounted views.
  // Betting/header components, wallet, core modules and native row templates stay intact.
  function activeGame(){
    var stateCode=window.state&&window.state.gameCode;
    var route=(location.pathname||'').match(/\\/(?:WinGo|TrxWinGo)\\/([^/?#]+)/i);
    var code=String(stateCode||(route&&route[1])||'');
    return /^(?:WinGo|TrxWinGo)_(?:30S|1M|3M|5M|10M)\$/i.test(code)?code:'';
  }
  function hasHistoryClass(vnode){
    var cls=vnode&&vnode.props&&vnode.props.class;
    return typeof cls==='string'&&/(^|\\s)history(\\s|\$)/.test(cls);
  }
  function keyHistory(vnode,game,inside){
    if(!vnode||typeof vnode!=='object')return 0;
    if(Array.isArray(vnode)){var total=0;for(var i=0;i<vnode.length;i++)total+=keyHistory(vnode[i],game,inside);return total;}
    inside=inside||hasHistoryClass(vnode);
    if(inside&&vnode.type&&vnode.type.__isKeepAlive){
      vnode.key='13l-history:'+game;
      vnode.props=Object.assign({},vnode.props||{},{key:vnode.key});
      return 1;
    }
    return Array.isArray(vnode.children)?keyHistory(vnode.children,game,inside):0;
  }
  function historyOwner(section){
    if(section.__vueParentComponent)return section.__vueParentComponent;
    // Vue production builds omit DOM.__vueParentComponent. Follow the mounted
    // root VNode instead; never depend on minified component variable names.
    var app=document.getElementById('app'),root=app&&app._vnode;
    var seen=new Set(),budget=5000;
    function walk(v,owner){
      if(!v||typeof v!=='object'||--budget<0||seen.has(v))return null;
      seen.add(v);
      if(Array.isArray(v)){for(var i=0;i<v.length;i++){var hit=walk(v[i],owner);if(hit)return hit;}return null;}
      if(v.el===section&&hasHistoryClass(v))return owner;
      if(v.component){var child=walk(v.component.subTree,v.component);if(child)return child;}
      if(v.suspense){var branch=walk(v.suspense.activeBranch,owner);if(branch)return branch;}
      return walk(v.children,owner);
    }
    return walk(root,null);
  }
  function installGameKeys(){
    if(!gamePage()||!activeGame())return;
    var sections=document.querySelectorAll('.history');
    for(var i=0;i<sections.length;i++){
      var owner=historyOwner(sections[i]);
      if(!owner||owner._13lGameKey30||typeof owner.render!=='function')continue;
      // Limit this adapter to a render tree that actually owns history + KeepAlive.
      function containsHistoryCache(v,inside){
        if(!v||typeof v!=='object')return false;
        if(Array.isArray(v))return v.some(function(x){return containsHistoryCache(x,inside);});
        inside=inside||hasHistoryClass(v);
        return !!(inside&&v.type&&v.type.__isKeepAlive)||containsHistoryCache(v.children,inside);
      }
      if(!containsHistoryCache(owner.subTree,false))continue;
      owner._13lGameKey30=true;
      (function(instance,render){
        instance.render=function(){
          var tree=render.apply(this,arguments);
          // Reading the native reactive gameCode here registers a render dependency.
          var game=activeGame(),count=game?keyHistory(tree,game,false):0;
          if(count&&instance._13lGameSeen30!==game){
            instance._13lGameSeen30=game;
            ping('key30 '+game+' historyScopes='+count);
          }
          return tree;
        };
        if(instance.proxy&&instance.proxy.\$forceUpdate)instance.proxy.\$forceUpdate();
      })(owner,owner.render);
    }
  }

  function mount(){gate();installGameKeys();if(gamePage()){headFix();ping('boot35 '+location.pathname.slice(0,44));requestScan();}}
  function requestScan(){if(pending)return;pending=true;requestAnimationFrame(function(){pending=false;installGameKeys();inspect();});}
  // Read-only diagnostics: the native component owns period/time/amount and pagination.
  // No JWT scan, all-game fetch, guessed amount matching or Vue textContent mutation.
  new MutationObserver(function(records){
    for(var i=0;i<records.length;i++){
      var el=records[i].target;
      if(records[i].type==='childList'||(el.closest&&el.closest('.history,.my_r,.MyGameRecord__C'))){requestScan();break;}
    }
  }).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
  ['pushState','replaceState'].forEach(function(name){
    var original=history[name];history[name]=function(){var r=original.apply(this,arguments);mount();return r;};
  });
  window.addEventListener('popstate',mount);window.addEventListener('hashchange',mount);
  window.addEventListener('resize',requestScan);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)mount();});
  setInterval(function(){if(!document.hidden){if(gamePage())headFix();inspect();}},900);
  if(document.fonts&&document.fonts.addEventListener)document.fonts.addEventListener('loadingdone',function(){
    Object.keys(lastPing).forEach(function(k){if(k.indexOf('font31 ')===0)delete lastPing[k];});requestScan();
  });
  mount();
})();
JS;

// v34: user authorised a targeted native WinGo timer/refresh correction.
// Exact before/after hashes, backup, and atomic write. Fail closed on unknown builds.
$native34 = json_decode((string)@file_get_contents($R . '/tools/13l-native34.json'), true);
$native34status = 'FAIL missing patch manifest';
if (is_array($native34)) {
    $np = $R . '/js/dragon-65oA2ftS.js';
    $ns = (string)@file_get_contents($np);
    $nh = hash('sha256', $ns);
    if ($nh === $native34['after_sha256']) $native34status = 'already applied';
    elseif ($nh === $native34['before_sha256']) {
        $ok34 = true;
        foreach ($native34['replacements'] as $pair) {
            if (substr_count($ns, $pair['old']) !== 1) { $ok34 = false; break; }
            $ns = str_replace($pair['old'], $pair['new'], $ns);
        }
        if ($ok34 && hash('sha256', $ns) === $native34['after_sha256'] &&
            @copy($np, $np . '.bak34') && @file_put_contents($np . '.tmp34', $ns) === strlen($ns) && @rename($np . '.tmp34', $np)) {
            $native34status = 'applied ' . strlen($ns) . ' B';
        } else $native34status = 'FAIL validation/backup/write';
    } else $native34status = 'FAIL unknown native build ' . $nh;
}
if (strpos($native34status, 'FAIL') === 0) {
    echo "HISTFIX v35: native34 " . $native34status . "\n";
    return;
}

$target = $R . '/js/13l-hist25.js';
@file_put_contents($target, $js);
$out = "HISTFIX v35\nNative34: " . $native34status . "\n";
$out .= "  js/13l-hist25.js: REWRITTEN " . (is_file($target) ? filesize($target) . ' B ✓' : 'FAIL!') . " (URL same, no-cache headers se phone fresh lega)\n";

// index.html me tag check (agar kisi wajah se na ho)
$idx = $R . '/index.html';
$h = (string)file_get_contents($idx);
$changed = false;
if (strpos($h, '13l-hist25.js') === false) {
    $tag = '<script src="/js/13l-hist25.js?cb=' . $CB . '"></script>';
    $h2 = stripos($h, '</body>') !== false ? preg_replace('#</body>#i', $tag . '</body>', $h, 1) : $h . $tag;
    if ($h2 !== $h) { @copy($idx, $idx . '.bak26'); $h = $h2; $changed = true; $out .= "  index.html: <script> add ✓\n"; }
} else $out .= "  index.html: hist25 script linked ✓\n";
if ($changed) @file_put_contents($idx, $h);

// .htaccess no-cache dobara confirm
$hta = $R . '/.htaccess';
$cur = is_file($hta) ? (string)file_get_contents($hta) : '';
if (strpos($cur, '13L-NO-CACHE') === false) {
    @file_put_contents($hta, $cur . "\n# BEGIN 13L-NO-CACHE\n<IfModule mod_headers.c>\n<FilesMatch \"\\.(html?|js|css)$\">\nHeader set Cache-Control \"no-cache, must-revalidate\"\n</FilesMatch>\n</IfModule>\n# END 13L-NO-CACHE\n");
    $out .= "  .htaccess: no-cache added ✓\n";
} else $out .= "  .htaccess: no-cache present ✓\n";

// netlog trim
$nl = $R . '/api/_core/.netlog';
if (is_file($nl) && filesize($nl) > 200000) {
    @file_put_contents($nl, implode('', array_slice((array)file($nl), -600)));
    $out .= "  netlog trimmed\n";
}
$out .= "Status: " . (strpos((string)file_get_contents($target), '13L-HIST25-v35') !== false ? 'v35 live ✓' : 'MISSING!') . "\n";
echo $out;
