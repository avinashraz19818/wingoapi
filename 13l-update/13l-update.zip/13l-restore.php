<?php
// =====================================================================
// 13L RESTORE v20.1 — skinsync ka asar khatam:
//  (1) index.html  ← index.html.bakskin se wapas (13L ka asli skin link)
//  (2) entry js    ← agar skinsync ne overwrite kiya tha to .bak13l se wapas
//  (3) report      : index.html ke saare /js //css references exist karte
//                    hain ya nahi + injected-marker status.
//  Data (DB, results, bets) ko isne kabhi chhua hi nahi — sirf static files.
// URL: https://13l.club9.eu.cc/13l-restore.php?key=13l2026
// =====================================================================
if (($_GET['key'] ?? '') !== '13l2026') { http_response_code(403); exit('wrong key'); }
@set_time_limit(300);
header('Content-Type: text/plain; charset=utf-8');
$R = rtrim(__DIR__, '/');
$idx = $R . '/index.html';

echo "RESTORE v20.1\n";

// ---- (1) index.html wapas ----
$bak = $idx . '.bakskin';
if (is_file($bak)) {
    $cur = (string)file_get_contents($idx);
    $old = (string)file_get_contents($bak);
    if ($cur !== $old) {
        @file_put_contents($idx . '.broken13l', $cur);      // broken copy safe rakho (rollback of rollback)
        if (@file_put_contents($idx, $old) !== false) echo "index.html: RESTORED from bakskin (" . strlen($cur) . " → " . strlen($old) . " B)\n";
        else echo "index.html: WRITE FAIL!! (cPanel permissions dekh)\n";
    } else echo "index.html: already restored (same as bakskin)\n";
} else {
    echo "index.html: bakskin backup NAHI mila — matlab skinsync ne html chhua hi nahi; theek hai.\n";
}

// ---- entry js identify + restore ----
$html = (string)file_get_contents($idx);
$entry = null;
if (preg_match('#<script[^>]+src="(/js/index-[\w\-]+\.js)"#i', $html, $m)) $entry = $R . $m[1];
if (!$entry) {
    $g = glob($R . '/js/index-*.js');
    if ($g) { usort($g, fn($a, $b) => strcmp(basename($a), basename($b))); $entry = $g[0]; }
}
if ($entry && is_file($entry)) {
    $c = (string)file_get_contents($entry);
    $bn = basename($entry);
    $has16 = strpos($c, '13L-JSINJECT-v16') !== false;
    $has17 = strpos($c, '13L-UNCLIP-v17') !== false || strpos($c, '13L-V19') !== false;
    if (!$has16 && !$has17 && is_file($entry . '.bak13l')) {
        @copy($entry, $entry . '.skinsync13l');
        if (@copy($entry . '.bak13l', $entry)) echo "entry js ($bn): OVERWRITE mila — .bak13l se restore kiya\n";
    } elseif ($has16 || $has17) {
        echo "entry js ($bn): patches intact (v16/v17: " . ($has16 ? 'v16' : '-') . "/" . ($has17 ? 'v17' : '-') . ")\n";
    } else {
        echo "entry js ($bn): overwrite hua lagta hai par .bak13l nahi mila — content theek hai?\n";
    }
} else echo "entry js: index.html me /js/index-*.js link hi nahi mila!\n";

// ---- (3) saare references exist? ----
$missing = 0; $checked = 0;
if (preg_match_all('#(?:src|href)="(/(?:js|css)/[^"]+\.(?:js|css))"#i', $html, $mm)) {
    foreach (array_unique($mm[1]) as $u) {
        $checked++;
        if (!is_file($R . $u)) { $missing++; echo "  MISSING: $u\n"; }
    }
}
echo "references: {$checked} checked, {$missing} missing\n";

// ---- css inject status (skinsync ne theme css overwrite kiya to marker gayab) ----
$files = glob($R . '/css/*.css') ?: [];
$n14 = 0;
foreach ($files as $f) if (strpos((string)@file_get_contents($f), '13L-INJECT-v14') !== false) $n14++;
echo "css v14 marker: {$n14} / " . count($files) . " files" . ($n14 < count($files) ? "  (kam hai to 13l-cssinject.php + 13l-allfix.php ek baar aur chala lena — marker-safe, dobara duplicate nahi padega)" : " ✓") . "\n";

// ---- config.js intact? ----
echo "config.js: " . (is_file($R . '/webapi/kv/config.js') ? "present ✓" : "MISSING!") . "\n";
echo "\nAb app fully close → reopen. Site 13L ke purane (pre-skinsync) skin par wapas.\n";
echo "Agar kuch custom fix (share-fix etc) gayab lage to bata — deploy-backup folder se poora restore aur kar sakta hoon.\n";
