<?php
// 13L result bridge config — PRECONFIGURED (v4-final).
// Draws are mirrored from the official AR feed, same source the reference
// sites use. To disable the bridge: empty the base ('') — the site then
// falls back to its own deterministic draw and keeps running.
return [
    'mode' => 'ar',
    'base' => 'https://draw.ar-lottery01.com',
    'key'  => '',
];
