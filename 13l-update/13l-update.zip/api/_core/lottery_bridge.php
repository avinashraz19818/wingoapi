<?php
// ============================================================
// 13L Lottery Result Bridge (draw results ONLY)
//
// Mirrors official draw results from the same lottery API (wingoapi
// provider engine) that the DhaniWin site uses. Users, wallet, bets,
// payouts stay 100% LOCAL on 13L555.
//
// TO ENABLE: copy api/_core/bridge.example.php  ->  api/_core/bridge.php
// and fill the provider URL (the same value that DhaniWin's admin panel
// has in its "lottery_upstream_url" setting).
//
// If bridge.php is missing or the base is empty, the engine keeps using
// the built-in deterministic draw (same issue numbers either way).
// ============================================================

function lb_cfg(): array
{
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    $cfg = ['base' => '', 'key' => '', 'timeout' => 4];
    $f = __DIR__ . '/bridge.php';
    if (is_file($f)) {
        $u = @include $f;
        if (is_array($u)) $cfg = array_merge($cfg, $u);
    }
    return $cfg;
}

function lb_enabled(): bool
{
    $b = trim((string)(lb_cfg()['base'] ?? ''));
    return $b !== '' && (stripos($b, 'http://') === 0 || stripos($b, 'https://') === 0);
}

function lb_call(string $action, array $input = []): ?array
{
    $cfg = lb_cfg();
    $base = trim((string)($cfg['base'] ?? ''));
    if ($base === '') return null;
    $url = $base . (strpos($base, '?') === false ? '?' : '&') . 'action=' . rawurlencode($action);
    $payload = json_encode($input, JSON_UNESCAPED_SLASHES);
    $hdrs = [
        'Accept: application/json',
        'Content-Type: application/json',
        'X-Api-Key: ' . (string)($cfg['key'] ?? ''),
        'Origin: https://' . ($_SERVER['HTTP_HOST'] ?? ''),
    ];
    $raw = null;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => $hdrs,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT        => max(2, min(8, (int)($cfg['timeout'] ?? 4))),
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code !== 200 || !$raw) return null;
    } else {
        $ctx = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => implode("\r\n", $hdrs),
                'content' => $payload,
                'timeout' => max(2, min(8, (int)($cfg['timeout'] ?? 4))),
                'ignore_errors' => true,
            ],
            'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
        ]);
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false || $raw === '') return null;
    }
    $json = json_decode((string)$raw, true);
    return is_array($json) ? $json : null;
}

// Backfill recent draws from the provider into the local lottery_results
// table (INSERT IGNORE keeps older/manual rows untouched). Returns rows added.
function lb_sync(string $gameCode, int $limit = 20): int
{
    $conn = db();
    if (!$conn || !lb_enabled()) return 0;
    $answer = lb_call('GetHistoryIssuePage', [
        'gameCode' => le_norm_game($gameCode),
        'pageSize' => $limit,
        'pageNo'   => 1,
    ]);
    $list = $answer['data']['list'] ?? null;
    if (!is_array($list) || !$list) return 0;
    $saved = 0;
    foreach ($list as $item) {
        $issue  = (string)($item['issueNumber'] ?? $item['issue_number'] ?? '');
        $prem   = trim((string)($item['premium'] ?? $item['number'] ?? $item['result'] ?? ''));
        if ($issue === '' || $prem === '') continue;
        $stmt = @$conn->prepare('INSERT IGNORE INTO lottery_results(game_code, issue_number, premium, number, color, big_small, sum_value, open_time, created_at) VALUES(?,?,?,?,?,?,?,?,NOW())');
        if (!$stmt) continue;
        $d = le_result_detail($gameCode, $prem, $issue);
        $premium = (string)$d['premium'];
        $number  = (string)$d['number'];
        $color   = (string)$d['color'];
        $bigSmall = (string)$d['bigSmall'];
        $sum = (int)$d['sum'];
        $stmt->bind_param('ssssssi', $gameCode, $issue, $premium, $number, $color, $bigSmall, $sum);
        if (@$stmt->execute()) $saved++;
    }
    return $saved;
}

// One specific issue from the provider (used when history sync missed it).
function lb_fetch_result(string $gameCode, string $issueNumber): ?string
{
    if (!lb_enabled() || $issueNumber === '') return null;
    $answer = lb_call('GetWinTheLotteryResult', [
        'gameCode'    => le_norm_game($gameCode),
        'issueNumber' => $issueNumber,
    ]);
    if (!$answer || !isset($answer['data'])) return null;
    $row = (is_array($answer['data']) && isset($answer['data'][0]) && is_array($answer['data'][0])) ? $answer['data'][0] : $answer['data'];
    if (!is_array($row)) return null;
    $prem = trim((string)($row['premium'] ?? $row['number'] ?? ''));
    return $prem !== '' ? $prem : null;
}

// Provider's displayed issue (already 1-period-lagged, same numbering).
// Cached for 3 seconds per game so page loads never block on the network.
function lb_issue_data(string $gameCode): ?array
{
    if (!lb_enabled()) return null;
    $key = 'lbissue_' . preg_replace('/[^A-Za-z0-9_]/', '', $gameCode);
    $cacheFile = sys_get_temp_dir() . '/' . $key . '.json';
    if (is_file($cacheFile) && (time() - (int)@filemtime($cacheFile)) < 3) {
        $j = json_decode((string)@file_get_contents($cacheFile), true);
        if (is_array($j) && !empty($j['issueNumber'])) return $j;
    }
    $answer = lb_call('GetGameIssue', ['gameCode' => le_norm_game($gameCode)]);
    $data = $answer['data'] ?? null;
    if (!is_array($data) || empty($data['issueNumber']) || !isset($data['endTime'])) return null;
    $data['diif'] = $data['diif'] ?? 0;
    @file_put_contents($cacheFile, json_encode($data, JSON_UNESCAPED_SLASHES));
    return $data;
}
