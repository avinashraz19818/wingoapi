<?php
// ============================================================
// 13L Lottery Result Bridge — mirrors the OFFICIAL AR draw feed
// (https://draw.ar-lottery01.com) so results on 13L555 are the
// exact same draws the reference/DhaniWin sites show.
//
// Wallet, users, bets, payouts stay 100% local.
// If the feed is unreachable, the local deterministic draw keeps
// the game running; rows sync back automatically after.
//
// Config lives in bridge.php (same folder).
// ============================================================

function lb_cfg(): array
{
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    $cfg = ['mode' => '', 'base' => '', 'key' => '', 'timeout' => 4];
    $f = __DIR__ . '/bridge.php';
    if (is_file($f)) {
        $u = @include $f;
        if (is_array($u)) $cfg = array_merge($cfg, $u);
    }
    return $cfg;
}

function lb_enabled(): bool
{
    $b = trim((string)(lb_cfg()['base'] ?? ''));
    return $b !== '' && (stripos($b, 'http://') === 0 || stripos($b, 'https://') === 0);
}

// 'WinGo_1M' => ['WinGo','WinGo_1M']; provider only serves these families.
function lb_game_family(string $gameCode): ?array
{
    $g = le_norm_game($gameCode);
    if ($g === '') return null;
    $family = null;
    if (stripos($g, 'TrxWinGo') === 0) $family = 'TrxWinGo';
    elseif (stripos($g, 'WinGo') === 0) $family = 'WinGo';
    elseif (stripos($g, 'K3') === 0) $family = 'K3';
    elseif (stripos($g, 'D5') === 0 || stripos($g, '5D') === 0) $family = 'D5';
    if ($family === null) return null; // MotoRace etc. stay on the local draw
    return [$family, $g];
}

function lb_http_get(string $url, array $headers): ?string
{
    $cfg = lb_cfg();
    $timeout = max(2, min(8, (int)($cfg['timeout'] ?? 4)));
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($code === 200 && $raw) ? (string)$raw : null;
    }
    $ctx = stream_context_create([
        'http' => ['method' => 'GET', 'header' => implode("\r\n", $headers), 'timeout' => $timeout, 'ignore_errors' => true],
        'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
    ]);
    $raw = @file_get_contents($url, false, $ctx);
    return ($raw === false || $raw === '') ? null : (string)$raw;
}

// Fetch the provider's history JSON (10s file cache per game so a burst of
// requests hits the network at most once). Returns decoded list or null.
function lb_fetch_list(string $gameCode, int $cacheTtl = 10): ?array
{
    if (!lb_enabled()) return null;
    $mode = (string)(lb_cfg()['mode'] ?? 'ar');
    $pair = lb_game_family($gameCode);
    if ($mode !== 'ar') return null;
    if ($pair === null) return null;
    [$family, $code] = $pair;
    $cacheFile = sys_get_temp_dir() . '/lbhist_' . preg_replace('/[^A-Za-z0-9_]/', '', $code) . '.json';
    if ($cacheTtl > 0 && is_file($cacheFile) && (time() - (int)@filemtime($cacheFile)) < $cacheTtl) {
        $j = json_decode((string)@file_get_contents($cacheFile), true);
        if (is_array($j) && isset($j['list']) && is_array($j['list'])) return $j['list'];
    }
    $base = rtrim((string)lb_cfg()['base'], '/');
    $url  = $base . '/' . $family . '/' . $code . '/GetHistoryIssuePage.json';
    $hdrs = [
        'Accept: application/json',
        'Referer: https://ar-lottery01.com/',
        'Origin: https://ar-lottery01.com',
        'Accept-Language: en-US,en;q=0.9',
    ];
    $raw = lb_http_get($url, $hdrs);
    if ($raw === null) return null;
    $j = json_decode($raw, true);
    $list = null;
    if (is_array($j)) {
        if (isset($j['data']['list']) && is_array($j['data']['list'])) $list = $j['data']['list'];
        elseif (isset($j['list']) && is_array($j['list'])) $list = $j['list'];
    }
    if ($list === null) return null;
    @file_put_contents($cacheFile, json_encode(['list' => $list], JSON_UNESCAPED_SLASHES));
    return $list;
}

// Insert provider draws into lottery_results (INSERT IGNORE keeps any
// admin-set rows untouched). Returns number of NEW rows saved.
function lb_sync(string $gameCode, int $limit = 30): int
{
    $conn = db();
    if (!$conn) return 0;
    $list = lb_fetch_list($gameCode);
    if (!$list) return 0;
    $saved = 0;
    $count = 0;
    foreach ($list as $item) {
        if ($count++ >= $limit) break;
        $issue = (string)($item['issueNumber'] ?? $item['issue_number'] ?? '');
        $prem  = trim((string)($item['premium'] ?? $item['number'] ?? $item['result'] ?? ''));
        if ($issue === '' || $prem === '') continue;
        $d = le_result_detail($gameCode, $prem, $issue);
        $premium  = (string)$d['premium'];
        $number   = (string)$d['number'];
        $color    = (string)$d['color'];
        $bigSmall = (string)$d['bigSmall'];
        $sum      = (int)$d['sum'];
        $stmt = @$conn->prepare('INSERT IGNORE INTO lottery_results(game_code, issue_number, premium, number, color, big_small, sum_value, open_time, created_at) VALUES(?,?,?,?,?,?,?,?,NOW())');
        if (!$stmt) continue;
        $stmt->bind_param('ssssssi', $gameCode, $issue, $premium, $number, $color, $bigSmall, $sum);
        if (@$stmt->execute() && $stmt->affected_rows > 0) $saved++;
    }
    return $saved;
}

// Specific issue lookup — only answers if it is inside the (cached) feed.
function lb_fetch_result(string $gameCode, string $issueNumber, int $cacheTtl = 5): ?string
{
    if ($issueNumber === '') return null;
    $list = lb_fetch_list($gameCode, max(0, $cacheTtl));
    if (!$list) return null;
    foreach ($list as $item) {
        $issue = (string)($item['issueNumber'] ?? $item['issue_number'] ?? '');
        if ($issue !== $issueNumber) continue;
        $prem = trim((string)($item['premium'] ?? $item['number'] ?? ''));
        return $prem !== '' ? $prem : null;
    }
    return null;
}

// Provider's issue payload passthrough — not used in 'ar' mode (the feed has
// no countdown endpoint; 13L's local lagged issue already matches the
// provider numbering exactly). Kept for future engines exposing one.
function lb_issue_data(string $gameCode): ?array
{
    return null;
}
