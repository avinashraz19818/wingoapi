<?php
// ============================================================
// 13L Lottery Result Bridge v5 — mirrors official draws.
// Two modes (picked automatically in bridge.php):
//   mode 'ar'  : direct AR draw feed (https://draw.ar-lottery01.com)
//   mode 'api' : user's own draw provider (wingoapi engine, ?action=
//                protocol — the same URL DhaniWin uses)
// Wallet, users, bets, payouts stay 100% local. If the feed is
// unreachable the local deterministic draw keeps the game running.
// ============================================================

function lb_cfg(): array
{
    $cfg = ['mode' => 'ar', 'base' => '', 'key' => '', 'timeout' => 5];
    $f = __DIR__ . '/bridge.php';
    if (is_file($f)) {
        $u = @include $f;
        if (is_array($u)) $cfg = array_merge($cfg, $u);
    }
    return $cfg;
}

function lb_enabled(): bool
{
    $b = trim((string)(lb_cfg()['base'] ?? ''));
    return $b !== '' && (stripos($b, 'http://') === 0 || stripos($b, 'https://') === 0);
}

function lb_game_family(string $gameCode): ?array
{
    $g = le_norm_game($gameCode);
    if ($g === '') return null;
    $family = null;
    if (stripos($g, 'TrxWinGo') === 0) $family = 'TrxWinGo';
    elseif (stripos($g, 'WinGo') === 0) $family = 'WinGo';
    elseif (stripos($g, 'K3') === 0) $family = 'K3';
    elseif (stripos($g, 'D5') === 0 || stripos($g, '5D') === 0) $family = 'D5';
    if ($family === null) return null; // MotoRace etc. stay on the local draw
    return [$family, $g];
}

function lb_http(string $url, array $headers, bool $post = false, string $payload = ''): ?array
{
    $cfg = lb_cfg();
    $timeout = max(2, min(10, (int)($cfg['timeout'] ?? 5)));
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        ];
        if ($post) { $opts[CURLOPT_POST] = true; $opts[CURLOPT_POSTFIELDS] = $payload; }
        curl_setopt_array($ch, $opts);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($code !== 200 || !$raw) return ['error' => 'http ' . $code . ($err ? ' / ' . $err : '')];
        return ['body' => (string)$raw];
    }
    $opts = ['http' => [
        'method' => $post ? 'POST' : 'GET',
        'header' => implode("\r\n", $headers),
        'timeout' => $timeout,
        'ignore_errors' => true,
        'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    ]];
    if ($post) $opts['http']['content'] = $payload;
    $ctx = stream_context_create($opts + ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false || $raw === '') return ['error' => 'stream fetch failed'];
    return ['body' => (string)$raw];
}

// ---- fetch a raw history list (no cache) ----
function lb_raw_list(string $gameCode): ?array
{
    if (!lb_enabled()) return null;
    $cfg = lb_cfg();
    $mode = (string)($cfg['mode'] ?? 'ar');
    $pair = lb_game_family($gameCode);
    if ($pair === null) return null;
    [$family, $code] = $pair;
    $base = rtrim((string)$cfg['base'], '/');

    if ($mode === 'api') {
        $url = $base . (strpos($base, '?') === false ? '?' : '&') . 'action=GetHistoryIssuePage';
        $hdrs = ['Accept: application/json', 'Content-Type: application/json', 'X-Api-Key: ' . (string)($cfg['key'] ?? ''), 'Origin: https://' . ($_SERVER['HTTP_HOST'] ?? '')];
        $res = lb_http($url, $hdrs, true, json_encode(['gameCode' => $code, 'pageSize' => 30, 'pageNo' => 1], JSON_UNESCAPED_SLASHES));
        if (!$res || isset($res['error'])) return null;
        $j = json_decode((string)$res['body'], true);
        if (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) return $j['data']['list'];
        if (is_array($j) && isset($j['list']) && is_array($j['list'])) return $j['list'];
        return null;
    }

    // mode 'ar' — direct feed, browser-like headers
    $hdrs = [
        'Accept: application/json',
        'Referer: https://ar-lottery01.com/',
        'Origin: https://ar-lottery01.com',
        'Accept-Language: en-US,en;q=0.9',
    ];
    $candidates = [
        $base . '/' . $family . '/' . $code . '/GetHistoryIssuePage.json',
        preg_replace('#^https://#', 'http://', $base) . '/' . $family . '/' . $code . '/GetHistoryIssuePage.json',
    ];
    foreach ($candidates as $url) {
        $res = lb_http($url, $hdrs);
        if (!$res || isset($res['error'])) continue;
        $j = json_decode((string)$res['body'], true);
        if (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) return $j['data']['list'];
        if (is_array($j) && isset($j['list']) && is_array($j['list'])) return $j['list'];
    }
    return null;
}

// ---- cached list for hot paths ----
function lb_fetch_list(string $gameCode, int $cacheTtl = 10): ?array
{
    if (!lb_enabled()) return null;
    $cacheFile = sys_get_temp_dir() . '/lbhist_' . preg_replace('/[^A-Za-z0-9_]/', '', le_norm_game($gameCode)) . '.json';
    if ($cacheTtl > 0 && is_file($cacheFile) && (time() - (int)@filemtime($cacheFile)) < $cacheTtl) {
        $j = json_decode((string)@file_get_contents($cacheFile), true);
        if (is_array($j) && isset($j['list']) && is_array($j['list'])) return $j['list'];
    }
    $list = lb_raw_list($gameCode);
    if ($list === null) return null;
    @file_put_contents($cacheFile, json_encode(['list' => $list], JSON_UNESCAPED_SLASHES));
    return $list;
}

function lb_sync(string $gameCode, int $limit = 30): int
{
    $conn = db();
    if (!$conn) return 0;
    $list = lb_fetch_list($gameCode, 15);
    if (!$list) return 0;
    $saved = 0;
    $count = 0;
    foreach ($list as $item) {
        if ($count++ >= $limit) break;
        $issue = (string)($item['issueNumber'] ?? $item['issue_number'] ?? '');
        $prem  = trim((string)($item['premium'] ?? $item['number'] ?? $item['result'] ?? ''));
        if ($issue === '' || $prem === '') continue;
        $d = le_result_detail($gameCode, $prem, $issue);
        $premium  = (string)$d['premium'];
        $number   = (string)$d['number'];
        $color    = (string)$d['color'];
        $bigSmall = (string)$d['bigSmall'];
        $sum      = (int)$d['sum'];
        $stmt = @$conn->prepare('INSERT INTO lottery_results(game_code, issue_number, premium, number, color, big_small, sum_value, open_time, created_at) VALUES(?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE premium=VALUES(premium), number=VALUES(number), color=VALUES(color), big_small=VALUES(big_small), sum_value=VALUES(sum_value)');
        if (!$stmt) continue;
        $stmt->bind_param('ssssssi', $gameCode, $issue, $premium, $number, $color, $bigSmall, $sum);
        if (@$stmt->execute() && $stmt->affected_rows > 0) $saved++;
    }
    return $saved;
}

function lb_fetch_result(string $gameCode, string $issueNumber, int $cacheTtl = 5): ?string
{
    if ($issueNumber === '' || !lb_enabled()) return null;
    $cfg = lb_cfg();
    if ((string)($cfg['mode'] ?? 'ar') === 'api') {
        $base = rtrim((string)$cfg['base'], '/');
        $url = $base . (strpos($base, '?') === false ? '?' : '&') . 'action=GetWinTheLotteryResult';
        $hdrs = ['Accept: application/json', 'Content-Type: application/json', 'X-Api-Key: ' . (string)($cfg['key'] ?? '')];
        $res = lb_http($url, $hdrs, true, json_encode(['gameCode' => le_norm_game($gameCode), 'issueNumber' => $issueNumber], JSON_UNESCAPED_SLASHES));
        if ($res && !isset($res['error'])) {
            $j = json_decode((string)$res['body'], true);
            $data = $j['data'] ?? null;
            if (is_array($data)) {
                $row = isset($data[0]) && is_array($data[0]) ? $data[0] : $data;
                $prem = trim((string)($row['premium'] ?? $row['number'] ?? ''));
                if ($prem !== '') return $prem;
            }
        }
    }
    $list = lb_fetch_list($gameCode, max(0, $cacheTtl));
    if (!$list) return null;
    foreach ($list as $item) {
        $issue = (string)($item['issueNumber'] ?? $item['issue_number'] ?? '');
        if ($issue !== $issueNumber) continue;
        $prem = trim((string)($item['premium'] ?? $item['number'] ?? ''));
        return $prem !== '' ? $prem : null;
    }
    return null;
}

// Provider-side issue payload passthrough — only the 'api' mode (wingoapi
// engine) has GetGameIssue; the 'ar' feed has no countdown endpoint and 13L's
// own lagged issue already matches its numbering 1:1.
function lb_issue_data(string $gameCode): ?array
{
    if (!lb_enabled()) return null;
    $cfg = lb_cfg();
    if ((string)($cfg['mode'] ?? 'ar') !== 'api') return null;
    $base = rtrim((string)$cfg['base'], '/');
    $url = $base . (strpos($base, '?') === false ? '?' : '&') . 'action=GetGameIssue';
    $hdrs = ['Accept: application/json', 'Content-Type: application/json', 'X-Api-Key: ' . (string)($cfg['key'] ?? '')];
    $res = lb_http($url, $hdrs, true, json_encode(['gameCode' => le_norm_game($gameCode)], JSON_UNESCAPED_SLASHES));
    if (!$res || isset($res['error'])) return null;
    $j = json_decode((string)$res['body'], true);
    $data = is_array($j) ? ($j['data'] ?? null) : null;
    if (!is_array($data) || empty($data['issueNumber']) || !isset($data['endTime'])) return null;
    $data['diif'] = $data['diif'] ?? 0;
    return $data;
}

// Diagnostic used by 13l-fixfeed.php: try a source right now.
function lb_probe(string $mode, string $base, string $key = ''): array
{
    $base2 = rtrim($base, '/');
    $list = null; $err = '';
    if ($mode === 'api') {
        $url = $base2 . (strpos($base2, '?') === false ? '?' : '&') . 'action=GetHistoryIssuePage';
        $hdrs = ['Accept: application/json', 'Content-Type: application/json', 'X-Api-Key: ' . $key];
        $res = lb_http($url, $hdrs, true, json_encode(['gameCode' => 'WinGo_1M', 'pageSize' => 5, 'pageNo' => 1]));
        if (!$res) $err = 'no response';
        elseif (isset($res['error'])) $err = $res['error'];
        else {
            $j = json_decode((string)$res['body'], true);
            if (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) $list = $j['data']['list'];
            elseif (is_array($j) && isset($j['list']) && is_array($j['list'])) $list = $j['list'];
            else $err = 'bad json: ' . substr((string)$res['body'], 0, 120);
        }
    } else {
        $url = $base2 . '/WinGo/WinGo_1M/GetHistoryIssuePage.json';
        $hdrs = ['Accept: application/json', 'Referer: https://ar-lottery01.com/', 'Origin: https://ar-lottery01.com', 'Accept-Language: en-US,en;q=0.9'];
        $res = lb_http($url, $hdrs);
        if (!$res) $err = 'no response';
        elseif (isset($res['error'])) $err = $res['error'];
        else {
            $j = json_decode((string)$res['body'], true);
            if (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) $list = $j['data']['list'];
            elseif (is_array($j) && isset($j['list']) && is_array($j['list'])) $list = $j['list'];
            else $err = 'bad json: ' . substr((string)$res['body'], 0, 120);
        }
    }
    if ($list === null) return ['ok' => false, 'url' => $url, 'error' => $err];
    $first = $list[0] ?? [];
    return ['ok' => true, 'url' => $url, 'rows' => count($list), 'sample_issue' => (string)($first['issueNumber'] ?? ''), 'sample_premium' => (string)($first['premium'] ?? $first['number'] ?? '')];
}
