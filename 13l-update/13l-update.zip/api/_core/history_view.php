<?php
// 13L v28 read-only WinGo view adapter. Native/DhaniWin field contract;
// provider rows only, no deterministic fallback, settlement or wallet writes.
function h28_closed_rows(array $raw, string $code, string $current): array
{
    $rows = [];
    foreach ($raw as $item) {
        if (!is_array($item)) continue;
        $issue = (string)($item['issueNumber'] ?? $item['issue_number'] ?? '');
        $rowCode = (string)($item['gameCode'] ?? $code);
        $premium = trim((string)($item['premium'] ?? $item['number'] ?? ''));
        if (le_norm_game($rowCode) !== $code || !preg_match('/^\d{17}$/D', $issue)) continue;
        if (substr($issue, 8, 5) !== le_game_prefix($code)) continue;
        // The current displayed period must NEVER appear before its timer closes.
        if (strcmp($issue, $current) >= 0 || !preg_match('/^[0-9]$/D', $premium)) continue;
        $n = (int)$premium;
        $rows[$issue] = [
            'issueNumber'=>$issue, 'issueNo'=>$issue, 'period'=>$issue,
            'gameCode'=>$code, 'premium'=>$premium, 'number'=>$n,
            'color'=>le_color_from_number($n), 'colour'=>le_color_from_number($n),
            'bigSmall'=>$n >= 5 ? 'Big' : 'Small', 'sum'=>$n,
            'openTime'=>$item['openTime'] ?? null,
        ];
    }
    krsort($rows, SORT_STRING);
    return array_values($rows);
}

function h28_statistics(array $rows): array
{
    $size = count($rows); $stats = [];
    for ($n = 0; $n < 10; $n++) {
        $missing = 0; $count = 0; $run = 0; $max = 0; $seen = false;
        foreach ($rows as $row) {
            if ((int)$row['number'] === $n) {
                $seen = true; $count++; $run++; $max = max($max, $run);
            } else {
                if (!$seen) $missing++;
                $run = 0;
            }
        }
        // Average absent-run length over observed gaps (including both ends).
        $stats[] = ['number'=>$n, 'missingCount'=>$missing,
            'avgMissing'=>round(($size-$count)/($count+1), 2),
            'openCount'=>$count, 'maxContinuous'=>$max, 'sampleCount'=>$size];
    }
    return $stats;
}

function h28_provider_rows(string $code): ?array
{
    if (!function_exists('lb_enabled') || !lb_enabled()) return null;
    // Explicit 100-row cache key: cannot reuse the older 30-row bridge cache.
    $raw = lb_fetch_list($code, 5, 100);
    if (!is_array($raw)) return null;
    $issue = function_exists('lb_issue_data') ? lb_issue_data($code) : null;
    $current = (string)($issue['issueNumber'] ?? le_issue_by_offset($code, 1));
    return h28_closed_rows($raw, $code, $current);
}

function h28_history_payload(array $rows, int $page): array
{
    $page = max(1, $page); $total = count($rows);
    return ['list'=>array_slice($rows, ($page-1)*10, 10), 'pageNo'=>$page,
        'pageSize'=>10, 'totalPage'=>(int)ceil($total/10), 'totalCount'=>$total,
        'source'=>'provider'];
}
