<?php
// 13L v28 read-only WinGo view adapter. Native/DhaniWin field contract;
// provider rows only, no deterministic fallback, settlement or wallet writes.
function h28_closed_rows(array $raw, string $code, string $current): array
{
    $rows = [];
    foreach ($raw as $item) {
        if (!is_array($item)) continue;
        $issue = (string)($item['issueNumber'] ?? $item['issue_number'] ?? '');
        $rowCode = (string)($item['gameCode'] ?? $code);
        $premium = trim((string)($item['premium'] ?? $item['number'] ?? ''));
        if (le_norm_game($rowCode) !== $code || !preg_match('/^\d{17}$/D', $issue)) continue;
        if (substr($issue, 8, 5) !== le_game_prefix($code)) continue;
        // The current displayed period must NEVER appear before its timer closes.
        if (strcmp($issue, $current) >= 0 || !preg_match('/^[0-9]$/D', $premium)) continue;
        $n = (int)$premium;
        $rows[$issue] = [
            'issueNumber'=>$issue, 'issueNo'=>$issue, 'period'=>$issue,
            'gameCode'=>$code, 'premium'=>$premium, 'number'=>$n,
            'color'=>le_color_from_number($n), 'colour'=>le_color_from_number($n),
            'bigSmall'=>$n >= 5 ? 'Big' : 'Small', 'sum'=>$n,
            'openTime'=>$item['openTime'] ?? null,
        ];
    }
    krsort($rows, SORT_STRING);
    return array_values($rows);
}

function h28_statistics(array $rows): array
{
    $size = count($rows); $stats = [];
    for ($n = 0; $n < 10; $n++) {
        $missing = 0; $count = 0; $run = 0; $max = 0; $seen = false;
        foreach ($rows as $row) {
            if ((int)$row['number'] === $n) {
                $seen = true; $count++; $run++; $max = max($max, $run);
            } else {
                if (!$seen) $missing++;
                $run = 0;
            }
        }
        // Average absent-run length over observed gaps (including both ends).
        $stats[] = ['number'=>$n, 'missingCount'=>$missing,
            'avgMissing'=>round(($size-$count)/($count+1), 2),
            'openCount'=>$count, 'maxContinuous'=>$max, 'sampleCount'=>$size];
    }
    return $stats;
}

function h28_provider_rows(string $code): ?array
{
    if (!function_exists('lb_enabled') || !lb_enabled()) return null;
    $cfg = lb_cfg();
    $issue = function_exists('lb_issue_data') ? lb_issue_data($code) : null;
    $current = (string)($issue['issueNumber'] ?? le_issue_by_offset($code, 1));
    // v29: a provider may cap pageSize=100 at TEN rows, including the current
    // period. Fetch its following pages, never reveal current just to reach 10.
    // Window contains ONLY validated provider observations, not legacy DB draws.
    $key = hash('sha256', __DIR__ . '|' . ($cfg['base'] ?? '') . '|' . $code);
    $file = sys_get_temp_dir() . '/13l_provider29_' . $key . '.json';
    $fp = @fopen($file, 'c+');
    $saved = [];
    if ($fp && flock($fp, LOCK_SH)) {
        $saved = json_decode((string)stream_get_contents($fp), true) ?: [];
        flock($fp, LOCK_UN);
    }
    if (($saved['current'] ?? '') === $current && time() - (int)($saved['at'] ?? 0) < 5) {
        if ($fp) fclose($fp);
        return h28_closed_rows((array)($saved['list'] ?? []), $code, $current);
    }
    $raw = lb_fetch_list($code, 5, 100);
    if (!is_array($raw)) { if ($fp) fclose($fp); return null; }
    $closed = h28_closed_rows($raw, $code, $current);
    $prior = h28_closed_rows((array)($saved['list'] ?? []), $code, $current);
    $merged = h28_closed_rows(array_merge($prior, $closed), $code, $current);
    $pageSize = max(1, min(100, count($raw)));
    $deadline = microtime(true) + 8;
    $previousOldest = $closed ? $closed[count($closed)-1]['issueNumber'] : '';
    if (($cfg['mode'] ?? '') === 'api') {
        for ($page=2; count($closed)<100 && $page<=12 && microtime(true)<$deadline; $page++) {
            $next = lb_raw_list($code, $pageSize, $page);
            if (!$next) break;
            $next = h28_closed_rows($next, $code, $current);
            if (!$next) break;
            $oldest = $next[count($next)-1]['issueNumber'];
            // Stop providers that ignore pageNo, without retry/request storms.
            if ($previousOldest !== '' && strcmp($oldest, $previousOldest) >= 0) break;
            $previousOldest = $oldest;
            $closed = h28_closed_rows(array_merge($closed, $next), $code, $current);
            $merged = h28_closed_rows(array_merge($merged, $next), $code, $current);
        }
    }
    $merged = array_slice($merged, 0, 200);
    if ($fp && flock($fp, LOCK_EX)) {
        // Merge concurrent requests before writing to avoid dropping verified rows.
        rewind($fp); $other = json_decode((string)stream_get_contents($fp), true) ?: [];
        $merged = array_slice(h28_closed_rows(array_merge((array)($other['list'] ?? []), $merged), $code, $current), 0, 200);
        rewind($fp); ftruncate($fp, 0);
        fwrite($fp, json_encode(['current'=>$current,'at'=>time(),'list'=>$merged]));
        fflush($fp); flock($fp, LOCK_UN);
    }
    if ($fp) fclose($fp);
    return $merged;
}

function h28_history_payload(array $rows, int $page): array
{
    $page = max(1, $page); $total = count($rows);
    return ['list'=>array_slice($rows, ($page-1)*10, 10), 'pageNo'=>$page,
        'pageSize'=>10, 'totalPage'=>(int)ceil($total/10), 'totalCount'=>$total,
        'source'=>'provider'];
}
