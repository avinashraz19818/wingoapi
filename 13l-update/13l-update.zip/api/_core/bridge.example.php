<?php
// COPY THIS FILE TO bridge.php (same folder) and fill the values.
// bridge.php ko copy karke bharna hai — bas yahi ek file badlegi.
return [
    // Draw provider URL — wahi address jo DhaniWin ke ADMIN panel me
    // "lottery_upstream_url" me dala hai. Usually looks like:
    //   https://sitedomain.com/wingoapi/  or  https://sitedomain.com/draw.php
    'base'  => '',
    // Provider key (agar admin me "lottery_upstream_key" set hai) — warna khali
    'key'   => '',
];
